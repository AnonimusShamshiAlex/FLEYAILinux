#!/usr/bin/env bash
# FLEY AI - установка живого голоса. Запуск: ./install_voice.sh
# 1) Нейроголос Microsoft Edge (лучший, бесплатно, нужен интернет): edge-tts + ffmpeg
# 2) Piper (офлайн, запасной)
DIR="$HOME/.local/share/fley-ai/voices"
mkdir -p "$DIR"

echo "[1/2] Нейроголос Edge (ru-RU-DmitryNeural)..."
if   command -v apt-get >/dev/null; then sudo apt-get install -y ffmpeg pipx
elif command -v dnf     >/dev/null; then sudo dnf install -y ffmpeg-free pipx || sudo dnf install -y ffmpeg pipx
elif command -v pacman  >/dev/null; then sudo pacman -S --needed --noconfirm ffmpeg python-pipx
elif command -v zypper  >/dev/null; then sudo zypper install -y ffmpeg python3-pipx
fi
if command -v pipx >/dev/null; then pipx install edge-tts || pipx upgrade edge-tts
else python3 -m pip install --user --break-system-packages edge-tts; fi
export PATH="$HOME/.local/bin:$PATH"
if command -v edge-tts >/dev/null && command -v ffmpeg >/dev/null; then
  if edge-tts --voice ru-RU-DmitryNeural --text "Здравствуйте, сэр. Голос установлен." --write-media /tmp/fley_edge_test.mp3 2>/dev/null; then
    echo "Edge-голос работает. Перезапустите FLEY AI."; exit 0
  fi
  echo "Edge-голос не ответил (нет интернета?). Ставлю офлайн-голос Piper..."
fi

echo "[2/2] Piper (офлайн)..."
command -v curl >/dev/null || { echo "Нужен curl"; exit 1; }
cd "$DIR"
case "$(uname -m)" in x86_64) A=x86_64;; aarch64) A=aarch64;; armv7l) A=armv7l;; *) echo "Архитектура не поддерживается"; exit 1;; esac
[ -x piper/piper ] || { curl -fL --retry 3 -o p.tgz "https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_linux_${A}.tar.gz" && tar xzf p.tgz && rm -f p.tgz; }
HF="https://huggingface.co/rhasspy/piper-voices/resolve/main"
[ -s ru.onnx ] || { curl -fL --retry 3 -o ru.onnx "$HF/ru/ru_RU/denis/medium/ru_RU-denis-medium.onnx" && curl -fL --retry 3 -o ru.onnx.json "$HF/ru/ru_RU/denis/medium/ru_RU-denis-medium.onnx.json"; }
echo "Готово. Перезапустите FLEY AI."
