# FLEY AI для Linux

Голосовой ИИ-помощник с HUD-интерфейсом. Порт Windows-версии: то же ядро (`src/core.hpp`), новый слой под Linux.

## Быстрый старт
```bash
./build.sh --install-deps   # один раз: поставит зависимости (apt / dnf / pacman / zypper)
./build.sh --run            # соберёт и запустит
./install.sh                # (по желанию) ярлык в меню приложений
```
При первом запуске откроются НАСТРОЙКИ: нажмите «СОЗДАТЬ КЛЮЧ (GROQ)», скопируйте ключ и нажмите «ВСТАВИТЬ КЛЮЧ».

## Что используется вместо Windows-частей
| Было (Windows) | Стало (Linux) |
|---|---|
| Win32 + GDI+ окно | SDL2 + Cairo |
| WinHTTP | libcurl |
| waveIn / waveOut | SDL2 audio |
| голос SAPI | espeak-ng, либо Piper (`FLEY_PIPER_MODEL`) |
| ShellExecute, SendInput | xdg-open, xdotool (X11) / wtype (Wayland) |
| громкость, медиа-клавиши | pactl / wpctl / amixer, playerctl |
| корзина, питание, блокировка | gio trash, systemctl, loginctl |

Зависимости: `g++ pkg-config libsdl2-dev libcairo2-dev libcurl4-openssl-dev`; для работы: `espeak-ng`, `xdotool` (или `wtype`), `playerctl`, `pactl`.

## Управление
Пробел или клик по ядру - микрофон. F11 - режим (полный экран / окно / мини). Esc - из полного экрана в окно.
Подтверждения опасных действий (команды, удаление, питание) показываются окном внутри программы: `Y` / `N`.

## Файлы
Рядом с программой (или в `~/.config/fley-ai/`): `.env` (настройки, права 600), `fley_memory.txt`, `fley_history.txt`, `fley.log`.

## Известные отличия
- Wayland: ввод текста/клавиш только через `wtype`; закрытие по имени процесса работает через `pkill`.
- Удаление - только в Корзину (`gio trash` / `trash-put`), безвозвратного `rm` нет.
- Голос espeak-ng звучит роботизированно; для живого голоса поставьте Piper и укажите модель в `.env`.
- Это порт: интерфейс проверен на компиляцию и логика действий тестами, но на вашем железе (микрофон, звук) возможны мелочи - пишите, поправлю.
