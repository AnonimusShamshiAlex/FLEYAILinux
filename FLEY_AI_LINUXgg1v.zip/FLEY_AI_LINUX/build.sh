#!/usr/bin/env bash
# FLEY AI (Linux) - сборка одной командой.
#   ./build.sh                 собрать в dist/fley-ai
#   ./build.sh --install-deps  сначала доустановить зависимости (нужен sudo)
#   ./build.sh --run           собрать и сразу запустить
set -euo pipefail
cd "$(dirname "$0")"

install_deps() {
  echo ">> Устанавливаю зависимости (нужен sudo)…"
  if   command -v apt-get >/dev/null; then sudo apt-get update && sudo apt-get install -y g++ pkg-config libsdl2-dev libcairo2-dev libcurl4-openssl-dev espeak-ng xdotool playerctl pulseaudio-utils fonts-dejavu-core
  elif command -v dnf     >/dev/null; then sudo dnf install -y gcc-c++ pkgconf-pkg-config SDL2-devel cairo-devel libcurl-devel espeak-ng xdotool playerctl pulseaudio-utils dejavu-sans-fonts dejavu-sans-mono-fonts
  elif command -v pacman  >/dev/null; then sudo pacman -S --needed --noconfirm gcc pkgconf sdl2 cairo curl espeak-ng xdotool playerctl libpulse ttf-dejavu
  elif command -v zypper  >/dev/null; then sudo zypper install -y gcc-c++ pkg-config SDL2-devel cairo-devel libcurl-devel espeak-ng xdotool playerctl pulseaudio-utils dejavu-fonts
  else echo "Не знаю ваш менеджер пакетов. Установите вручную: g++, pkg-config, SDL2, cairo, libcurl (dev-пакеты), espeak-ng, xdotool, playerctl."; exit 1; fi
}

RUN=0
for a in "$@"; do
  case "$a" in
    --install-deps) install_deps ;;
    --run) RUN=1 ;;
    -h|--help) sed -n 2,6p "$0"; exit 0 ;;
  esac
done

command -v g++ >/dev/null        || { echo "Нет g++. Запустите: ./build.sh --install-deps"; exit 1; }
command -v pkg-config >/dev/null || { echo "Нет pkg-config. Запустите: ./build.sh --install-deps"; exit 1; }
for lib in sdl2 cairo libcurl; do
  pkg-config --exists "$lib" || { echo "Не найдена библиотека '$lib' (нужны dev-пакеты). Запустите: ./build.sh --install-deps"; exit 1; }
done

echo ">> Проверка ядра (тесты)…"
g++ -std=c++17 -O1 -Isrc tests/test_core.cpp -o /tmp/fley_test_core && /tmp/fley_test_core | tail -3

echo ">> Компиляция FLEY AI…"
mkdir -p dist
g++ -std=c++17 -O2 -Wall -Wno-unused-function src/main_linux.cpp -o dist/fley-ai \
    $(pkg-config --cflags --libs sdl2 cairo libcurl) -lpthread

cp -f assets/fai.png dist/fai.png
[ -f dist/.env ] || { cp -f .env.example dist/.env; chmod 600 dist/.env; }

echo
echo "Готово: dist/fley-ai"
echo "Запуск:       ./dist/fley-ai"
echo "Установка:    ./install.sh   (ярлык в меню приложений)"
echo "Ключ API:     введите в окне НАСТРОЙКИ при первом запуске (бесплатный: https://console.groq.com/keys)"
for t in espeak-ng xdotool playerctl pactl; do command -v $t >/dev/null || echo "Совет: не найден '$t' (нужен для озвучки/управления ПК) - ./build.sh --install-deps"; done
[ "$RUN" = 1 ] && exec ./dist/fley-ai
exit 0
