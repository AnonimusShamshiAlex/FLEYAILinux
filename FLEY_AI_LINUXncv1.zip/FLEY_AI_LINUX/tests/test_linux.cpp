// Тесты Linux-части FLEY AI (без микрофона, окна и интернета). Запуск: make test
#include "../src/actions.hpp"

#include <cstdlib>

static int g_fail = 0, g_ok = 0;
#define CHECK(c)                                                                         \
    do {                                                                                 \
        if (c) ++g_ok;                                                                   \
        else { ++g_fail; fprintf(stderr, "FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); }  \
    } while (0)

static void write_text(const std::string& p, const std::string& t) { ensure_dir(fs::path(p).parent_path().string()); write_file(p, t); }

int main() {
    // чистое окружение
    std::string root = "/tmp/fley_test_" + std::to_string((long)getpid());
    std::error_code ec;
    fs::remove_all(root, ec);
    ensure_dir(root + "/home/Рабочий стол");
    ensure_dir(root + "/home/Documents");
    setenv("HOME", (root + "/home").c_str(), 1);
    setenv("XDG_CONFIG_HOME", (root + "/home/.config").c_str(), 1);
    setenv("XDG_DATA_HOME", (root + "/home/.local/share").c_str(), 1);
    setenv("XDG_DATA_DIRS", (root + "/share").c_str(), 1);
    ensure_dir(data_dir());
    write_text(root + "/home/.config/user-dirs.dirs", "XDG_DESKTOP_DIR=\"$HOME/Рабочий стол\"\nXDG_DOCUMENTS_DIR=\"$HOME/Documents\"\n");

    // ---- пути
    CHECK(config_dir() == root + "/home/.config/fley-ai");
    CHECK(expand_path_arg("desktop") == root + "/home/Рабочий стол");
    CHECK(expand_path_arg("Рабочий стол\\файл.txt") == root + "/home/Рабочий стол/файл.txt");
    CHECK(expand_path_arg("документы/a.md") == root + "/home/Documents/a.md");
    CHECK(expand_path_arg("~/x") == root + "/home/x");
    CHECK(expand_path_arg("/etc/hosts") == "/etc/hosts");
    CHECK(expand_path_arg("\"notes.txt\"") == root + "/home/notes.txt");

    // ---- защита от удаления и чтения секретов
    CHECK(is_protected_path_linux("/"));
    CHECK(is_protected_path_linux("/home"));
    CHECK(is_protected_path_linux("/usr/bin/ls"));
    CHECK(is_protected_path_linux("/etc"));
    CHECK(is_protected_path_linux(root + "/home"));
    CHECK(is_protected_path_linux(root + "/home/Рабочий стол"));
    CHECK(is_protected_path_linux(root + "/home/.ssh"));
    CHECK(!is_protected_path_linux(root + "/home/Рабочий стол/старое.txt"));
    CHECK(!is_protected_path_linux("/tmp/some_file.txt"));
    CHECK(is_protected_path_linux("/tmp"));
    CHECK(is_secret_path(root + "/home/.ssh/id_rsa"));
    CHECK(is_secret_path(root + "/home/.config/fley-ai/.env"));
    CHECK(is_secret_path(root + "/home/проект/.env"));
    CHECK(is_secret_path("/etc/shadow"));
    CHECK(!is_secret_path(root + "/home/Documents/notes.txt"));

    // ---- чтение файла
    write_text(root + "/home/Documents/notes.txt", "Привет, это заметка.\n");
    write_text(root + "/home/.ssh/id_rsa", "SECRET");
    ActResult r = ActReadFile({"read_file", {"documents/notes.txt"}});
    CHECK(r.ok && r.msg.find("Привет") != std::string::npos && r.feedback);
    r = ActReadFile({"read_file", {"~/.ssh/id_rsa"}});
    CHECK(!r.ok && r.msg.find("секрет") != std::string::npos);
    write_text(root + "/home/Documents/bin.dat", std::string("a\0b", 3));
    r = ActReadFile({"read_file", {"documents/bin.dat"}});
    CHECK(!r.ok);

    // ---- поиск и список
    r = ActFindFile({"find_file", {"notes"}});
    CHECK(r.ok && r.msg.find("notes.txt") != std::string::npos);
    r = ActFindFile({"find_file", {"НЕТТАКОГОФАЙЛА"}});
    CHECK(r.ok && r.msg.find("Ничего не найдено") != std::string::npos);
    r = ActListDir({"list_dir", {"documents"}});
    CHECK(r.ok && r.msg.find("notes.txt") != std::string::npos);

    // ---- .desktop: разбор, сопоставление имён (в том числе русских алиасов)
    write_text(root + "/share/applications/org.gnome.TextEditor.desktop",
               "[Desktop Entry]\nType=Application\nName=Text Editor\nName[ru]=Текстовый редактор\nExec=gnome-text-editor %U\nIcon=x\n");
    write_text(root + "/share/applications/hidden.desktop", "[Desktop Entry]\nType=Application\nName=Hidden Thing\nExec=true\nNoDisplay=true\n");
    write_text(root + "/share/applications/org.telegram.desktop.desktop", "[Desktop Entry]\nType=Application\nName=Telegram Desktop\nExec=telegram-desktop -- %u\n");
    auto entries = desktop_entries();
    CHECK(entries.size() == 2);  // скрытое не попало
    CHECK(split_exec("a \"b c\" 'd e' f").size() == 4);
    CHECK(split_exec("env \"A B\"=1 app")[1] == "A B=1");
    ActResult o = ActOpenApp("Блокнот");   // Windows-название -> «Text Editor»
    CHECK(!o.ok && o.msg.find("Не удалось запустить") != std::string::npos);  // нашли запись, но gnome-text-editor нет в системе
    o = ActOpenApp("телеграм");
    CHECK(!o.ok && o.msg.find("Не удалось запустить") != std::string::npos);
    o = ActOpenApp("несуществующаяпрограмма");
    CHECK(!o.ok && o.msg.find("Не нашёл") != std::string::npos);

    // ---- процессы
    RunResult rr = run_capture({"echo", "привет"}, 3000);
    CHECK(rr.code == 0 && rr.out == "привет\n");
    rr = run_capture({"cat"}, 3000, "из stdin");
    CHECK(rr.code == 0 && rr.out == "из stdin");
    long long t0 = now_ms();
    rr = run_shell("sleep 10", 600);
    CHECK(rr.timeout && now_ms() - t0 < 3000);  // зависшая команда убивается по таймауту
    rr = run_shell("exit 3", 2000);
    CHECK(rr.code == 3);
    CHECK(!have_cmd("точно-нет-такой-команды"));
    CHECK(have_cmd("sh"));

    // ---- действия «опасных» типов: подтверждение
    g_taint = false;
    g_set.confirm = true;
    ui_confirm = nullptr;  // без интерфейса опасное не выполняется
    r = ActRun({"run", {"echo hi"}});
    CHECK(!r.ok);
    ui_confirm = [](const std::string&) { return true; };
    r = ActRun({"run", {"echo hi"}});
    CHECK(r.ok && r.msg.find("hi") != std::string::npos);
    g_set.confirm = false;
    g_taint = true;  // после чтения недоверенных данных подтверждение требуется даже при confirm=0
    ui_confirm = [](const std::string&) { return false; };
    r = ActRun({"run", {"echo hi"}});
    CHECK(!r.ok);
    g_taint = false;

    // ---- удаление: защищённое и в Корзину
    r = ActDelete({"delete", {"/home"}});
    CHECK(!r.ok && r.msg.find("нельзя") != std::string::npos);
    r = ActDelete({"delete", {"~"}});
    CHECK(!r.ok);
    write_text(root + "/home/Documents/trash_me.txt", "x");
    r = ActDelete({"delete", {"documents/trash_me.txt"}});
    if (have_cmd("gio") || have_cmd("trash-put")) CHECK(r.ok || r.msg.find("Корзин") != std::string::npos);
    CHECK(fs::exists(root + "/home/Documents/trash_me.txt") == !r.ok);  // файл исчез только если реально перемещён

    // ---- закрытие программ: системные нельзя
    r = ActCloseApp({"close_app", {"systemd"}});
    CHECK(!r.ok && r.msg.find("Системный") != std::string::npos);
    CHECK(safe_proc_name("Telegram.exe") == "Telegram");
    CHECK(safe_proc_name("a; rm -rf /") == "arm-rf");

    // ---- клавиши
    CHECK(map_key_name("Enter") == "Return");
    CHECK(map_key_name("win") == "super");
    CHECK(map_key_name("ctrl") == "ctrl");
    CHECK(map_key_name("pagedown") == "Next");

    // ---- питание: неизвестный режим и отмена
    r = ActPower({"power", {"explode"}});
    CHECK(!r.ok);
    r = ActPower({"power", {"cancel"}});
    CHECK(r.ok);

    // ---- таймер: срабатывает и кладёт напоминание в очередь
    r = ActTimer({"timer", {"0.02", "проверка"}});  // 1.2 с
    CHECK(r.ok);
    for (int i = 0; i < 40 && !g_remFlag; ++i) msleep(100);
    CHECK(g_remFlag);
    { std::lock_guard<std::mutex> lk(g_remMx); CHECK(g_remDue.size() == 1 && g_remDue[0] == "проверка"); }
    CHECK(!ActTimer({"timer", {"0"}}).ok);

    // ---- память и история
    g_facts.clear();
    CHECK(ActRemember({"remember", {"любит чай"}}).ok);
    CHECK(ActRemember({"remember", {"любит чай"}}).msg == "Уже помню.");
    g_facts.clear();
    load_memory();
    CHECK(g_facts.size() == 1 && g_facts[0] == "любит чай");
    CHECK(memory_block().find("любит чай") != std::string::npos);
    CHECK(ActForget({"forget", {"ЧАЙ"}}).ok);  // регистр не важен, в том числе для кириллицы
    CHECK(g_facts.empty());
    g_hist = {{"user", "строка1\nстрока2"}, {"assistant", "ответ \\ слэш"}};
    save_history();
    g_hist.clear();
    load_history();
    CHECK(g_hist.size() == 2 && g_hist[0].second == "строка1\nстрока2" && g_hist[1].second == "ответ \\ слэш");

    // ---- sysinfo
    r = ActSysInfo();
    CHECK(r.ok && r.msg.find("Процессор") != std::string::npos && r.feedback);

    // ---- настройки: .env, свой сервер по http
    write_text(env_path(), "OPENAI_API_KEY=abc\nFLEY_BASE_URL=http://localhost:11434/v1\nFLEY_WAKE=флей\n");
    g_env = parse_env(read_file(env_path()));
    g_set = make_settings(g_env, "");
    CHECK(g_set.key == "abc" && g_set.host == "localhost:11434" && g_set.base_path == "/v1" && g_set.wake == "флей");

    // ---- разбор тегов действий моделью
    std::vector<Action> acts;
    std::string txt = extract_actions("Открываю. [[ACTION: open_app | firefox]] [[ACTION: key | ctrl+t]]", acts);
    CHECK(txt == "Открываю." && acts.size() == 2 && acts[1].type == "key");

    fs::remove_all(root, ec);
    printf("%s: %d проверок пройдено, %d провалено\n", g_fail ? "ЕСТЬ ОШИБКИ" : "ALL LINUX TESTS PASSED", g_ok, g_fail);
    return g_fail ? 1 : 0;
}
