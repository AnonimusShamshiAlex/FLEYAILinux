#!/usr/bin/env bash
# FLEY AI для Linux - установка одной командой:  ./install.sh
# Ставит зависимости (apt / dnf / pacman / zypper), собирает программу, кладёт её в ~/.local
# и добавляет «FLEY AI» в меню приложений. Права root нужны только для установки пакетов (спросит sudo).
#
# Параметры:
#   --system        установить для всех пользователей в /usr/local (нужен sudo)
#   --prefix DIR    свой каталог установки (по умолчанию ~/.local)
#   --no-deps       не устанавливать пакеты (если всё уже стоит)
#   --autostart     запускать FLEY AI вместе с рабочим столом
#   --key КЛЮЧ      сразу записать API-ключ (Groq gsk_..., OpenAI sk-..., OpenRouter sk-or-...)
#   -y, --yes       не задавать вопросов
#   -h, --help
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PREFIX="$HOME/.local"
SYSTEM=0; NODEPS=0; AUTOSTART=0; ASSUME_YES=0; KEY=""

c_ok=$'\e[32m'; c_warn=$'\e[33m'; c_err=$'\e[31m'; c_dim=$'\e[2m'; c_off=$'\e[0m'
[ -t 1 ] || { c_ok=""; c_warn=""; c_err=""; c_dim=""; c_off=""; }
say()  { printf '%s\n' "$*"; }
ok()   { printf '%s✔%s %s\n' "$c_ok" "$c_off" "$*"; }
warn() { printf '%s!%s %s\n' "$c_warn" "$c_off" "$*"; }
die()  { printf '%s✘ %s%s\n' "$c_err" "$*" "$c_off" >&2; exit 1; }

usage() { sed -n '2,15p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0; }

while [ $# -gt 0 ]; do
  case "$1" in
    --system) SYSTEM=1; PREFIX="/usr/local" ;;
    --prefix) [ $# -ge 2 ] || die "После --prefix нужен каталог"; PREFIX="$2"; shift ;;
    --no-deps) NODEPS=1 ;;
    --autostart) AUTOSTART=1 ;;
    --key) [ $# -ge 2 ] || die "После --key нужен ключ"; KEY="$2"; shift ;;
    -y|--yes) ASSUME_YES=1 ;;
    -h|--help) usage ;;
    *) die "Неизвестный параметр: $1 (см. --help)" ;;
  esac
  shift
done

[ "$(uname -s)" = "Linux" ] || die "Этот установщик только для Linux."
[ -f "$DIR/Makefile" ] && [ -f "$DIR/src/main.cpp" ] || die "Запускайте install.sh из папки проекта FLEY_AI_LINUX (рядом должны лежать Makefile и src/)."

# ---------------------------------------------------------------- sudo
SUDO=""
if [ "$(id -u)" -ne 0 ]; then
  if command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi
fi
need_root() {  # выполняет команду с правами root
  if [ "$(id -u)" -eq 0 ]; then "$@"
  elif [ -n "$SUDO" ]; then $SUDO "$@"
  else die "Нужны права root для: $*  (установите sudo или запустите от root)"; fi
}

# ---------------------------------------------------------------- пакеты
PM=""
for p in apt-get dnf zypper pacman; do command -v "$p" >/dev/null 2>&1 && { PM="$p"; break; }; done

case "$PM" in
  apt-get) REQUIRED="build-essential pkg-config libgtk-3-dev libcurl4-openssl-dev libpulse-dev"
           OPTIONAL="espeak-ng pulseaudio-utils xdg-utils libglib2.0-bin playerctl xdotool wtype wl-clipboard" ;;
  dnf)     REQUIRED="gcc-c++ make pkgconf-pkg-config gtk3-devel libcurl-devel pulseaudio-libs-devel"
           OPTIONAL="espeak-ng pulseaudio-utils xdg-utils glib2 playerctl xdotool wtype wl-clipboard" ;;
  zypper)  REQUIRED="gcc-c++ make pkg-config gtk3-devel libcurl-devel libpulse-devel"
           OPTIONAL="espeak-ng pulseaudio-utils xdg-utils glib2-tools playerctl xdotool wtype wl-clipboard" ;;
  pacman)  REQUIRED="base-devel pkgconf gtk3 curl libpulse"
           OPTIONAL="espeak-ng xdg-utils glib2 playerctl xdotool wtype wl-clipboard" ;;
esac

pkg_install() {  # один пакет; возвращает ошибку, но не завершает скрипт
  case "$PM" in
    apt-get) need_root env DEBIAN_FRONTEND=noninteractive apt-get install -y "$@" ;;
    dnf)     need_root dnf install -y "$@" ;;
    zypper)  need_root zypper --non-interactive install "$@" ;;
    pacman)  need_root pacman -S --needed --noconfirm "$@" ;;
  esac
}

have_build_tools() {
  command -v g++ >/dev/null 2>&1 && command -v make >/dev/null 2>&1 && command -v pkg-config >/dev/null 2>&1 &&
    pkg-config --exists gtk+-3.0 libcurl libpulse-simple 2>/dev/null
}

if [ "$NODEPS" -eq 0 ]; then
  if have_build_tools; then
    ok "Инструменты сборки и библиотеки уже установлены"
  elif [ -z "$PM" ]; then
    warn "Не нашёл менеджер пакетов (apt/dnf/zypper/pacman). Установите вручную: компилятор g++, make, pkg-config и dev-пакеты GTK3, libcurl, libpulse."
  else
    say "Нужно установить пакеты для сборки: $REQUIRED"
    if [ "$ASSUME_YES" -eq 0 ] && [ -t 0 ]; then
      read -r -p "Продолжить? [Y/n] " a
      case "${a:-Y}" in [nNнН]*) die "Отменено." ;; esac
    fi
    [ "$PM" = "apt-get" ] && need_root apt-get update -qq || true
    # shellcheck disable=SC2086
    pkg_install $REQUIRED || die "Не удалось установить пакеты для сборки."
    ok "Пакеты для сборки установлены"
  fi
  # необязательное: голос, громкость, плеер, клавиатура. Каждое отдельно, чтобы один отсутствующий пакет ничего не ломал
  if [ -n "$PM" ]; then
    missing=""
    for pkg in $OPTIONAL; do
      case "$pkg" in
        espeak-ng) command -v espeak-ng >/dev/null 2>&1 && continue ;;
        playerctl) command -v playerctl >/dev/null 2>&1 && continue ;;
        xdotool)   command -v xdotool   >/dev/null 2>&1 && continue ;;
        wtype)     command -v wtype     >/dev/null 2>&1 && continue ;;
        wl-clipboard) command -v wl-copy >/dev/null 2>&1 && continue ;;
        pulseaudio-utils) command -v pactl >/dev/null 2>&1 && continue ;;
        xdg-utils) command -v xdg-open >/dev/null 2>&1 && continue ;;
        libglib2.0-bin|glib2|glib2-tools) command -v gio >/dev/null 2>&1 && continue ;;
      esac
      missing="$missing $pkg"
    done
    for pkg in $missing; do
      if pkg_install "$pkg" >/dev/null 2>&1; then ok "Установлен: $pkg"
      else warn "Не удалось поставить «$pkg» (необязательно, часть голосовых команд может не работать)"; fi
    done
  fi
fi

# ---------------------------------------------------------------- сборка
say ""
say "Собираю FLEY AI (1-2 минуты)…"
make -C "$DIR" -s all >/dev/null 2>"$DIR/build.log" || { cat "$DIR/build.log" >&2; die "Сборка не удалась. Лог: $DIR/build.log"; }
rm -f "$DIR/build.log"
ok "Сборка готова"

# ---------------------------------------------------------------- установка
SRC_BIN="$DIR/build/fley-ai"
[ -x "$SRC_BIN" ] || die "Не найден собранный файл $SRC_BIN"

do_install() {  # $1 - префикс; использует install(1) и при необходимости root
  local pre="$1" runner=""
  if [ "$SYSTEM" -eq 1 ] && [ "$(id -u)" -ne 0 ]; then runner="$SUDO"; [ -n "$runner" ] || die "Для --system нужен sudo."; fi
  $runner install -Dm755 "$SRC_BIN" "$pre/bin/fley-ai"
  $runner install -Dm644 "$DIR/assets/fley-ai.svg" "$pre/share/icons/hicolor/scalable/apps/fley-ai.svg"
  # в ярлыке пишем полный путь к программе: меню находит её, даже если ~/.local/bin нет в PATH
  local tmp; tmp="$(mktemp)"
  sed "s|^Exec=fley-ai|Exec=$pre/bin/fley-ai|" "$DIR/packaging/fley-ai.desktop" > "$tmp"
  $runner install -Dm644 "$tmp" "$pre/share/applications/fley-ai.desktop"
  rm -f "$tmp"
  command -v update-desktop-database >/dev/null 2>&1 && $runner update-desktop-database "$pre/share/applications" >/dev/null 2>&1 || true
  command -v gtk-update-icon-cache  >/dev/null 2>&1 && $runner gtk-update-icon-cache -q -t "$pre/share/icons/hicolor" >/dev/null 2>&1 || true
}
do_install "$PREFIX"
ok "Установлено в $PREFIX  (программа: $PREFIX/bin/fley-ai)"

# ---------------------------------------------------------------- настройки и ключ
CONF_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/fley-ai"
mkdir -p "$CONF_DIR"
ENV_FILE="$CONF_DIR/.env"
if [ ! -f "$ENV_FILE" ]; then
  "$PREFIX/bin/fley-ai" --doctor >/dev/null 2>&1 || true   # при первом запуске программа сама создаёт .env
fi
[ -f "$ENV_FILE" ] || cp "$DIR/.env.example" "$ENV_FILE"
chmod 600 "$ENV_FILE"

set_key() (  # подоболочка: umask 077 не влияет на остальной скрипт
  umask 077
  local k="$1" tmp; tmp="$(mktemp)"
  if grep -q '^GROQ_API_KEY=' "$ENV_FILE" 2>/dev/null; then
    awk -v key="$k" 'BEGIN{done=0} /^GROQ_API_KEY=/ && !done {print "GROQ_API_KEY=" key; done=1; next} {print}' "$ENV_FILE" > "$tmp"
  else
    { cat "$ENV_FILE"; printf '\nGROQ_API_KEY=%s\n' "$k"; } > "$tmp"
  fi
  mv "$tmp" "$ENV_FILE"; chmod 600 "$ENV_FILE"
)
has_key() { grep -Eq '^(GROQ|OPENAI|OPENROUTER)_API_KEY=.+' "$ENV_FILE" 2>/dev/null; }

if [ -n "$KEY" ]; then
  set_key "$KEY"; ok "API-ключ записан в $ENV_FILE"
elif ! has_key && [ "$ASSUME_YES" -eq 0 ] && [ -t 0 ]; then
  say ""
  say "Нужен API-ключ. Бесплатный ключ Groq: https://console.groq.com/keys"
  read -r -s -p "Вставьте ключ (Enter - пропустить, потом можно в окне НАСТРОЙКИ): " k; echo
  if [ -n "${k:-}" ]; then set_key "$k"; ok "API-ключ сохранён (файл доступен только вам)"; fi
fi

# ---------------------------------------------------------------- автозапуск
if [ "$AUTOSTART" -eq 1 ]; then
  mkdir -p "${XDG_CONFIG_HOME:-$HOME/.config}/autostart"
  sed "s|^Exec=fley-ai|Exec=$PREFIX/bin/fley-ai|" "$DIR/packaging/fley-ai.desktop" > "${XDG_CONFIG_HOME:-$HOME/.config}/autostart/fley-ai.desktop"
  echo "X-GNOME-Autostart-enabled=true" >> "${XDG_CONFIG_HOME:-$HOME/.config}/autostart/fley-ai.desktop"
  ok "Автозапуск включён"
fi

# ---------------------------------------------------------------- итог
case ":$PATH:" in
  *":$PREFIX/bin:"*) ;;
  *) warn "Каталога $PREFIX/bin нет в PATH. Из меню приложений FLEY AI запустится, а в терминале пишите полный путь: $PREFIX/bin/fley-ai" ;;
esac
say ""
say "Проверка системы:"
"$PREFIX/bin/fley-ai" --doctor 2>&1 | sed -n '/\[/p;/Связь/p;/API-ключ/p;/Сеанс/p' | sed 's/^/  /' || true
say ""
ok "Готово! Запускайте «FLEY AI» из меню приложений или командой: fley-ai"
say "${c_dim}Режим без окна: fley-ai --cli   |   Проверка: fley-ai --doctor   |   Удаление: ./uninstall.sh${c_off}"
