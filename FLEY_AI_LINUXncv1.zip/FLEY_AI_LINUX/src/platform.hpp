// FLEY AI для Linux: платформенный слой (пути, процессы, HTTP через libcurl, микрофон и звук через PulseAudio/PipeWire).
// Весь переносимый код (JSON, настройки, VAD, разбор команд) лежит в core.hpp и не менялся.
#pragma once
#include "core.hpp"

#include <curl/curl.h>
#include <pulse/error.h>
#include <pulse/simple.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <filesystem>
#include <fstream>
#include <functional>
#include <future>
#include <mutex>
#include <sstream>
#include <thread>

namespace fs = std::filesystem;
using namespace fley;

// ---------------------------------------------------------------- общее состояние (один процесс, один экземпляр)
enum State { IDLE = 0, LISTENING = 1, THINKING = 2, SPEAKING = 3 };

inline Settings g_set;
inline std::map<std::string, std::string> g_env;  // сырые значения .env (для настроек, которых нет в Settings)
inline std::string g_scheme = "https";             // http допускается для локальных серверов (Ollama и т.п.)
inline std::atomic<bool> g_closing{false}, g_online{true}, g_taint{false}, g_ensurePlay{false}, g_stopSpeak{false};
inline std::atomic<bool> g_reload{false}, g_keyErr{false}, g_clearReq{false}, g_remFlag{false}, g_showSettings{false};
inline std::atomic<int> g_state{IDLE}, g_level1000{0};
inline bool g_verbose = false;

inline std::mutex g_msgMx;
inline std::string g_status = "Запуск…";
inline bool g_statusErr = false;

inline std::function<void(int, const std::string&)> ui_log;    // роль: 0 вы, 1 FLEY, 2 действие
inline std::function<bool(const std::string&)> ui_confirm;     // окно «Да/Нет» для опасных действий

inline void msleep(int ms) { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }
inline long long now_ms() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

// ---------------------------------------------------------------- пути и файлы
inline std::string home_dir() {
    const char* h = getenv("HOME");
    return (h && *h) ? h : "/tmp";
}
inline std::string xdg_dir(const char* env, const char* fallback_rel) {
    const char* v = getenv(env);
    return (v && *v) ? std::string(v) : home_dir() + "/" + fallback_rel;
}
inline std::string config_dir() { return xdg_dir("XDG_CONFIG_HOME", ".config") + "/fley-ai"; }
inline std::string data_dir() { return xdg_dir("XDG_DATA_HOME", ".local/share") + "/fley-ai"; }
inline std::string env_path() {
    const char* e = getenv("FLEY_ENV");
    return (e && *e) ? std::string(e) : config_dir() + "/.env";
}
inline void ensure_dir(const std::string& d) { std::error_code ec; fs::create_directories(d, ec); }

inline std::string read_file(const std::string& path, size_t max = 8u << 20) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return "";
    std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    if (s.size() > max) s.resize(max);
    return s;
}
inline bool write_file(const std::string& path, const std::string& data, bool private_mode = false) {
    std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) return false;
        f.write(data.data(), (std::streamsize)data.size());
        if (!f) return false;
    }
    std::error_code ec;
    if (private_mode) fs::permissions(tmp, fs::perms::owner_read | fs::perms::owner_write, ec);
    fs::rename(tmp, path, ec);
    return !ec;
}

inline void log_line(const std::string& msg) {
    static std::mutex mx;
    std::lock_guard<std::mutex> lk(mx);
    char ts[32];
    time_t t = time(nullptr);
    strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", localtime(&t));
    std::string path = data_dir() + "/fley.log";
    std::error_code ec;
    if (fs::exists(path, ec) && fs::file_size(path, ec) > (2u << 20)) fs::rename(path, path + ".1", ec);  // не раздуваем лог
    if (FILE* f = fopen(path.c_str(), "ab")) { fprintf(f, "%s %s\n", ts, msg.c_str()); fclose(f); }
    if (g_verbose) fprintf(stderr, "[%s] %s\n", ts, msg.c_str());
}

inline void set_status(const std::string& t, bool err = false) {
    std::lock_guard<std::mutex> lk(g_msgMx);
    g_status = t;
    g_statusErr = err;
}
inline std::string get_status(bool* err = nullptr) {
    std::lock_guard<std::mutex> lk(g_msgMx);
    if (err) *err = g_statusErr;
    return g_status;
}

// ---------------------------------------------------------------- процессы
inline bool have_cmd(const std::string& name) {
    if (name.empty()) return false;
    if (name.find('/') != std::string::npos) return access(name.c_str(), X_OK) == 0;
    const char* p = getenv("PATH");
    std::string path = p ? p : "/usr/local/bin:/usr/bin:/bin";
    std::stringstream ss(path);
    std::string dir;
    while (std::getline(ss, dir, ':')) {
        if (dir.empty()) continue;
        std::string full = dir + "/" + name;
        if (access(full.c_str(), X_OK) == 0) return true;
    }
    return false;
}

struct RunResult { int code = -1; std::string out; bool timeout = false; bool started = false; };

// Запуск программы без оболочки, с таймаутом; stdout+stderr собираются в строку, input уходит в stdin.
inline RunResult run_capture(const std::vector<std::string>& argv, int timeout_ms, const std::string& input = "") {
    RunResult r;
    if (argv.empty()) return r;
    std::vector<char*> av;
    for (auto& a : argv) av.push_back(const_cast<char*>(a.c_str()));
    av.push_back(nullptr);
    int outp[2], inp[2];
    if (pipe(outp) != 0) return r;
    if (pipe(inp) != 0) { close(outp[0]); close(outp[1]); return r; }
    pid_t pid = fork();
    if (pid < 0) { close(outp[0]); close(outp[1]); close(inp[0]); close(inp[1]); return r; }
    if (pid == 0) {
        setpgid(0, 0);
        dup2(inp[0], 0); dup2(outp[1], 1); dup2(outp[1], 2);
        close(outp[0]); close(outp[1]); close(inp[0]); close(inp[1]);
        execvp(av[0], av.data());
        _exit(127);
    }
    r.started = true;
    close(outp[1]); close(inp[0]);
    signal(SIGPIPE, SIG_IGN);
    fcntl(outp[0], F_SETFL, O_NONBLOCK);
    size_t wrote = 0;
    bool in_open = true;
    if (input.empty()) { close(inp[1]); in_open = false; } else fcntl(inp[1], F_SETFL, O_NONBLOCK);
    long long deadline = now_ms() + timeout_ms;
    char buf[8192];
    bool out_open = true;
    while (out_open) {
        long long left = deadline - now_ms();
        if (left <= 0) { r.timeout = true; break; }
        pollfd pf[2];
        int n = 0;
        pf[n++] = {outp[0], POLLIN, 0};
        if (in_open) pf[n++] = {inp[1], POLLOUT, 0};
        int pr = poll(pf, (nfds_t)n, (int)std::min<long long>(left, 200));
        if (pr < 0 && errno != EINTR) break;
        if (in_open && n == 2 && (pf[1].revents & (POLLOUT | POLLERR | POLLHUP))) {
            ssize_t w = write(inp[1], input.data() + wrote, input.size() - wrote);
            if (w > 0) wrote += (size_t)w;
            if (w < 0 && errno != EAGAIN) wrote = input.size();
            if (wrote >= input.size()) { close(inp[1]); in_open = false; }
        }
        if (pf[0].revents & (POLLIN | POLLHUP)) {
            ssize_t k = read(outp[0], buf, sizeof buf);
            if (k > 0) { if (r.out.size() < (16u << 20)) r.out.append(buf, (size_t)k); }
            else if (k == 0) out_open = false;
        }
    }
    if (in_open) close(inp[1]);
    close(outp[0]);
    if (r.timeout) kill(-pid, SIGKILL);
    int st = 0;
    for (int i = 0; i < 100; ++i) {
        pid_t w = waitpid(pid, &st, WNOHANG);
        if (w == pid) { r.code = WIFEXITED(st) ? WEXITSTATUS(st) : -1; return r; }
        if (i == 50 && !r.timeout) kill(-pid, SIGKILL);
        msleep(20);
    }
    kill(-pid, SIGKILL);
    waitpid(pid, &st, 0);
    return r;
}
inline RunResult run_shell(const std::string& cmd, int timeout_ms) { return run_capture({"/bin/sh", "-c", cmd}, timeout_ms); }

// Запуск «и забыть»: программа живёт отдельно от FLEY (двойной fork), вывод отбрасывается.
inline bool spawn_detached(const std::vector<std::string>& argv) {
    if (argv.empty() || !have_cmd(argv[0])) return false;
    std::vector<char*> av;
    for (auto& a : argv) av.push_back(const_cast<char*>(a.c_str()));
    av.push_back(nullptr);
    pid_t p = fork();
    if (p < 0) return false;
    if (p == 0) {
        setsid();
        pid_t q = fork();
        if (q != 0) _exit(q < 0 ? 1 : 0);
        int fd = open("/dev/null", O_RDWR);
        if (fd >= 0) { dup2(fd, 0); dup2(fd, 1); dup2(fd, 2); if (fd > 2) close(fd); }
        execvp(av[0], av.data());
        _exit(127);
    }
    int st = 0;
    waitpid(p, &st, 0);
    return WIFEXITED(st) && WEXITSTATUS(st) == 0;
}

// Открыть ссылку / файл / папку программой по умолчанию
inline bool open_target(const std::string& target) {
    for (const char* c : {"xdg-open", "gio", "gnome-open", "kde-open5", "kde-open"}) {
        if (!have_cmd(c)) continue;
        if (std::string(c) == "gio") return spawn_detached({"gio", "open", target});
        return spawn_detached({c, target});
    }
    return false;
}

// ---------------------------------------------------------------- HTTP (libcurl)
struct HttpRes {
    int status = 0;
    std::string body, ctype;
    int err = 0;    // код curl, если не удалось соединиться
    int retry = 0;  // заголовок Retry-After, сек
};
inline size_t curl_write_cb(char* p, size_t s, size_t n, void* u) {
    auto* b = (std::string*)u;
    if (b->size() > (24u << 20)) return 0;
    b->append(p, s * n);
    return s * n;
}
inline size_t curl_header_cb(char* p, size_t s, size_t n, void* u) {
    std::string h(p, s * n);
    std::string l = to_lower_ascii(h);
    if (l.compare(0, 12, "retry-after:") == 0) *(int*)u = std::atoi(h.c_str() + 12);
    return s * n;
}
inline HttpRes http_request(const std::string& url, const std::vector<std::string>& headers, const std::string* post_body,
                            long timeout_s = 120, long max_redirs = 3) {
    static std::once_flag once;
    std::call_once(once, [] { curl_global_init(CURL_GLOBAL_DEFAULT); });
    HttpRes r;
    CURL* c = curl_easy_init();
    if (!c) { r.err = -1; return r; }
    curl_slist* hl = nullptr;
    for (auto& h : headers) hl = curl_slist_append(hl, h.c_str());
    curl_easy_setopt(c, CURLOPT_URL, url.c_str());
    curl_easy_setopt(c, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(c, CURLOPT_USERAGENT, "FLEY-AI-Linux/1.0 (+Mozilla/5.0 X11; Linux x86_64)");
    curl_easy_setopt(c, CURLOPT_CONNECTTIMEOUT, 15L);
    curl_easy_setopt(c, CURLOPT_TIMEOUT, timeout_s);
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, max_redirs > 0 ? 1L : 0L);
    curl_easy_setopt(c, CURLOPT_MAXREDIRS, max_redirs);
    curl_easy_setopt(c, CURLOPT_PROTOCOLS_STR, "http,https");
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, curl_write_cb);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, &r.body);
    curl_easy_setopt(c, CURLOPT_HEADERFUNCTION, curl_header_cb);
    curl_easy_setopt(c, CURLOPT_HEADERDATA, &r.retry);
    if (hl) curl_easy_setopt(c, CURLOPT_HTTPHEADER, hl);
    if (post_body) {
        curl_easy_setopt(c, CURLOPT_POST, 1L);
        curl_easy_setopt(c, CURLOPT_POSTFIELDS, post_body->data());
        curl_easy_setopt(c, CURLOPT_POSTFIELDSIZE_LARGE, (curl_off_t)post_body->size());
    }
    CURLcode rc = curl_easy_perform(c);
    if (rc != CURLE_OK && r.body.empty()) {
        r.err = (int)rc;
    } else {
        long code = 0;
        curl_easy_getinfo(c, CURLINFO_RESPONSE_CODE, &code);
        r.status = (int)code;
        char* ct = nullptr;
        curl_easy_getinfo(c, CURLINFO_CONTENT_TYPE, &ct);
        if (ct) r.ctype = ct;
    }
    curl_slist_free_all(hl);
    curl_easy_cleanup(c);
    return r;
}

inline HttpRes http_post(const std::string& path, const std::string& ctype, const std::string& body, bool tts = false) {
    const std::string& host = tts ? g_set.tts_host : g_set.host;
    const std::string& base = tts ? g_set.tts_path : g_set.base_path;
    const std::string& key = tts ? g_set.tts_key : g_set.key;
    std::string scheme = tts ? "https" : g_scheme;
    return http_request(scheme + "://" + host + base + path,
                        {"Authorization: Bearer " + key, "Content-Type: " + ctype, "X-Title: FLEY AI"}, &body, 120, 0);
}
inline std::string http_get_page(const std::string& host, const std::string& path) {
    HttpRes r = http_request("https://" + host + path, {"Accept-Language: ru,en;q=0.8", "Cookie: CONSENT=YES+1; SOCS=CAI"}, nullptr, 20, 3);
    return r.body.size() > 1500000 ? r.body.substr(0, 1500000) : r.body;
}

// ---------------------------------------------------------------- микрофон (PulseAudio / PipeWire-pulse)
inline std::string pick_source(const std::string& want_in) {
    static bool logged = false;
    std::string want = to_lower_ascii(want_in);
    std::string chosen;
    RunResult r = run_capture({"pactl", "list", "short", "sources"}, 3000);
    std::stringstream ss(r.out);
    std::string ln;
    int idx = 0;
    while (std::getline(ss, ln)) {
        std::vector<std::string> cols;
        std::stringstream ls(ln);
        std::string c;
        while (std::getline(ls, c, '\t')) cols.push_back(c);
        if (cols.size() < 2) continue;
        if (!logged) log_line("mic[" + std::to_string(idx) + "]: " + cols[1]);
        ++idx;
        if (cols[1].size() > 8 && cols[1].compare(cols[1].size() - 8, 8, ".monitor") == 0) continue;  // не «что играет», а микрофон
        if (!want.empty() && chosen.empty() && to_lower_ascii(cols[1]).find(want) != std::string::npos) chosen = cols[1];
    }
    if (!logged) log_line(chosen.empty() ? "mic: источник по умолчанию" : "mic: выбран " + chosen);
    logged = true;
    return chosen;
}

class Mic {
public:
    ~Mic() { close_(); }
    bool open(const std::string& device_part, std::string& err) {
        pa_sample_spec ss;
        ss.format = PA_SAMPLE_S16LE; ss.rate = 16000; ss.channels = 1;
        pa_buffer_attr at;
        at.maxlength = (uint32_t)-1; at.tlength = (uint32_t)-1; at.prebuf = (uint32_t)-1; at.minreq = (uint32_t)-1;
        at.fragsize = 1600;  // 50 мс
        std::string dev = pick_source(device_part);  // заодно один раз пишет список микрофонов в лог
        int e = 0;
        s_ = pa_simple_new(nullptr, "FLEY AI", PA_STREAM_RECORD, dev.empty() ? nullptr : dev.c_str(), "микрофон", &ss, nullptr, &at, &e);
        if (!s_) { err = pa_strerror(e); return false; }
        return true;
    }
    // Читает ровно n отсчётов (блокирует до поступления данных)
    bool read(short* d, size_t n) {
        int e = 0;
        return s_ && pa_simple_read(s_, d, n * 2, &e) >= 0;
    }
    void close_() { if (s_) { pa_simple_free(s_); s_ = nullptr; } }
private:
    pa_simple* s_ = nullptr;
};

// ---------------------------------------------------------------- воспроизведение
// Проигрывает PCM s16le; можно прервать флагом stop. Громкость кадра отдаёт в g_level1000 (оживляет ядро на экране).
inline bool play_pcm(const std::string& pcm, int rate, int channels, const std::atomic<bool>& stop) {
    pa_sample_spec ss;
    ss.format = PA_SAMPLE_S16LE; ss.rate = (uint32_t)rate; ss.channels = (uint8_t)channels;
    pa_buffer_attr at;
    at.maxlength = (uint32_t)-1; at.prebuf = (uint32_t)-1; at.minreq = (uint32_t)-1; at.fragsize = (uint32_t)-1;
    at.tlength = (uint32_t)(rate * channels * 2 / 5);  // ~200 мс
    int e = 0;
    pa_simple* s = pa_simple_new(nullptr, "FLEY AI", PA_STREAM_PLAYBACK, nullptr, "голос", &ss, nullptr, &at, &e);
    if (!s) { log_line(std::string("play: ") + pa_strerror(e)); return false; }
    const size_t chunk = (size_t)rate * (size_t)channels * 2 / 20;  // 50 мс
    bool ok = true;
    for (size_t off = 0; off + 1 < pcm.size() && !stop && !g_closing; off += chunk) {
        size_t n = std::min(chunk, pcm.size() - off) & ~(size_t)1;
        double rms = rms16((const short*)(pcm.data() + off), n / 2);
        g_level1000 = (int)(std::min(1.0, rms / 6000.0) * 1000.0);
        if (pa_simple_write(s, pcm.data() + off, n, &e) < 0) { ok = false; break; }
    }
    if (stop || g_closing || !ok) pa_simple_flush(s, &e); else pa_simple_drain(s, &e);
    pa_simple_free(s);
    g_level1000 = 0;
    return ok;
}

// WAV (16 бит PCM) -> воспроизведение
inline bool play_wav(const std::string& wav, const std::atomic<bool>& stop) {
    if (wav.size() < 44 || wav.compare(0, 4, "RIFF") != 0) return false;
    auto rd = [&](size_t o, int n) { uint32_t v = 0; for (int i = 0; i < n && o + (size_t)i < wav.size(); ++i) v |= (uint32_t)(unsigned char)wav[o + (size_t)i] << (8 * i); return v; };
    size_t p = 12;
    int ch = 1, rate = 22050, bits = 16;
    while (p + 8 <= wav.size()) {
        std::string id = wav.substr(p, 4);
        size_t len = rd(p + 4, 4);
        if (id == "fmt ") { ch = (int)rd(p + 10, 2); rate = (int)rd(p + 12, 4); bits = (int)rd(p + 22, 2); }
        else if (id == "data") {
            size_t n = std::min(len, wav.size() - (p + 8));
            if (bits != 16 || ch < 1 || ch > 2) return false;
            return play_pcm(wav.substr(p + 8, n), rate, ch, stop);
        }
        p += 8 + len + (len & 1);
    }
    return false;
}
