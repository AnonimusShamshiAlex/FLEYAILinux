// FLEY AI для Linux: окно HUD (GTK3 + Cairo), режимы --cli / --ask / --doctor.
#include "brain.hpp"

#include <glib-unix.h>
#include <gtk/gtk.h>
#include <sys/file.h>

#define FLEY_VERSION "1.0"

// ================================================================== общие вещи
static const char* kUsage =
    "FLEY AI " FLEY_VERSION " для Linux\n"
    "Использование: fley-ai [параметры]\n"
    "  (без параметров)   окно HUD с постоянным прослушиванием\n"
    "  --cli              без окна: работает в терминале (удобно по SSH и для проверки)\n"
    "  --ask \"текст\"      выполнить фразу так, будто вы её сказали (без микрофона)\n"
    "  --say \"текст\"      проверить голос\n"
    "  --no-speak         не озвучивать ответы (для --ask / --cli)\n"
    "  --doctor           проверить, чего не хватает в системе\n"
    "  --verbose          дублировать лог в терминал\n"
    "  --version, --help\n"
    "Настройки: ~/.config/fley-ai/.env   Лог: ~/.local/share/fley-ai/fley.log\n";

static void install_hint(const char* what_apt, const char* what_dnf, const char* what_pac) {
    printf("      Установка: apt install %s | dnf install %s | pacman -S %s\n", what_apt, what_dnf, what_pac);
}

static int doctor() {
    ensure_env_file();
    load_settings();
    printf("FLEY AI %s - проверка системы\n\n", FLEY_VERSION);
    printf("Система: %s\n", os_name().c_str());
    printf("Сеанс: %s, окружение: %s\n", is_wayland() ? "Wayland" : "X11", getenv("XDG_CURRENT_DESKTOP") ? getenv("XDG_CURRENT_DESKTOP") : "неизвестно");
    printf("Настройки: %s\n", env_path().c_str());
    printf("API-ключ: %s\n\n", !g_set.key.empty() ? "есть" : "НЕ ЗАДАН (впишите в настройках; бесплатный: console.groq.com/keys)");
    int bad = 0;
    auto check = [&](const char* title, bool ok, const char* need, const char* a, const char* d, const char* p) {
        printf("  [%s] %s\n", ok ? " OK " : "НЕТ ", title);
        if (!ok) { ++bad; if (need) printf("      %s\n", need); install_hint(a, d, p); }
    };
    bool pa = have_cmd("pactl") && run_capture({"pactl", "info"}, 3000).code == 0;
    check("Звуковой сервер (PipeWire/PulseAudio)", pa, "Без него нет ни микрофона, ни звука.", "pipewire-pulse pulseaudio-utils", "pipewire-pulseaudio pulseaudio-utils", "pipewire-pulse libpulse");
    if (pa) {
        RunResult r = run_capture({"pactl", "list", "short", "sources"}, 3000);
        int n = 0;
        std::stringstream ss(r.out);
        std::string ln;
        while (std::getline(ss, ln)) if (ln.find(".monitor") == std::string::npos && !ln.empty()) ++n;
        check("Микрофон найден", n > 0, "Подключите микрофон или включите его в настройках звука.", "-", "-", "-");
    }
    bool voice = have_cmd("espeak-ng") || have_cmd("espeak") || !env_get("FLEY_PIPER_MODEL").empty();
    check("Голос (espeak-ng или Piper)", voice || (!g_set.windows_tts && g_set.tts_cloud), "Без голоса FLEY только пишет ответы.", "espeak-ng", "espeak-ng", "espeak-ng");
    check("xdg-open (открытие ссылок, файлов)", have_cmd("xdg-open") || have_cmd("gio"), nullptr, "xdg-utils", "xdg-utils", "xdg-utils");
    check("gio (запуск приложений, Корзина)", have_cmd("gio"), "Нужен для запуска программ и удаления в Корзину.", "libglib2.0-bin", "glib2", "glib2");
    check("Громкость (wpctl или pactl)", have_cmd("wpctl") || have_cmd("pactl"), nullptr, "wireplumber", "wireplumber", "wireplumber");
    check("playerctl (пауза, следующий трек)", have_cmd("playerctl"), "Нужен для голосового управления плеером.", "playerctl", "playerctl", "playerctl");
    bool kb = is_wayland() ? (have_cmd("wtype") || have_cmd("ydotool")) : have_cmd("xdotool");
    check(is_wayland() ? "wtype/ydotool (ввод текста и клавиш)" : "xdotool (ввод текста и клавиш)", kb, "Нужен для команд «напечатай» и «нажми».",
          is_wayland() ? "wtype" : "xdotool", is_wayland() ? "wtype" : "xdotool", is_wayland() ? "wtype" : "xdotool");
    check("loginctl (блокировка экрана)", have_cmd("loginctl"), nullptr, "systemd", "systemd", "systemd");
    printf("\n  Установленных программ найдено (для «открой …»): %zu\n", desktop_entries().size());
    if (!g_set.key.empty() || g_scheme == "http") {
        HttpRes r = http_request(g_scheme + "://" + g_set.host + g_set.base_path + "/models", {"Authorization: Bearer " + g_set.key}, nullptr, 15, 0);
        printf("  Связь с %s: %s\n", g_set.host.c_str(), r.status == 200 ? "OK, ключ принят" : r.status == 401 ? "ключ НЕ подошёл (401)" : r.status ? ("ответ " + std::to_string(r.status)).c_str() : ("нет связи (код " + std::to_string(r.err) + ")").c_str());
    }
    printf("\n%s\n", bad ? "Есть, что доустановить (см. выше). Остальное работает." : "Всё необходимое на месте.");
    return 0;
}

static std::string arg_value(int argc, char** argv, const char* name) {
    for (int i = 1; i + 1 < argc; ++i) if (std::string(argv[i]) == name) return argv[i + 1];
    return "";
}
static bool has_flag(int argc, char** argv, const char* name) {
    for (int i = 1; i < argc; ++i) if (std::string(argv[i]) == name) return true;
    return false;
}

static void print_event(int role, const std::string& t) {
    const char* tag = role == 0 ? "ВЫ   " : role == 1 ? "FLEY " : role == 3 ? "ОШИБКА" : "ДЕЙСТВИЕ";
    printf("%s> %s\n", tag, t.c_str());
    fflush(stdout);
}
static bool cli_confirm(const std::string& what) {
    printf("\n[ПОДТВЕРЖДЕНИЕ] %s\nВыполнить? [y/N]: ", what.c_str());
    fflush(stdout);
    char buf[16] = {};
    if (!fgets(buf, sizeof buf, stdin)) return false;
    std::string a = to_lower_ascii(trim(buf));
    return a == "y" || a == "yes" || a.compare(0, 2, "д") == 0 || a.compare(0, 2, "Д") == 0;
}

static void on_signal_cli(int) { g_closing = true; }

static int run_cli(bool ask_mode, const std::string& ask_text) {
    ui_log = print_event;
    ui_confirm = cli_confirm;
    if (ask_mode) {
        Action probe;
        bool local = g_set.pc && local_intent(ask_text, probe);
        if (g_set.key.empty() && g_scheme == "https" && !local) {
            fprintf(stderr, "Нет API-ключа: впишите его в %s (GROQ_API_KEY=...)\n", env_path().c_str());
            return 2;
        }
        try { process_text(ask_text); }
        catch (const std::exception& e) { fprintf(stderr, "Ошибка: %s\n", e.what()); return 1; }
        return 0;
    }
    signal(SIGINT, on_signal_cli);
    signal(SIGTERM, on_signal_cli);
    printf("FLEY AI %s (режим терминала). Ctrl+C - выход.\n", FLEY_VERSION);
    std::thread t(session_thread);
    std::string last;
    while (!g_closing) {
        std::string s = get_status();
        if (s != last) { last = s; printf("· %s\n", s.c_str()); fflush(stdout); }
        msleep(200);
    }
    t.detach();
    return 0;
}

// ================================================================== окно HUD
struct LogEntry { int role; std::string text; };
static std::vector<LogEntry> g_logs;  // только поток интерфейса
static GtkWidget *g_win = nullptr, *g_area = nullptr;
static double g_phase = 0, g_levelSmooth = 0, g_scrollPx = 0;
static int g_mode = 0;  // 0 весь экран, 1 окно, 2 мини
static int g_hover = -1;
static double g_cpu = 0, g_ram = 0;
static int g_bat = -1;
static long long g_statsAt = 0;
static CpuTimes g_cpuPrev;

struct Rgb { double r, g, b; };
static const Rgb CYAN{0.20, 0.72, 1.00}, ICE{0.78, 0.94, 1.00}, AMBER{1.00, 0.68, 0.18}, GOLD{1.00, 0.82, 0.35}, RED{1.00, 0.33, 0.33},
    GREEN{0.45, 1.00, 0.72}, STEEL{0.36, 0.48, 0.58};

static void setc(cairo_t* cr, Rgb c, double a = 1.0) { cairo_set_source_rgba(cr, c.r, c.g, c.b, a); }

static double draw_text(cairo_t* cr, const std::string& s, double x, double y, double size, Rgb c, double a, int align = 0, double maxw = -1,
                        bool bold = false, const char* family = "Sans", bool measure_only = false) {
    PangoLayout* l = pango_cairo_create_layout(cr);
    std::string fam = std::string(family) + (bold ? " Bold" : "");
    PangoFontDescription* fd = pango_font_description_from_string(fam.c_str());
    pango_font_description_set_absolute_size(fd, size * PANGO_SCALE);
    pango_layout_set_font_description(l, fd);
    if (maxw > 0) {
        pango_layout_set_width(l, (int)(maxw * PANGO_SCALE));
        pango_layout_set_wrap(l, PANGO_WRAP_WORD_CHAR);
        pango_layout_set_alignment(l, align == 1 ? PANGO_ALIGN_CENTER : align == 2 ? PANGO_ALIGN_RIGHT : PANGO_ALIGN_LEFT);
    }
    pango_layout_set_text(l, s.c_str(), -1);
    int w = 0, h = 0;
    pango_layout_get_pixel_size(l, &w, &h);
    if (!measure_only) {
        double px = x;
        if (maxw <= 0) px = align == 1 ? x - w / 2.0 : align == 2 ? x - w : x;
        cairo_move_to(cr, px, y);
        setc(cr, c, a);
        pango_cairo_show_layout(cr, l);
    }
    g_object_unref(l);
    pango_font_description_free(fd);
    return (double)h;
}
static double text_width(cairo_t* cr, const std::string& s, double size, bool bold = false, const char* family = "Sans") {
    PangoLayout* l = pango_cairo_create_layout(cr);
    PangoFontDescription* fd = pango_font_description_from_string((std::string(family) + (bold ? " Bold" : "")).c_str());
    pango_font_description_set_absolute_size(fd, size * PANGO_SCALE);
    pango_layout_set_font_description(l, fd);
    pango_layout_set_text(l, s.c_str(), -1);
    int w = 0, h = 0;
    pango_layout_get_pixel_size(l, &w, &h);
    g_object_unref(l);
    pango_font_description_free(fd);
    return w;
}

static void brackets(cairo_t* cr, double x, double y, double w, double h, Rgb c, double len, double lw, double a) {
    setc(cr, c, a);
    cairo_set_line_width(cr, lw);
    cairo_move_to(cr, x, y + len); cairo_line_to(cr, x, y); cairo_line_to(cr, x + len, y);
    cairo_move_to(cr, x + w - len, y); cairo_line_to(cr, x + w, y); cairo_line_to(cr, x + w, y + len);
    cairo_move_to(cr, x + w, y + h - len); cairo_line_to(cr, x + w, y + h); cairo_line_to(cr, x + w - len, y + h);
    cairo_move_to(cr, x + len, y + h); cairo_line_to(cr, x, y + h); cairo_line_to(cr, x, y + h - len);
    cairo_stroke(cr);
}

struct Btn { int id; double x, y, w, h; std::string text; Rgb col; };
static std::vector<Btn> g_btns;
enum { B_MIC = 1, B_SET, B_MODE, B_CLEAR, B_EXIT };

struct Lay { double s, cx, cy, R, lx, ly, lw, lh; bool mini; };
static Lay layout_for(double w, double h) {
    Lay L;
    L.mini = w < 640;
    L.s = std::max(0.6, std::min(1.7, std::min(w / 1100.0, h / 720.0)));
    if (L.mini) L.s = std::max(0.6, std::min(w / 520.0, h / 380.0));
    L.cx = w / 2;
    L.R = L.mini ? std::min(w * 0.14, h * 0.14) : std::min(w * 0.14, h * 0.165);
    L.cy = h * (L.mini ? 0.30 : 0.345);
    double sy = L.cy + L.R * 1.82;  // подпись состояния лежит сразу под эквалайзером
    L.lw = std::min(w * 0.82, 980.0 * L.s);
    L.lx = (w - L.lw) / 2;
    L.ly = std::max(sy + (L.mini ? 48.0 : 62.0 * L.s), h * (L.mini ? 0.0 : 0.70));
    L.lh = h - L.ly - (L.mini ? 40.0 : 34.0 * L.s);
    return L;
}

static void update_stats() {
    long long t = now_ms();
    if (t - g_statsAt < 1000) return;
    g_statsAt = t;
    CpuTimes c = read_cpu_times();
    if (g_cpuPrev.total && c.total > g_cpuPrev.total)
        g_cpu = 100.0 * (double)((c.total - g_cpuPrev.total) - (c.idle - g_cpuPrev.idle)) / (double)(c.total - g_cpuPrev.total);
    g_cpuPrev = c;
    g_ram = ram_percent();
    g_bat = battery_percent();
}

static void bar(cairo_t* cr, double x, double y, double w, double frac, Rgb c, const std::string& label, const std::string& val, double s) {
    draw_text(cr, label, x, y, 11 * s, ICE, 0.7, 0, -1, false, "Monospace");
    draw_text(cr, val, x + w, y, 11 * s, ICE, 0.9, 2, -1, false, "Monospace");
    double by = y + 16 * s;
    setc(cr, CYAN, 0.18);
    cairo_rectangle(cr, x, by, w, 4 * s);
    cairo_fill(cr);
    setc(cr, c, 0.9);
    cairo_rectangle(cr, x, by, w * std::max(0.0, std::min(1.0, frac)), 4 * s);
    cairo_fill(cr);
}

static void draw_orb(cairo_t* cr, const Lay& L) {
    int st = g_state;
    bool online = g_online;
    Rgb col = !online ? STEEL : st == THINKING ? AMBER : st == SPEAKING ? ICE : CYAN;
    double target = online ? g_level1000 / 1000.0 : 0.0;
    double R = L.R, cx = L.cx, cy = L.cy;
    double pulse = st == THINKING ? 0.5 + 0.5 * std::sin(g_phase * 5.0) : 0.0;
    double lv = std::max(g_levelSmooth, pulse * 0.5);
    (void)target;

    // свечение
    cairo_pattern_t* gl = cairo_pattern_create_radial(cx, cy, R * 0.2, cx, cy, R * 2.3);
    cairo_pattern_add_color_stop_rgba(gl, 0, col.r, col.g, col.b, online ? 0.28 + 0.25 * lv : 0.08);
    cairo_pattern_add_color_stop_rgba(gl, 1, col.r, col.g, col.b, 0);
    cairo_set_source(cr, gl);
    cairo_arc(cr, cx, cy, R * 2.3, 0, 2 * M_PI);
    cairo_fill(cr);
    cairo_pattern_destroy(gl);

    double spin = online ? (st == THINKING ? 2.4 : st == SPEAKING ? 1.2 : 0.6) : 0.12;

    // эквалайзер вокруг ядра
    const int N = 72;
    for (int i = 0; i < N; ++i) {
        double a = (double)i / N * 2 * M_PI - M_PI / 2;
        double wobble = 0.5 + 0.5 * std::sin(i * 0.9 + g_phase * 4.0) * std::cos(i * 0.31 - g_phase * 2.0);
        double len = R * (0.05 + (online ? 0.26 : 0.02) * lv * (0.35 + wobble));
        double r0 = R * 1.48;
        setc(cr, col, online ? 0.35 + 0.55 * lv : 0.18);
        cairo_set_line_width(cr, std::max(1.5, R * 0.025));
        cairo_move_to(cr, cx + std::cos(a) * r0, cy + std::sin(a) * r0);
        cairo_line_to(cr, cx + std::cos(a) * (r0 + len), cy + std::sin(a) * (r0 + len));
        cairo_stroke(cr);
    }
    // внешнее кольцо с делениями
    cairo_save(cr);
    cairo_translate(cr, cx, cy);
    cairo_rotate(cr, -g_phase * spin * 0.5);
    for (int i = 0; i < 90; ++i) {
        double a = (double)i / 90 * 2 * M_PI;
        double l = (i % 5 == 0) ? R * 0.10 : R * 0.04;
        setc(cr, col, (i % 5 == 0) ? 0.7 : 0.35);
        cairo_set_line_width(cr, 1.2);
        cairo_move_to(cr, std::cos(a) * R * 1.30, std::sin(a) * R * 1.30);
        cairo_line_to(cr, std::cos(a) * (R * 1.30 + l), std::sin(a) * (R * 1.30 + l));
        cairo_stroke(cr);
    }
    cairo_restore(cr);
    // дуги
    for (int k = 0; k < 3; ++k) {
        double r = R * (1.08 + 0.08 * k);
        double dir = (k % 2 ? -1 : 1);
        double a0 = g_phase * spin * (0.7 + 0.5 * k) * dir + k * 2.1;
        setc(cr, col, 0.75 - 0.15 * k);
        cairo_set_line_width(cr, 2.2 - 0.4 * k);
        cairo_arc(cr, cx, cy, r, a0, a0 + 1.15 + 0.25 * k);
        cairo_stroke(cr);
        cairo_arc(cr, cx, cy, r, a0 + M_PI, a0 + M_PI + 0.7);
        cairo_stroke(cr);
    }
    // пунктирное кольцо
    cairo_save(cr);
    double dashes[2] = {R * 0.05, R * 0.07};
    cairo_set_dash(cr, dashes, 2, g_phase * 20 * spin);
    setc(cr, col, 0.5);
    cairo_set_line_width(cr, 1.4);
    cairo_arc(cr, cx, cy, R * 0.92, 0, 2 * M_PI);
    cairo_stroke(cr);
    cairo_restore(cr);
    // ядро
    double cr_ = R * (0.50 + 0.14 * lv + 0.04 * pulse);
    cairo_pattern_t* core = cairo_pattern_create_radial(cx, cy, 0, cx, cy, cr_);
    cairo_pattern_add_color_stop_rgba(core, 0.0, 1, 1, 1, online ? 0.98 : 0.35);
    cairo_pattern_add_color_stop_rgba(core, 0.35, col.r * 0.6 + 0.4, col.g * 0.6 + 0.4, col.b * 0.6 + 0.4, online ? 0.95 : 0.3);
    cairo_pattern_add_color_stop_rgba(core, 1.0, col.r, col.g, col.b, 0.0);
    cairo_set_source(cr, core);
    cairo_arc(cr, cx, cy, cr_, 0, 2 * M_PI);
    cairo_fill(cr);
    cairo_pattern_destroy(core);
    // тонкий обод
    setc(cr, col, 0.9);
    cairo_set_line_width(cr, 2);
    cairo_arc(cr, cx, cy, R * 0.62, 0, 2 * M_PI);
    cairo_stroke(cr);
}

static std::string state_label() {
    if (!g_online) return "МИКРОФОН ВЫКЛЮЧЕН";
    switch (g_state.load()) {
        case LISTENING: return "СЛУШАЮ";
        case THINKING: return "ДУМАЮ";
        case SPEAKING: return "ГОВОРЮ";
        default: return "ГОТОВ";
    }
}

static void build_buttons(const Lay& L, double w, double h, cairo_t* cr) {
    g_btns.clear();
    struct D { int id; std::string t; Rgb c; };
    std::vector<D> d;
    if (L.mini) d = {{B_MIC, g_online ? "МИК" : "МИК ✕", g_online ? GREEN : STEEL}, {B_SET, "НАСТР.", CYAN}, {B_MODE, "РЕЖИМ", CYAN}, {B_EXIT, "ВЫХОД", RED}};
    else d = {{B_MIC, g_online ? "МИКРОФОН: ВКЛ" : "МИКРОФОН: ВЫКЛ", g_online ? GREEN : STEEL}, {B_SET, "НАСТРОЙКИ", CYAN}, {B_MODE, "РЕЖИМ", CYAN}, {B_CLEAR, "ОЧИСТИТЬ", CYAN}, {B_EXIT, "ВЫХОД", RED}};
    double bh = (L.mini ? 24 : 32) * L.s, gap = 8 * L.s, fs = (L.mini ? 11 : 13) * L.s;
    double x = w - 14 * L.s, y = (L.mini ? h - bh - 8 : 14 * L.s);
    if (L.mini) {  // в мини-режиме кнопки внизу слева направо
        x = 10;
        for (auto& b : d) { double bw = text_width(cr, b.t, fs, true) + 20 * L.s; g_btns.push_back({b.id, x, y, bw, bh, b.t, b.c}); x += bw + gap; }
        return;
    }
    for (auto it = d.rbegin(); it != d.rend(); ++it) {
        double bw = text_width(cr, it->t, fs, true) + 26 * L.s;
        x -= bw;
        g_btns.push_back({it->id, x, y, bw, bh, it->t, it->c});
        x -= gap;
    }
}

static gboolean on_draw(GtkWidget* wd, cairo_t* cr, gpointer) {
    double w = gtk_widget_get_allocated_width(wd), h = gtk_widget_get_allocated_height(wd);
    Lay L = layout_for(w, h);
    // фон
    cairo_pattern_t* bg = cairo_pattern_create_radial(w / 2, h * 0.4, 20, w / 2, h * 0.4, std::max(w, h) * 0.8);
    cairo_pattern_add_color_stop_rgb(bg, 0, 0.02, 0.09, 0.16);
    cairo_pattern_add_color_stop_rgb(bg, 1, 0.005, 0.015, 0.035);
    cairo_set_source(cr, bg);
    cairo_paint(cr);
    cairo_pattern_destroy(bg);
    // сетка
    setc(cr, CYAN, 0.045);
    cairo_set_line_width(cr, 1);
    double step = 46 * L.s;
    for (double x = std::fmod(g_phase * 6, step); x < w; x += step) { cairo_move_to(cr, x, 0); cairo_line_to(cr, x, h); }
    for (double y = 0; y < h; y += step) { cairo_move_to(cr, 0, y); cairo_line_to(cr, w, y); }
    cairo_stroke(cr);

    update_stats();
    draw_orb(cr, L);

    // заголовок
    double ty = L.mini ? 8 : 16 * L.s;
    if (!L.mini) {
        draw_text(cr, "F L E Y   A I", 22 * L.s, ty, 28 * L.s, ICE, 0.95, 0, -1, true);
        draw_text(cr, "СОЗДАТЕЛЬ: FLEY INDUSTRIES", 24 * L.s, ty + 36 * L.s, 11 * L.s, CYAN, 0.6, 0, -1, false, "Monospace");
    } else {
        draw_text(cr, "FLEY AI", 12, ty, 15, ICE, 0.95, 0, -1, true);
    }

    // панель системы слева
    if (!L.mini) {
        double px = 22 * L.s, py = 100 * L.s, pw = 220 * L.s, ph = 190 * L.s;
        brackets(cr, px - 8, py - 8, pw + 16, ph + 16, CYAN, 12 * L.s, 1.4, 0.7);
        draw_text(cr, "СИСТЕМА", px, py, 12 * L.s, CYAN, 0.9, 0, -1, true, "Monospace");
        char b[64];
        snprintf(b, sizeof b, "%.0f%%", g_cpu);
        bar(cr, px, py + 26 * L.s, pw, g_cpu / 100.0, CYAN, "ПРОЦЕССОР", b, L.s);
        snprintf(b, sizeof b, "%.0f%%", g_ram);
        bar(cr, px, py + 62 * L.s, pw, g_ram / 100.0, CYAN, "ПАМЯТЬ", b, L.s);
        if (g_bat >= 0) { snprintf(b, sizeof b, "%d%%", g_bat); bar(cr, px, py + 98 * L.s, pw, g_bat / 100.0, g_bat < 20 ? RED : GREEN, "БАТАРЕЯ", b, L.s); }
        time_t t = time(nullptr);
        struct tm tmv;
        localtime_r(&t, &tmv);
        strftime(b, sizeof b, "%H:%M:%S", &tmv);
        draw_text(cr, b, px, py + 138 * L.s, 24 * L.s, ICE, 0.95, 0, -1, true, "Monospace");
        strftime(b, sizeof b, "%d.%m.%Y", &tmv);
        draw_text(cr, b, px, py + 168 * L.s, 12 * L.s, CYAN, 0.7, 0, -1, false, "Monospace");
        // панель памяти справа
        double rx = w - 242 * L.s, rw = 220 * L.s;
        brackets(cr, rx - 8, py - 8, rw + 16, 96 * L.s + 16, CYAN, 12 * L.s, 1.4, 0.7);
        draw_text(cr, "ПАМЯТЬ ФЛЕЯ", rx, py, 12 * L.s, CYAN, 0.9, 0, -1, true, "Monospace");
        draw_text(cr, "фактов о вас: " + std::to_string(g_factCount.load()), rx, py + 26 * L.s, 12 * L.s, ICE, 0.85, 0, -1, false, "Monospace");
        draw_text(cr, std::string("управление ПК: ") + (g_set.pc ? "вкл" : "выкл"), rx, py + 48 * L.s, 12 * L.s, ICE, 0.85, 0, -1, false, "Monospace");
        draw_text(cr, std::string("модель: ") + utf8_truncate(g_set.model, 26), rx, py + 70 * L.s, 11 * L.s, ICE, 0.6, 0, -1, false, "Monospace");
    }

    // состояние и статус
    double sy = L.cy + L.R * 1.82;
    draw_text(cr, state_label(), L.cx, sy, 15 * L.s, g_online ? CYAN : STEEL, 0.95, 1, -1, true, "Monospace");
    bool err = false;
    std::string st = get_status(&err);
    draw_text(cr, st, L.cx - std::min(w * 0.4, 520 * L.s), sy + 24 * L.s, 13 * L.s, err ? RED : ICE, err ? 1.0 : 0.8, 1, std::min(w * 0.8, 1040 * L.s));

    // журнал
    brackets(cr, L.lx - 6, L.ly - 6, L.lw + 12, L.lh + 12, CYAN, 12 * L.s, 1.4, 0.6);
    cairo_save(cr);
    cairo_rectangle(cr, L.lx, L.ly, L.lw, L.lh);
    cairo_clip(cr);
    double yb = L.ly + L.lh + g_scrollPx;
    double total = 0;
    for (size_t i = g_logs.size(); i-- > 0;) {
        const LogEntry& e = g_logs[i];
        std::string pre = e.role == 0 ? "ВЫ ▸ " : e.role == 1 ? "FLEY ▸ " : e.role == 3 ? "! " : "⚙ ";
        Rgb c = e.role == 0 ? GREEN : e.role == 1 ? ICE : e.role == 3 ? RED : GOLD;
        double fs = 14 * L.s * (e.role == 2 ? 0.85 : 1.0);
        double eh = draw_text(cr, pre + e.text, L.lx + 8, 0, fs, c, 1, 0, L.lw - 16, false, "Sans", true);
        yb -= eh + 6 * L.s;
        total += eh + 6 * L.s;
        if (yb + eh < L.ly) { if (yb < L.ly - 2000) break; }
        draw_text(cr, pre + e.text, L.lx + 8, yb, fs, c, e.role == 2 ? 0.75 : 0.95, 0, L.lw - 16);
        if (yb < L.ly - 400) break;
    }
    (void)total;
    cairo_restore(cr);
    if (!L.mini) draw_text(cr, "Пробел или клик по ядру - микрофон    F11 - режим окна    Esc - выйти из полного экрана    Колесо - прокрутка журнала", w / 2, h - 24 * L.s, 11 * L.s, CYAN, 0.45, 1, -1, false, "Monospace");

    // кнопки
    build_buttons(L, w, h, cr);
    for (const Btn& b : g_btns) {
        bool hv = (g_hover == b.id);
        double r = 6 * L.s;
        cairo_new_sub_path(cr);
        cairo_arc(cr, b.x + b.w - r, b.y + r, r, -M_PI / 2, 0);
        cairo_arc(cr, b.x + b.w - r, b.y + b.h - r, r, 0, M_PI / 2);
        cairo_arc(cr, b.x + r, b.y + b.h - r, r, M_PI / 2, M_PI);
        cairo_arc(cr, b.x + r, b.y + r, r, M_PI, 3 * M_PI / 2);
        cairo_close_path(cr);
        setc(cr, b.col, hv ? 0.30 : 0.10);
        cairo_fill_preserve(cr);
        setc(cr, b.col, hv ? 1.0 : 0.65);
        cairo_set_line_width(cr, hv ? 2 : 1.2);
        cairo_stroke(cr);
        double fs = (L.mini ? 11 : 13) * L.s;
        draw_text(cr, b.text, b.x + b.w / 2, b.y + (b.h - fs * 1.25) / 2, fs, b.col, 1, 1, -1, true);
    }
    return FALSE;
}

// ---------------------------------------------------------------- режимы окна
static void persist_env(const std::string& key, const std::string& val) {
    ensure_env_file();
    write_file(env_path(), set_env_value(read_file(env_path()), key, val), true);
}
static void apply_mode(int m, bool persist) {
    g_mode = m;
    if (m == 0) {
        gtk_window_set_keep_above(GTK_WINDOW(g_win), FALSE);
        gtk_window_fullscreen(GTK_WINDOW(g_win));
    } else {
        gtk_window_unfullscreen(GTK_WINDOW(g_win));
        gtk_window_set_keep_above(GTK_WINDOW(g_win), m == 2);
        if (m == 1) gtk_window_resize(GTK_WINDOW(g_win), 1100, 720);
        else gtk_window_resize(GTK_WINDOW(g_win), 480, 360);
    }
    if (persist) persist_env("FLEY_WINDOW_MODE", m == 0 ? "full" : m == 1 ? "window" : "mini");
}

// ---------------------------------------------------------------- окно подтверждения (вызывается из потока диалога)
struct ConfirmReq { std::string what; bool result = false, done = false; std::mutex mx; std::condition_variable cv; };
static gboolean confirm_idle(gpointer p) {
    auto* sp = (std::shared_ptr<ConfirmReq>*)p;
    ConfirmReq& r = **sp;
    GtkWidget* d = gtk_message_dialog_new(GTK_WINDOW(g_win), GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_YES_NO, "FLEY просит подтверждения");
    gtk_message_dialog_format_secondary_text(GTK_MESSAGE_DIALOG(d), "%s", r.what.c_str());
    int resp = gtk_dialog_run(GTK_DIALOG(d));
    gtk_widget_destroy(d);
    { std::lock_guard<std::mutex> lk(r.mx); r.result = (resp == GTK_RESPONSE_YES); r.done = true; }
    r.cv.notify_all();
    delete sp;
    return FALSE;
}
static bool gui_confirm(const std::string& what) {
    auto req = std::make_shared<ConfirmReq>();
    req->what = what;
    g_idle_add(confirm_idle, new std::shared_ptr<ConfirmReq>(req));
    std::unique_lock<std::mutex> lk(req->mx);
    req->cv.wait_for(lk, std::chrono::seconds(90), [&] { return req->done; });
    return req->done && req->result;
}

// ---------------------------------------------------------------- настройки
static void set_autostart(bool on) {
    std::string dir = xdg_dir("XDG_CONFIG_HOME", ".config") + "/autostart";
    std::string f = dir + "/fley-ai.desktop";
    if (!on) { std::error_code ec; fs::remove(f, ec); return; }
    ensure_dir(dir);
    char exe[4096] = {};
    ssize_t n = readlink("/proc/self/exe", exe, sizeof exe - 1);
    std::string bin = n > 0 ? std::string(exe, (size_t)n) : "fley-ai";
    write_file(f, "[Desktop Entry]\nType=Application\nName=FLEY AI\nComment=Голосовой ИИ-помощник\nExec=\"" + bin + "\"\nIcon=fley-ai\nTerminal=false\nX-GNOME-Autostart-enabled=true\n");
}
static bool autostart_enabled() {
    std::error_code ec;
    return fs::exists(xdg_dir("XDG_CONFIG_HOME", ".config") + "/autostart/fley-ai.desktop", ec);
}

struct SettingsUi {
    GtkWidget *key, *call, *wake, *silence, *lang, *fx, *espeak, *piper, *gain, *mic, *mode, *confirm, *pc, *greet, *autostart;
};
static void on_paste_key(GtkButton*, gpointer p) {
    auto* u = (SettingsUi*)p;
    gchar* t = gtk_clipboard_wait_for_text(gtk_clipboard_get(GDK_SELECTION_CLIPBOARD));
    if (t) { std::string k = trim(t); g_free(t); gtk_entry_set_text(GTK_ENTRY(u->key), k.c_str()); }
}
static void on_create_key(GtkButton*, gpointer) { open_target("https://console.groq.com/keys"); }
static void on_show_key(GtkToggleButton* b, gpointer p) {
    gtk_entry_set_visibility(GTK_ENTRY(((SettingsUi*)p)->key), gtk_toggle_button_get_active(b));
}
static GtkWidget* combo_with(std::initializer_list<const char*> items, const std::string& active) {
    GtkWidget* c = gtk_combo_box_text_new();
    int idx = 0, sel = 0;
    for (const char* it : items) {
        gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(c), it);
        if (active == it) sel = idx;
        ++idx;
    }
    gtk_combo_box_set_active(GTK_COMBO_BOX(c), sel);
    return c;
}
static void open_settings() {
    static bool open = false;
    if (open) return;
    open = true;
    load_settings();
    SettingsUi u;
    GtkWidget* d = gtk_dialog_new_with_buttons("FLEY AI - настройки", GTK_WINDOW(g_win), GTK_DIALOG_MODAL, "Отмена", GTK_RESPONSE_CANCEL, "Сохранить", GTK_RESPONSE_OK, nullptr);
    gtk_window_set_default_size(GTK_WINDOW(d), 640, -1);
    GtkWidget* grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 8);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 12);
    gtk_container_set_border_width(GTK_CONTAINER(grid), 16);
    gtk_box_pack_start(GTK_BOX(gtk_dialog_get_content_area(GTK_DIALOG(d))), grid, TRUE, TRUE, 0);
    int row = 0;
    auto lab = [&](const char* t, GtkWidget* w) {
        GtkWidget* l = gtk_label_new(t);
        gtk_widget_set_halign(l, GTK_ALIGN_END);
        gtk_grid_attach(GTK_GRID(grid), l, 0, row, 1, 1);
        gtk_widget_set_hexpand(w, TRUE);
        gtk_grid_attach(GTK_GRID(grid), w, 1, row, 1, 1);
        ++row;
    };
    u.key = gtk_entry_new();
    gtk_entry_set_visibility(GTK_ENTRY(u.key), FALSE);
    gtk_entry_set_text(GTK_ENTRY(u.key), g_set.key.c_str());
    lab("API-ключ (Groq / OpenAI / OpenRouter)", u.key);
    GtkWidget* kb = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);
    GtkWidget* b1 = gtk_button_new_with_label("Вставить ключ из буфера");
    GtkWidget* b2 = gtk_button_new_with_label("Создать бесплатный ключ (Groq)");
    GtkWidget* b3 = gtk_check_button_new_with_label("Показать");
    g_signal_connect(b1, "clicked", G_CALLBACK(on_paste_key), &u);
    g_signal_connect(b2, "clicked", G_CALLBACK(on_create_key), nullptr);
    g_signal_connect(b3, "toggled", G_CALLBACK(on_show_key), &u);
    gtk_box_pack_start(GTK_BOX(kb), b1, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(kb), b2, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(kb), b3, FALSE, FALSE, 0);
    lab("", kb);
    u.call = gtk_entry_new(); gtk_entry_set_text(GTK_ENTRY(u.call), g_set.call_me.c_str()); lab("Как к вам обращаться (например: сэр)", u.call);
    u.wake = gtk_entry_new(); gtk_entry_set_text(GTK_ENTRY(u.wake), g_set.wake.c_str()); lab("Слово-активатор (пусто = отвечать на всё)", u.wake);
    u.silence = gtk_spin_button_new_with_range(0.4, 5.0, 0.1); gtk_spin_button_set_value(GTK_SPIN_BUTTON(u.silence), g_set.silence); lab("Пауза в конце фразы, секунды", u.silence);
    u.lang = combo_with({"ru", "uz", "en", "auto"}, g_set.stt_lang.empty() ? "auto" : g_set.stt_lang); lab("Язык речи", u.lang);
    u.fx = combo_with({"JARVIS", "РОБОТ", "ЧИСТЫЙ"}, g_set.fx_mode == 2 ? "РОБОТ" : g_set.fx_mode == 0 ? "ЧИСТЫЙ" : "JARVIS"); lab("Эффект голоса", u.fx);
    u.espeak = gtk_entry_new(); gtk_entry_set_text(GTK_ENTRY(u.espeak), env_get("FLEY_ESPEAK_VOICE").c_str()); lab("Голос espeak-ng (например ru+m3)", u.espeak);
    u.piper = gtk_entry_new(); gtk_entry_set_text(GTK_ENTRY(u.piper), env_get("FLEY_PIPER_MODEL").c_str()); lab("Нейро-голос Piper: путь к .onnx (по желанию)", u.piper);
    u.gain = gtk_spin_button_new_with_range(1, 20, 0.5); gtk_spin_button_set_value(GTK_SPIN_BUTTON(u.gain), g_set.mic_gain); lab("Усиление микрофона", u.gain);
    u.mic = gtk_entry_new(); gtk_entry_set_text(GTK_ENTRY(u.mic), g_set.mic_device.c_str()); lab("Микрофон: часть названия (пусто = по умолчанию)", u.mic);
    u.mode = combo_with({"full", "window", "mini"}, g_set.window_mode); lab("Режим окна (full / window / mini)", u.mode);
    u.pc = gtk_check_button_new_with_label("Управление компьютером голосом"); gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(u.pc), g_set.pc); lab("", u.pc);
    u.confirm = gtk_check_button_new_with_label("Спрашивать подтверждение (Да/Нет) для опасных действий"); gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(u.confirm), g_set.confirm); lab("", u.confirm);
    u.greet = gtk_check_button_new_with_label("Приветствие при запуске"); gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(u.greet), g_set.greeting); lab("", u.greet);
    u.autostart = gtk_check_button_new_with_label("Запускать вместе с системой"); gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(u.autostart), autostart_enabled()); lab("", u.autostart);
    gtk_widget_show_all(d);
    int resp = gtk_dialog_run(GTK_DIALOG(d));
    if (resp == GTK_RESPONSE_OK) {
        ensure_env_file();
        std::string env = read_file(env_path());
        auto put = [&](const char* k, const std::string& v, bool create = true) { env = set_env_value(env, k, v, create); };
        auto txt = [](GtkWidget* w) { return trim(gtk_entry_get_text(GTK_ENTRY(w))); };
        auto cb = [](GtkWidget* w) { gchar* t = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(w)); std::string s = t ? t : ""; g_free(t); return s; };
        auto on = [](GtkWidget* w) { return gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(w)) ? "1" : "0"; };
        std::string key = txt(u.key);
        if (!key.empty()) { put("GROQ_API_KEY", key); put("OPENAI_API_KEY", "", false); put("OPENROUTER_API_KEY", "", false); }
        put("FLEY_CALL_ME", txt(u.call));
        put("FLEY_WAKE", txt(u.wake));
        char b[32];
        snprintf(b, sizeof b, "%.1f", gtk_spin_button_get_value(GTK_SPIN_BUTTON(u.silence))); put("FLEY_SILENCE_SECONDS", b);
        put("FLEY_STT_LANG", cb(u.lang));
        std::string fx = cb(u.fx);
        put("FLEY_VOICE_FX", fx == "РОБОТ" ? "2" : fx == "ЧИСТЫЙ" ? "0" : "1");
        put("FLEY_ESPEAK_VOICE", txt(u.espeak));
        put("FLEY_PIPER_MODEL", txt(u.piper));
        snprintf(b, sizeof b, "%.1f", gtk_spin_button_get_value(GTK_SPIN_BUTTON(u.gain))); put("FLEY_MIC_GAIN", b);
        put("FLEY_MIC_DEVICE", txt(u.mic));
        put("FLEY_WINDOW_MODE", cb(u.mode));
        put("FLEY_PC_CONTROL", on(u.pc));
        put("FLEY_CONFIRM", on(u.confirm));
        put("FLEY_GREETING", on(u.greet));
        write_file(env_path(), env, true);
        set_autostart(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(u.autostart)));
        load_settings();
        g_micGain = 0;
        g_keyErr = false;
        g_reload = true;
        int wm = g_set.window_mode == "full" ? 0 : g_set.window_mode == "window" ? 1 : 2;
        if (wm != g_mode) apply_mode(wm, false);
        set_status("Настройки сохранены.");
    }
    gtk_widget_destroy(d);
    open = false;
}

// ---------------------------------------------------------------- события окна
static void orb_action() {
    if (g_state == SPEAKING) g_stopSpeak = true;
    else g_online = !g_online;
}
static void do_button(int id) {
    switch (id) {
        case B_MIC: orb_action(); break;
        case B_SET: open_settings(); break;
        case B_MODE: apply_mode((g_mode + 1) % 3, true); break;
        case B_CLEAR: g_logs.clear(); g_clearReq = true; set_status("Диалог очищен (память о вас сохранена)."); break;
        case B_EXIT: gtk_main_quit(); break;
    }
}
static int hit_button(double x, double y) {
    for (const Btn& b : g_btns) if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) return b.id;
    return -1;
}
static gboolean on_press(GtkWidget* wd, GdkEventButton* e, gpointer) {
    if (e->button != 1) return FALSE;
    int id = hit_button(e->x, e->y);
    if (id > 0) { do_button(id); return TRUE; }
    Lay L = layout_for(gtk_widget_get_allocated_width(wd), gtk_widget_get_allocated_height(wd));
    double dx = e->x - L.cx, dy = e->y - L.cy;
    if (dx * dx + dy * dy <= L.R * 1.6 * L.R * 1.6) orb_action();
    return TRUE;
}
static gboolean on_motion(GtkWidget* wd, GdkEventMotion* e, gpointer) {
    int h = hit_button(e->x, e->y);
    if (h != g_hover) {
        g_hover = h;
        GdkWindow* gw = gtk_widget_get_window(wd);
        if (gw) {
            GdkCursor* c = h > 0 ? gdk_cursor_new_from_name(gdk_window_get_display(gw), "pointer") : nullptr;
            gdk_window_set_cursor(gw, c);
            if (c) g_object_unref(c);
        }
    }
    return FALSE;
}
static gboolean on_scroll(GtkWidget*, GdkEventScroll* e, gpointer) {
    if (e->direction == GDK_SCROLL_UP) g_scrollPx += 60;
    else if (e->direction == GDK_SCROLL_DOWN) g_scrollPx -= 60;
    else if (e->direction == GDK_SCROLL_SMOOTH) g_scrollPx -= e->delta_y * 40;
    if (g_scrollPx < 0) g_scrollPx = 0;
    return TRUE;
}
static gboolean on_key(GtkWidget*, GdkEventKey* e, gpointer) {
    if (e->keyval == GDK_KEY_space) { orb_action(); return TRUE; }
    if (e->keyval == GDK_KEY_F11) { apply_mode((g_mode + 1) % 3, true); return TRUE; }
    if (e->keyval == GDK_KEY_Escape) { if (g_mode == 0) apply_mode(1, true); return TRUE; }
    if ((e->state & GDK_CONTROL_MASK) && (e->keyval == GDK_KEY_q || e->keyval == GDK_KEY_Q)) { gtk_main_quit(); return TRUE; }
    return FALSE;
}
static gboolean tick(gpointer) {
    g_phase += 0.033;
    double target = g_online ? g_level1000 / 1000.0 : 0.0;
    g_levelSmooth += (target - g_levelSmooth) * 0.35;
    if (g_showSettings.exchange(false)) { g_idle_add([](gpointer) -> gboolean { open_settings(); return FALSE; }, nullptr); }
    gtk_widget_queue_draw(g_area);
    return TRUE;
}
static gboolean add_log_idle(gpointer p) {
    auto* e = (LogEntry*)p;
    g_logs.push_back(*e);
    if (g_logs.size() > 300) g_logs.erase(g_logs.begin());
    g_scrollPx = 0;
    delete e;
    return FALSE;
}
static gboolean on_quit_signal(gpointer) { gtk_main_quit(); return G_SOURCE_REMOVE; }

static int run_gui(int argc, char** argv) {
    if (!gtk_init_check(&argc, &argv)) {
        fprintf(stderr, "Не удалось открыть графический экран (нет DISPLAY/WAYLAND_DISPLAY).\nЗапустите в терминале режим без окна: fley-ai --cli\n");
        return 3;
    }
    // один экземпляр: два помощника на одном микрофоне мешали бы друг другу
    ensure_dir(data_dir());
    int lockfd = open((data_dir() + "/fley.lock").c_str(), O_CREAT | O_RDWR, 0600);
    if (lockfd >= 0 && flock(lockfd, LOCK_EX | LOCK_NB) != 0) {
        GtkWidget* d = gtk_message_dialog_new(nullptr, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "FLEY AI уже запущен.");
        gtk_dialog_run(GTK_DIALOG(d));
        return 0;
    }
    g_win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(g_win), "FLEY AI");
    gtk_window_set_default_size(GTK_WINDOW(g_win), 1100, 720);
    gtk_window_set_default_icon_name("fley-ai");
    gtk_widget_set_app_paintable(g_win, TRUE);
    g_area = gtk_drawing_area_new();
    gtk_widget_add_events(g_area, GDK_BUTTON_PRESS_MASK | GDK_POINTER_MOTION_MASK | GDK_SCROLL_MASK | GDK_SMOOTH_SCROLL_MASK);
    gtk_container_add(GTK_CONTAINER(g_win), g_area);
    g_signal_connect(g_area, "draw", G_CALLBACK(on_draw), nullptr);
    g_signal_connect(g_area, "button-press-event", G_CALLBACK(on_press), nullptr);
    g_signal_connect(g_area, "motion-notify-event", G_CALLBACK(on_motion), nullptr);
    g_signal_connect(g_area, "scroll-event", G_CALLBACK(on_scroll), nullptr);
    g_signal_connect(g_win, "key-press-event", G_CALLBACK(on_key), nullptr);
    g_signal_connect(g_win, "destroy", G_CALLBACK(gtk_main_quit), nullptr);
    g_unix_signal_add(SIGINT, on_quit_signal, nullptr);
    g_unix_signal_add(SIGTERM, on_quit_signal, nullptr);

    ui_log = [](int role, const std::string& t) { g_idle_add(add_log_idle, new LogEntry{role, t}); };
    ui_confirm = gui_confirm;

    int wm = g_set.window_mode == "full" ? 0 : g_set.window_mode == "window" ? 1 : 2;
    gtk_widget_show_all(g_win);
    apply_mode(wm, false);
    g_timeout_add(33, tick, nullptr);

    std::thread session(session_thread);
    gtk_main();

    g_closing = true;
    session.detach();
    gtk_widget_hide(g_win);
    for (int i = 0; i < 15; ++i) msleep(50);  // даём потокам заметить выход
    _exit(0);
}

// ================================================================== main
int main(int argc, char** argv) {
    if (has_flag(argc, argv, "--help") || has_flag(argc, argv, "-h")) { fputs(kUsage, stdout); return 0; }
    if (has_flag(argc, argv, "--version")) { puts("FLEY AI " FLEY_VERSION); return 0; }
    g_verbose = has_flag(argc, argv, "--verbose");
    g_noSpeak = has_flag(argc, argv, "--no-speak");
    ensure_env_file();
    load_settings();
    if (has_flag(argc, argv, "--doctor")) return doctor();
    load_memory();
    load_history();
    std::string say = arg_value(argc, argv, "--say");
    if (!say.empty()) {
        try { g_noSpeak = false; speak_answer(say); }
        catch (const std::exception& e) { fprintf(stderr, "Ошибка голоса: %s\n", e.what()); return 1; }
        return 0;
    }
    std::string ask = arg_value(argc, argv, "--ask");
    if (!ask.empty()) return run_cli(true, ask);
    if (has_flag(argc, argv, "--cli")) return run_cli(false, "");
    return run_gui(argc, argv);
}
