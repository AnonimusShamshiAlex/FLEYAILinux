// FLEY AI для Linux: действия (управление компьютером голосом).
// Те же команды, что и в Windows-версии, но через Linux-инструменты: xdg-open, .desktop-файлы, wpctl/pactl,
// playerctl, loginctl, systemctl, xdotool/wtype, gio trash.
#pragma once
#include "platform.hpp"

#include <sys/statvfs.h>

#include <set>

struct ActResult { bool ok = false; std::string msg; bool feedback = false; };
inline ActResult Ok(const std::string& m, bool fb = false) { return {true, m, fb}; }
inline ActResult Fail(const std::string& m, bool fb = false) { return {false, m, fb}; }

// ---------------------------------------------------------------- память и история (файлы в ~/.local/share/fley-ai)
inline std::vector<std::string> g_facts;
inline std::vector<std::pair<std::string, std::string>> g_hist;
inline std::atomic<int> g_factCount{0};

inline std::string mem_path() { return data_dir() + "/fley_memory.txt"; }
inline std::string hist_path() { return data_dir() + "/fley_history.txt"; }

inline void load_memory() {
    g_facts.clear();
    std::stringstream ss(read_file(mem_path()));
    std::string line;
    while (std::getline(ss, line)) { line = trim(line); if (!line.empty()) g_facts.push_back(line); }
    g_factCount = (int)g_facts.size();
}
inline void save_memory() {
    std::string o;
    for (auto& f : g_facts) o += f + "\n";
    write_file(mem_path(), o, true);
    g_factCount = (int)g_facts.size();
}
inline std::string memory_block() {
    if (g_facts.empty()) return "";
    std::vector<std::string> pick;
    size_t total = 0;
    for (size_t i = g_facts.size(); i-- > 0;) {
        if (total + g_facts[i].size() > 2500) break;
        total += g_facts[i].size() + 3;
        pick.push_back(g_facts[i]);
    }
    std::string m = "\nДОЛГОВРЕМЕННАЯ ПАМЯТЬ (факты о пользователе, которые ты помнишь):\n";
    for (size_t i = pick.size(); i-- > 0;) m += "- " + pick[i] + "\n";
    return m;
}
inline ActResult ActRemember(const Action& a) {
    std::string f = a.args.empty() ? "" : trim(a.args[0]);
    for (char& c : f) if (c == '\n' || c == '\r') c = ' ';
    f = utf8_truncate(f, 300);
    if (f.empty()) return Fail("Пустой факт.");
    for (auto& x : g_facts) if (x == f) return Ok("Уже помню.");
    g_facts.push_back(f);
    if (g_facts.size() > 300) g_facts.erase(g_facts.begin());
    save_memory();
    return Ok("Запомнил: " + f);
}
inline ActResult ActForget(const Action& a) {
    std::string needle = lower_utf8(a.args.empty() ? "" : trim(a.args[0]));
    if (needle.empty()) return Fail("Не указано, что забыть.");
    size_t before = g_facts.size();
    std::vector<std::string> keep;
    for (auto& x : g_facts) if (lower_utf8(x).find(needle) == std::string::npos) keep.push_back(x);
    g_facts.swap(keep);
    save_memory();
    return Ok("Забыто записей: " + std::to_string(before - g_facts.size()));
}
inline std::string esc_line(const std::string& s) {
    std::string o;
    for (char c : s) { if (c == '\\') o += "\\\\"; else if (c == '\n') o += "\\n"; else if (c != '\r') o += c; }
    return o;
}
inline std::string unesc_line(const std::string& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '\\' && i + 1 < s.size()) { ++i; o += s[i] == 'n' ? '\n' : s[i]; }
        else o += s[i];
    }
    return o;
}
inline void save_history() {
    std::string o;
    size_t from = g_hist.size() > 40 ? g_hist.size() - 40 : 0;
    for (size_t i = from; i < g_hist.size(); ++i)
        o += std::string(g_hist[i].first == "user" ? "U\t" : "A\t") + esc_line(utf8_truncate(g_hist[i].second, 1500)) + "\n";
    write_file(hist_path(), o, true);
}
inline void load_history() {
    g_hist.clear();
    std::stringstream ss(read_file(hist_path()));
    std::string line;
    while (std::getline(ss, line))
        if (line.size() >= 2 && line[1] == '\t') g_hist.push_back({line[0] == 'U' ? "user" : "assistant", unesc_line(line.substr(2))});
    while (!g_hist.empty() && g_hist.front().first != "user") g_hist.erase(g_hist.begin());
}

// ---------------------------------------------------------------- пути
inline std::string user_dir(const std::string& key, const std::string& fallback) {
    std::stringstream ss(read_file(xdg_dir("XDG_CONFIG_HOME", ".config") + "/user-dirs.dirs"));
    std::string line, want = "XDG_" + key + "_DIR=";
    while (std::getline(ss, line)) {
        if (line.compare(0, want.size(), want) != 0) continue;
        std::string v = trim(line.substr(want.size()));
        if (v.size() >= 2 && v.front() == '"' && v.back() == '"') v = v.substr(1, v.size() - 2);
        size_t p = v.find("$HOME");
        if (p != std::string::npos) v.replace(p, 5, home_dir());
        if (!v.empty()) return v;
    }
    return home_dir() + "/" + fallback;
}

// Русские и английские названия стандартных папок -> реальный путь пользователя
inline std::string expand_path_arg(const std::string& arg_in) {
    std::string a = trim(arg_in);
    if (a.size() >= 2 && (a.front() == '"' || a.front() == '\'') && a.back() == a.front()) a = a.substr(1, a.size() - 2);
    for (char& c : a) if (c == '\\') c = '/';  // модель может написать путь в стиле Windows
    if (a == "~") return home_dir();
    if (a.compare(0, 2, "~/") == 0) return home_dir() + a.substr(1);
    if (!a.empty() && a[0] == '/') return a;
    struct Al { const char* name; const char* key; const char* fb; };
    static const Al al[] = {
        {"рабочий стол", "DESKTOP", "Desktop"}, {"desktop", "DESKTOP", "Desktop"},
        {"документы", "DOCUMENTS", "Documents"}, {"documents", "DOCUMENTS", "Documents"},
        {"загрузки", "DOWNLOAD", "Downloads"}, {"downloads", "DOWNLOAD", "Downloads"},
        {"изображения", "PICTURES", "Pictures"}, {"картинки", "PICTURES", "Pictures"}, {"фото", "PICTURES", "Pictures"}, {"pictures", "PICTURES", "Pictures"},
        {"музыка", "MUSIC", "Music"}, {"music", "MUSIC", "Music"},
        {"видео", "VIDEOS", "Videos"}, {"videos", "VIDEOS", "Videos"},
        {"домашняя папка", "", ""}, {"домой", "", ""}, {"home", "", ""},
    };
    std::string low = lower_utf8(a);
    for (const Al& x : al) {
        size_t n = std::strlen(x.name);
        if (low.compare(0, n, x.name) == 0 && (low.size() == n || low[n] == '/')) {
            std::string base = x.key[0] ? user_dir(x.key, x.fb) : home_dir();
            return low.size() == n ? base : base + a.substr(n);
        }
    }
    return home_dir() + "/" + a;
}

// Что нельзя удалять ни при каких обстоятельствах
inline std::string norm_path(const std::string& p) {
    std::error_code ec;
    fs::path c = fs::weakly_canonical(fs::path(p), ec);
    std::string s = ec ? p : c.string();
    while (s.size() > 1 && s.back() == '/') s.pop_back();
    return s;
}
inline bool is_protected_path_linux(const std::string& raw) {
    std::string p = norm_path(raw);
    if (p.empty() || p == "/") return true;
    static const char* roots[] = {"/bin", "/boot", "/dev", "/etc", "/lib", "/lib32", "/lib64", "/libx32", "/opt", "/proc", "/root",
                                  "/run", "/sbin", "/srv", "/sys", "/usr", "/var", "/snap", "/home", "/mnt", "/media", "/tmp"};
    for (const char* r : roots) {
        std::string rs = r;
        if (p == rs) return true;
        bool under = p.compare(0, rs.size() + 1, rs + "/") == 0;
        if (!under) continue;
        if (rs == "/home") { if (p.find('/', 6) == std::string::npos) return true; continue; }          // /home/<имя> целиком
        if (rs == "/mnt" || rs == "/media") { if (p.find('/', rs.size() + 1) == std::string::npos) return true; continue; }
        if (rs == "/tmp") continue;                                                                       // файлы в /tmp можно
        return true;                                                                                       // всё остальное системное
    }
    std::string h = home_dir();
    if (p == h) return true;
    static const char* userRoots[] = {".ssh", ".gnupg", ".config", ".local", ".mozilla", ".cache"};
    for (const char* u : userRoots) if (p == h + "/" + u) return true;
    for (const char* k : {"DESKTOP", "DOCUMENTS", "DOWNLOAD", "PICTURES", "MUSIC", "VIDEOS"})
        if (p == norm_path(user_dir(k, ""))) return true;
    return false;
}

// Файлы с секретами: ни читать, ни пересказывать (защита от утечки ключей через «прочитай файл»)
inline bool is_secret_path(const std::string& raw) {
    std::string p = norm_path(raw), h = home_dir();
    static const char* sub[] = {".ssh", ".gnupg", ".aws", ".azure", ".kube", ".docker", ".mozilla", ".config/google-chrome", ".config/chromium",
                                ".config/BraveSoftware", ".config/gcloud", ".config/fley-ai", ".local/share/keyrings", ".password-store", ".netrc"};
    for (const char* s : sub) {
        std::string full = h + "/" + s;
        if (p == full || p.compare(0, full.size() + 1, full + "/") == 0) return true;
    }
    if (p == "/etc/shadow" || p == "/etc/gshadow" || p.compare(0, 12, "/etc/sudoers") == 0) return true;
    std::string base = to_lower_ascii(fs::path(p).filename().string());
    if (base == ".env" || base.compare(0, 5, ".env.") == 0 || base == "id_rsa" || base == "id_ed25519" || base.find("secret") != std::string::npos) return true;
    return false;
}

// ---------------------------------------------------------------- подтверждение опасных действий
inline bool need_confirm() { return g_set.confirm || g_taint; }
inline bool confirm_action(const std::string& what) {
    if (!ui_confirm) return false;  // без интерфейса опасные действия не выполняем
    return ui_confirm(what);
}

// ---------------------------------------------------------------- запуск программ (.desktop)
struct DesktopEntry {
    std::string id, path, name, name_l, generic, keywords, exec, exec_base;
    bool terminal = false;
};
inline std::mutex g_deMx;
inline std::vector<DesktopEntry> g_entries;
inline long long g_entriesAt = 0;

inline std::vector<std::string> split_exec(const std::string& s) {
    std::vector<std::string> out;
    std::string cur;
    bool inq = false, any = false;
    char q = 0;
    for (size_t i = 0; i < s.size(); ++i) {
        char c = s[i];
        if (inq) {
            if (c == '\\' && i + 1 < s.size()) cur += s[++i];
            else if (c == q) inq = false;
            else cur += c;
        } else if (c == '"' || c == '\'') { inq = true; q = c; any = true; }
        else if (c == ' ' || c == '\t') { if (any || !cur.empty()) { out.push_back(cur); cur.clear(); any = false; } }
        else cur += c;
    }
    if (any || !cur.empty()) out.push_back(cur);
    return out;
}

inline void parse_desktop_file(const std::string& path, const std::string& id, std::vector<DesktopEntry>& out) {
    std::stringstream ss(read_file(path, 200000));
    std::string line;
    bool in = false, nodisplay = false, isapp = true;
    DesktopEntry e;
    e.path = path; e.id = id;
    std::string name_ru;
    while (std::getline(ss, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        if (line[0] == '[') { in = (line == "[Desktop Entry]"); continue; }
        if (!in) continue;
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq), v = line.substr(eq + 1);
        if (k == "Name") e.name = v;
        else if (k == "Name[ru]") name_ru = v;
        else if (k == "GenericName" || k == "GenericName[ru]") e.generic += " " + v;
        else if (k == "Keywords" || k == "Keywords[ru]") e.keywords += " " + v;
        else if (k == "Exec") e.exec = v;
        else if (k == "Terminal") e.terminal = (v == "true");
        else if (k == "NoDisplay" || k == "Hidden") nodisplay = nodisplay || v == "true";
        else if (k == "Type") isapp = (v == "Application");
    }
    if (nodisplay || !isapp || e.name.empty() || e.exec.empty()) return;
    e.name_l = lower_utf8(e.name + " " + name_ru);
    e.generic = lower_utf8(e.generic);
    e.keywords = lower_utf8(e.keywords);
    std::vector<std::string> av = split_exec(e.exec);
    if (!av.empty()) e.exec_base = to_lower_ascii(fs::path(av[0]).filename().string());
    out.push_back(e);
}

inline std::vector<DesktopEntry> desktop_entries() {
    std::lock_guard<std::mutex> lk(g_deMx);
    if (!g_entries.empty() && now_ms() - g_entriesAt < 60000) return g_entries;
    std::vector<std::string> dirs;
    dirs.push_back(xdg_dir("XDG_DATA_HOME", ".local/share") + "/applications");
    const char* xd = getenv("XDG_DATA_DIRS");
    std::stringstream ss(xd && *xd ? xd : "/usr/local/share:/usr/share");
    std::string d;
    while (std::getline(ss, d, ':')) if (!d.empty()) dirs.push_back(d + "/applications");
    dirs.push_back("/var/lib/flatpak/exports/share/applications");
    dirs.push_back(home_dir() + "/.local/share/flatpak/exports/share/applications");
    dirs.push_back("/var/lib/snapd/desktop/applications");
    std::vector<DesktopEntry> all;
    std::set<std::string> seen;
    for (const auto& dir : dirs) {
        std::error_code ec;
        if (!fs::is_directory(dir, ec)) continue;
        for (fs::recursive_directory_iterator it(dir, fs::directory_options::skip_permission_denied, ec), end; !ec && it != end; it.increment(ec)) {
            if (!it->is_regular_file(ec) || it->path().extension() != ".desktop") continue;
            std::string id = it->path().filename().string();
            if (!seen.insert(id).second) continue;  // первое найденное важнее (пользовательское перекрывает системное)
            parse_desktop_file(it->path().string(), id, all);
        }
    }
    g_entries = all;
    g_entriesAt = now_ms();
    return g_entries;
}

struct AppAlias { std::vector<std::string> keys, terms; };
inline const std::vector<AppAlias>& app_aliases() {
    static const std::vector<AppAlias> v = {
        {{"notepad", "блокнот", "текстовый редактор", "text editor", "gedit"}, {"text editor", "текстовый редактор", "gedit", "kate", "mousepad", "pluma", "xed", "kwrite"}},
        {{"calc", "calculator", "калькулятор"}, {"calculator", "калькулятор", "kcalc", "galculator", "mate-calc"}},
        {{"paint", "рисование", "paint"}, {"gimp", "krita", "drawing", "pinta", "kolourpaint"}},
        {{"taskmgr", "диспетчер задач", "task manager", "системный монитор", "монитор системы"}, {"system monitor", "системный монитор", "task manager", "resources", "ресурсы", "htop"}},
        {{"settings", "параметры", "настройки", "control panel", "панель управления"}, {"settings", "параметры", "настройки", "control center", "system settings"}},
        {{"chrome", "хром", "google chrome"}, {"google chrome", "chromium", "chrome"}},
        {{"edge", "эдж"}, {"microsoft edge"}},
        {{"firefox", "фаерфокс", "файрфокс"}, {"firefox"}},
        {{"code", "vscode", "vs code", "visual studio code", "вскод"}, {"visual studio code", "code", "vscodium"}},
        {{"word", "ворд"}, {"libreoffice writer", "writer", "onlyoffice documents"}},
        {{"excel", "эксель"}, {"libreoffice calc", "onlyoffice spreadsheets"}},
        {{"powerpoint", "презентация"}, {"libreoffice impress", "impress"}},
        {{"browser", "браузер", "интернет"}, {"firefox", "chromium", "google chrome", "brave", "vivaldi", "opera", "web"}},
        {{"telegram", "телеграм", "телеграмм", "телега"}, {"telegram"}},
        {{"spotify", "спотифай"}, {"spotify"}},
        {{"discord", "дискорд"}, {"discord"}},
        {{"steam", "стим"}, {"steam"}},
        {{"vlc", "влс"}, {"vlc"}},
        {{"camera", "камера"}, {"camera", "камера", "cheese", "snapshot"}},
        {{"music", "музыка", "плеер"}, {"music", "музыка", "rhythmbox", "lollypop", "elisa", "amberol", "spotify"}},
        {{"youtube", "ютуб", "ютюб"}, {"youtube"}},
    };
    return v;
}

inline bool open_terminal() {
    for (const char* t : {"x-terminal-emulator", "gnome-terminal", "kgx", "konsole", "xfce4-terminal", "mate-terminal", "tilix", "alacritty", "kitty", "wezterm", "foot", "xterm"})
        if (have_cmd(t)) return spawn_detached({t});
    return false;
}

inline bool launch_entry(const DesktopEntry& e) {
    if (have_cmd("gio")) {
        RunResult r = run_capture({"gio", "launch", e.path}, 8000);
        if (r.code == 0) return true;
    }
    if (have_cmd("gtk-launch")) {
        std::string id = e.id;
        if (id.size() > 8 && id.compare(id.size() - 8, 8, ".desktop") == 0) id.resize(id.size() - 8);
        if (spawn_detached({"gtk-launch", id})) return true;
    }
    std::vector<std::string> av;
    for (auto& t : split_exec(e.exec)) {
        if (t == "%%") av.push_back("%");
        else if (t.size() == 2 && t[0] == '%') continue;  // %u %f ...
        else av.push_back(t);
    }
    if (av.empty()) return false;
    if (e.terminal) {
        for (const char* t : {"x-terminal-emulator", "gnome-terminal", "konsole", "xfce4-terminal", "xterm"}) {
            if (!have_cmd(t)) continue;
            std::vector<std::string> w{t, std::string(t) == "gnome-terminal" ? "--" : "-e"};
            w.insert(w.end(), av.begin(), av.end());
            return spawn_detached(w);
        }
        return false;
    }
    return spawn_detached(av);
}

inline ActResult ActOpenApp(const std::string& arg_in) {
    std::string arg = trim(arg_in);
    if (arg.empty()) return Fail("Не указано, что открыть.");
    std::string q = lower_utf8(arg);
    if (q.size() > 4 && q.compare(q.size() - 4, 4, ".exe") == 0) q.resize(q.size() - 4);
    // особые случаи: терминал и файловый менеджер
    for (const char* k : {"терминал", "консоль", "cmd", "powershell", "terminal", "командная строка", "bash"})
        if (q == k) return open_terminal() ? Ok("Открыт терминал.") : Fail("Не нашёл терминал.");
    for (const char* k : {"проводник", "explorer", "файлы", "файловый менеджер", "files", "nautilus", "dolphin", "thunar"})
        if (q == k) return open_target(home_dir()) ? Ok("Открыт файловый менеджер.") : Fail("Не удалось открыть файловый менеджер.");

    std::vector<std::pair<std::string, int>> terms;  // (запрос, штраф)
    terms.push_back({q, 0});
    for (const auto& al : app_aliases())
        for (const auto& k : al.keys)
            if (q == k || q == lower_utf8(k)) for (const auto& t : al.terms) terms.push_back({t, 8});

    const DesktopEntry* best = nullptr;
    int bestScore = 0;
    std::vector<DesktopEntry> entries = desktop_entries();
    for (const DesktopEntry& e : entries) {
        std::string idl = to_lower_ascii(e.id);
        for (const auto& [t, pen] : terms) {
            int sc = 0;
            if (e.name_l == t) sc = 100;
            else if (e.exec_base == t || idl == t + ".desktop") sc = 95;
            else if (e.name_l.compare(0, t.size(), t) == 0) sc = 80;
            else if (e.name_l.find(t) != std::string::npos) sc = 65;
            else if (idl.find(t) != std::string::npos || e.exec_base.find(t) != std::string::npos) sc = 55;
            else if (e.keywords.find(t) != std::string::npos) sc = 45;
            else if (e.generic.find(t) != std::string::npos) sc = 40;
            sc -= sc ? pen : 0;
            if (sc > bestScore) { bestScore = sc; best = &e; }
        }
    }
    if (best && bestScore >= 40) {
        if (launch_entry(*best)) return Ok("Запущено: " + arg);
        return Fail("Не удалось запустить «" + arg + "».");
    }
    // запасной путь: имя команды в PATH
    bool safe = !q.empty();
    for (unsigned char c : q) if (!(isalnum(c) || c == '-' || c == '_' || c == '.')) safe = false;
    if (safe && have_cmd(q) && spawn_detached({q})) return Ok("Запущено: " + arg);
    return Fail("Не нашёл программу «" + arg + "» среди установленных.");
}

// ---------------------------------------------------------------- YouTube и веб
inline bool valid_video_id(const std::string& id) {
    if (id.size() != 11) return false;
    for (unsigned char c : id) if (!(isalnum(c) || c == '-' || c == '_')) return false;
    return true;
}
inline std::string first_video_id(const std::string& page) {
    static const char* marks[] = {"\"videoRenderer\":{\"videoId\":\"", "\"videoId\":\"", "/watch?v="};
    for (const char* m : marks) {
        size_t from = 0, ml = std::strlen(m);
        for (int tries = 0; tries < 8; ++tries) {
            size_t p = page.find(m, from);
            if (p == std::string::npos) break;
            std::string id = page.substr(p + ml, 11);
            if (valid_video_id(id)) return id;
            from = p + ml;
        }
    }
    return "";
}
inline ActResult ActYouTube(const std::string& query, bool play) {
    if (trim(query).empty()) return open_target("https://www.youtube.com") ? Ok("Открыт YouTube.") : Fail("Не удалось открыть YouTube.");
    std::string q = url_encode(trim(query));
    if (play) {
        std::string id = first_video_id(http_get_page("www.youtube.com", "/results?search_query=" + q + "&sp=EgIQAQ%3D%3D&hl=ru"));
        if (id.empty()) id = first_video_id(http_get_page("www.youtube.com", "/results?search_query=" + q));
        if (id.empty()) {  // запасной путь: поисковик
            std::string page = http_get_page("html.duckduckgo.com", "/html/?q=site%3Ayoutube.com%2Fwatch+" + q);
            size_t p = page.find("youtube.com%2Fwatch%3Fv%3D");
            if (p != std::string::npos && valid_video_id(page.substr(p + 26, 11))) id = page.substr(p + 26, 11);
        }
        if (!id.empty() && open_target("https://www.youtube.com/watch?v=" + id + "&autoplay=1")) {
            g_ensurePlay = true;  // после ответа проверим, что звук пошёл, и при необходимости нажмём Play
            return Ok("Включено видео по запросу: " + trim(query));
        }
    }
    if (open_target("https://www.youtube.com/results?search_query=" + q))
        return Ok(play ? "Автоматически выбрать видео не удалось, открыт список результатов: " + trim(query) : "Открыт поиск на YouTube: " + trim(query));
    return Fail("Не удалось открыть YouTube.");
}

inline std::string strip_tags(const std::string& s) {
    std::string o;
    bool tag = false;
    for (char c : s) { if (c == '<') tag = true; else if (c == '>') tag = false; else if (!tag) o += c; }
    static const char* ent[][2] = {{"&amp;", "&"}, {"&quot;", "\""}, {"&#x27;", "'"}, {"&#39;", "'"}, {"&lt;", "<"}, {"&gt;", ">"}, {"&nbsp;", " "}};
    for (auto& e : ent) {
        size_t p;
        while ((p = o.find(e[0])) != std::string::npos) o.replace(p, std::strlen(e[0]), e[1]);
    }
    return trim(o);
}
inline ActResult ActWebSearch(const std::string& q) {
    if (trim(q).empty()) return Fail("Пустой запрос.", true);
    std::string page = http_get_page("html.duckduckgo.com", "/html/?q=" + url_encode(trim(q)));
    std::string m;
    size_t pos = 0;
    int n = 0;
    while (n < 6) {
        size_t a = page.find("class=\"result__a\"", pos);
        if (a == std::string::npos) break;
        size_t ta = page.find('>', a), te = page.find("</a>", ta == std::string::npos ? a : ta);
        if (ta == std::string::npos || te == std::string::npos) break;
        std::string title = strip_tags(page.substr(ta + 1, te - ta - 1));
        std::string snip;
        size_t sa = page.find("class=\"result__snippet\"", te);
        size_t nextRes = page.find("class=\"result__a\"", te);
        if (sa != std::string::npos && (nextRes == std::string::npos || sa < nextRes)) {
            size_t sb = page.find('>', sa), se = page.find("</a>", sb == std::string::npos ? sa : sb);
            if (sb != std::string::npos && se != std::string::npos) snip = strip_tags(page.substr(sb + 1, se - sb - 1));
            pos = se == std::string::npos ? te : se;
        } else pos = te;
        ++n;
        m += std::to_string(n) + ". " + title + (snip.empty() ? "" : " - " + snip) + "\n";
    }
    if (m.empty()) return Fail("Поиск в интернете ничего не вернул (возможно, сайт недоступен). Предложи открыть поиск в браузере.", true);
    return Ok("Результаты поиска по «" + trim(q) + "»:\n" + utf8_truncate(m, 3500), true);
}

// ---------------------------------------------------------------- файлы
inline void search_files(const fs::path& dir, const std::string& needle, int depth, long long deadline, std::vector<std::string>& out) {
    std::error_code ec;
    if (depth < 0 || out.size() >= 15 || now_ms() > deadline) return;
    for (fs::directory_iterator it(dir, fs::directory_options::skip_permission_denied, ec), end; !ec && it != end; it.increment(ec)) {
        if (out.size() >= 15 || now_ms() > deadline) return;
        std::string nm = it->path().filename().string();
        if (nm.empty() || nm[0] == '.' || nm == "node_modules" || nm == "__pycache__") continue;
        if (lower_utf8(nm).find(needle) != std::string::npos) out.push_back(it->path().string());
        std::error_code e2;
        if (it->is_directory(e2) && !it->is_symlink(e2)) search_files(it->path(), needle, depth - 1, deadline, out);
    }
}
inline ActResult ActFindFile(const Action& a) {
    if (a.args.empty() || trim(a.args[0]).empty()) return Fail("Не указано, что искать.", true);
    std::string needle = lower_utf8(trim(a.args[0]));
    std::string base = a.args.size() > 1 && !trim(a.args[1]).empty() ? expand_path_arg(a.args[1]) : home_dir();
    std::vector<std::string> out;
    search_files(base, needle, 6, now_ms() + 6000, out);
    if (out.empty()) return Ok("Ничего не найдено по «" + trim(a.args[0]) + "» в " + base + ".", true);
    std::string m = "Найдено:\n";
    for (auto& s : out) m += s + "\n";
    return Ok(utf8_truncate(m, 3500), true);
}
inline ActResult ActReadFile(const Action& a) {
    if (a.args.empty()) return Fail("Не указан файл.", true);
    std::string p = expand_path_arg(a.args[0]);
    std::error_code ec;
    if (!fs::is_regular_file(p, ec)) return Fail("Файл не найден: " + p, true);
    if (is_secret_path(p)) return Fail("Этот файл содержит секреты (ключи, пароли), читать его я не буду.", true);
    std::string ext = to_lower_ascii(fs::path(p).extension().string());
    static const char* ok[] = {".txt", ".md", ".log", ".csv", ".json", ".xml", ".ini", ".cfg", ".conf", ".yaml", ".yml", ".cpp", ".h", ".hpp", ".c",
                               ".py", ".js", ".ts", ".html", ".css", ".sh", ".rs", ".go", ".java", ".toml", ".tex", ".srt", ""};
    bool allowed = false;
    for (auto e : ok) if (ext == e) allowed = true;
    if (!allowed) return Fail("Читать можно только текстовые файлы (txt, md, json, код и т.п.), а это: " + ext, true);
    std::string buf = read_file(p, 8000);
    if (buf.find('\0') != std::string::npos) return Fail("Это двоичный файл, а не текст.", true);
    return Ok("Начало файла " + p + ":\n" + utf8_truncate(buf, 6000), true);
}
inline ActResult ActListDir(const Action& a) {
    std::string p = a.args.empty() ? home_dir() : expand_path_arg(a.args[0]);
    std::error_code ec;
    if (!fs::is_directory(p, ec)) return Fail("Папка не найдена: " + p, true);
    std::vector<std::string> names;
    for (fs::directory_iterator it(p, fs::directory_options::skip_permission_denied, ec), end; !ec && it != end; it.increment(ec)) {
        std::error_code e2;
        names.push_back(it->path().filename().string() + (it->is_directory(e2) ? "/" : ""));
        if (names.size() >= 80) break;
    }
    std::sort(names.begin(), names.end());
    std::string m = "Содержимое " + p + " (" + std::to_string(names.size()) + "):\n";
    for (auto& n : names) m += n + "\n";
    return Ok(utf8_truncate(m, 3500), true);
}
inline ActResult ActOpenPath(const Action& a) {
    if (a.args.empty()) return Fail("Не указан путь.");
    std::string p = expand_path_arg(a.args[0]);
    std::error_code ec;
    if (!fs::exists(p, ec)) return Fail("Нет такого файла или папки: " + p);
    return open_target(p) ? Ok("Открыто: " + p) : Fail("Не удалось открыть: " + p);
}

// ---------------------------------------------------------------- состояние компьютера
struct CpuTimes { unsigned long long idle = 0, total = 0; };
inline CpuTimes read_cpu_times() {
    CpuTimes t;
    std::stringstream ss(read_file("/proc/stat", 4096));
    std::string cpu;
    unsigned long long v[8] = {};
    ss >> cpu;
    for (auto& x : v) ss >> x;
    t.idle = v[3] + v[4];
    for (auto x : v) t.total += x;
    return t;
}
inline double ram_percent() {
    std::stringstream ss(read_file("/proc/meminfo", 8192));
    std::string k, unit;
    unsigned long long val, total = 0, avail = 0;
    while (ss >> k >> val >> unit) { if (k == "MemTotal:") total = val; else if (k == "MemAvailable:") avail = val; }
    return total ? 100.0 * (double)(total - avail) / (double)total : 0.0;
}
inline int battery_percent(std::string* status = nullptr) {
    std::error_code ec;
    for (fs::directory_iterator it("/sys/class/power_supply", ec), end; !ec && it != end; it.increment(ec)) {
        std::string nm = it->path().filename().string();
        if (nm.compare(0, 3, "BAT") != 0) continue;
        std::string cap = trim(read_file(it->path().string() + "/capacity", 16));
        if (status) *status = trim(read_file(it->path().string() + "/status", 32));
        if (!cap.empty()) return std::atoi(cap.c_str());
    }
    return -1;
}
inline std::string os_name() {
    std::stringstream ss(read_file("/etc/os-release", 4096));
    std::string line;
    while (std::getline(ss, line))
        if (line.compare(0, 12, "PRETTY_NAME=") == 0) {
            std::string v = line.substr(12);
            if (v.size() >= 2 && v.front() == '"') v = v.substr(1, v.size() - 2);
            return v;
        }
    return "Linux";
}
inline std::string host_name() {
    char h[256] = {};
    gethostname(h, sizeof h - 1);
    return h;
}
inline std::string user_name() {
    const char* u = getenv("USER");
    return (u && *u) ? u : "user";
}

inline ActResult ActSysInfo() {
    CpuTimes a = read_cpu_times();
    msleep(400);
    CpuTimes b = read_cpu_times();
    double cpu = (b.total > a.total) ? 100.0 * (double)((b.total - a.total) - (b.idle - a.idle)) / (double)(b.total - a.total) : 0.0;
    char buf[400];
    std::string m = "Система: " + os_name() + ", компьютер " + host_name() + ".\n";
    snprintf(buf, sizeof buf, "Процессор: загрузка %.0f%%. Оперативная память: занято %.0f%%.\n", cpu, ram_percent());
    m += buf;
    struct statvfs sv;
    if (statvfs(home_dir().c_str(), &sv) == 0) {
        double freeG = (double)sv.f_bavail * (double)sv.f_frsize / 1e9, totG = (double)sv.f_blocks * (double)sv.f_frsize / 1e9;
        snprintf(buf, sizeof buf, "Диск (домашняя папка): свободно %.0f ГБ из %.0f ГБ.\n", freeG, totG);
        m += buf;
    }
    std::string st;
    int bat = battery_percent(&st);
    if (bat >= 0) m += "Батарея: " + std::to_string(bat) + "% (" + (st == "Charging" ? "заряжается" : st == "Discharging" ? "разряжается" : st == "Full" ? "полная" : st) + ").\n";
    double up = std::atof(read_file("/proc/uptime", 64).c_str());
    snprintf(buf, sizeof buf, "Работает без перезагрузки: %d ч %d мин.\n", (int)(up / 3600), (int)std::fmod(up / 60, 60));
    m += buf;
    return Ok(m, true);
}

// ---------------------------------------------------------------- громкость, медиа, блокировка
inline ActResult ActVolume(const Action& a) {
    std::string d = to_lower_ascii(a.args.empty() ? "" : trim(a.args[0]));
    int lvl = a.args.size() > 1 ? std::atoi(a.args[1].c_str()) : 50;
    lvl = std::max(0, std::min(150, lvl));
    std::string n = std::to_string(lvl);
    bool ok = false;
    if (have_cmd("wpctl")) {
        const char* sink = "@DEFAULT_AUDIO_SINK@";
        RunResult r;
        if (d == "up") r = run_capture({"wpctl", "set-volume", "-l", "1.5", sink, "10%+"}, 3000);
        else if (d == "down") r = run_capture({"wpctl", "set-volume", sink, "10%-"}, 3000);
        else if (d == "mute") r = run_capture({"wpctl", "set-mute", sink, "toggle"}, 3000);
        else if (d == "set") r = run_capture({"wpctl", "set-volume", "-l", "1.5", sink, n + "%"}, 3000);
        else return Fail("Неизвестная команда громкости: " + d);
        ok = r.code == 0;
    }
    if (!ok && have_cmd("pactl")) {
        RunResult r;
        if (d == "up") r = run_capture({"pactl", "set-sink-volume", "@DEFAULT_SINK@", "+10%"}, 3000);
        else if (d == "down") r = run_capture({"pactl", "set-sink-volume", "@DEFAULT_SINK@", "-10%"}, 3000);
        else if (d == "mute") r = run_capture({"pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"}, 3000);
        else r = run_capture({"pactl", "set-sink-volume", "@DEFAULT_SINK@", n + "%"}, 3000);
        ok = r.code == 0;
    }
    if (!ok && have_cmd("amixer")) {
        RunResult r;
        if (d == "up") r = run_capture({"amixer", "-q", "sset", "Master", "10%+"}, 3000);
        else if (d == "down") r = run_capture({"amixer", "-q", "sset", "Master", "10%-"}, 3000);
        else if (d == "mute") r = run_capture({"amixer", "-q", "sset", "Master", "toggle"}, 3000);
        else r = run_capture({"amixer", "-q", "sset", "Master", n + "%"}, 3000);
        ok = r.code == 0;
    }
    return ok ? Ok("Громкость изменена.") : Fail("Не удалось изменить громкость: нужен wpctl (PipeWire) или pactl.");
}

inline bool keyboard_key(const std::string& xkey);  // ниже

inline ActResult ActMedia(const Action& a) {
    std::string d = to_lower_ascii(a.args.empty() ? "" : trim(a.args[0]));
    const char* pc = d == "next" ? "next" : (d == "prev" || d == "previous") ? "previous" : d == "stop" ? "stop" : "play-pause";
    if (have_cmd("playerctl") && run_capture({"playerctl", pc}, 3000).code == 0) return Ok("Готово.");
    const char* xk = d == "next" ? "XF86AudioNext" : (d == "prev" || d == "previous") ? "XF86AudioPrev" : d == "stop" ? "XF86AudioStop" : "XF86AudioPlay";
    if (keyboard_key(xk)) return Ok("Готово.");
    return Fail("Не удалось управлять плеером: установите playerctl.");
}

inline ActResult ActLock() {
    if (have_cmd("loginctl") && run_capture({"loginctl", "lock-session"}, 4000).code == 0) return Ok("Компьютер заблокирован.");
    if (have_cmd("xdg-screensaver") && run_capture({"xdg-screensaver", "lock"}, 4000).code == 0) return Ok("Компьютер заблокирован.");
    if (have_cmd("gnome-screensaver-command") && run_capture({"gnome-screensaver-command", "-l"}, 4000).code == 0) return Ok("Компьютер заблокирован.");
    if (have_cmd("dm-tool") && run_capture({"dm-tool", "lock"}, 4000).code == 0) return Ok("Компьютер заблокирован.");
    return Fail("Не удалось заблокировать экран.");
}

// ---------------------------------------------------------------- клавиатура: X11 (xdotool) и Wayland (wtype / ydotool)
inline bool is_wayland() {
    const char* t = getenv("XDG_SESSION_TYPE");
    return (t && std::string(t) == "wayland") || (getenv("WAYLAND_DISPLAY") && !getenv("DISPLAY"));
}
inline std::string map_key_name(const std::string& k_in) {
    std::string k = to_lower_ascii(trim(k_in));
    static const std::map<std::string, std::string> m = {
        {"enter", "Return"}, {"return", "Return"}, {"esc", "Escape"}, {"escape", "Escape"}, {"tab", "Tab"}, {"space", "space"},
        {"backspace", "BackSpace"}, {"delete", "Delete"}, {"del", "Delete"}, {"up", "Up"}, {"down", "Down"}, {"left", "Left"}, {"right", "Right"},
        {"pageup", "Prior"}, {"pagedown", "Next"}, {"home", "Home"}, {"end", "End"}, {"insert", "Insert"},
        {"win", "super"}, {"windows", "super"}, {"super", "super"}, {"meta", "super"}, {"ctrl", "ctrl"}, {"control", "ctrl"}, {"alt", "alt"}, {"shift", "shift"},
    };
    auto it = m.find(k);
    if (it != m.end()) return it->second;
    if (k.size() >= 2 && k[0] == 'f' && isdigit((unsigned char)k[1])) return k;  // f1..f12 (xdotool принимает F5 и f5)
    return k;
}
inline bool is_modifier(const std::string& k) { return k == "ctrl" || k == "alt" || k == "shift" || k == "super"; }

inline bool keyboard_key(const std::string& xkey) {
    if (is_wayland()) {
        if (have_cmd("wtype")) {
            std::vector<std::string> av{"wtype"};
            std::vector<std::string> mods, keys;
            std::stringstream ss(xkey);
            std::string tok;
            while (std::getline(ss, tok, '+')) { std::string n = map_key_name(tok); (is_modifier(n) ? mods : keys).push_back(n); }
            for (auto& m : mods) { av.push_back("-M"); av.push_back(m == "super" ? "logo" : m); }
            for (auto& k : keys) { av.push_back("-k"); av.push_back(k); }
            for (auto it = mods.rbegin(); it != mods.rend(); ++it) { av.push_back("-m"); av.push_back(*it == "super" ? "logo" : *it); }
            return run_capture(av, 4000).code == 0;
        }
    }
    if (have_cmd("xdotool")) return run_capture({"xdotool", "key", "--clearmodifiers", xkey}, 4000).code == 0;
    return false;
}

inline ActResult ActKey(const std::string& spec) {
    if (trim(spec).empty()) return Fail("Не указаны клавиши.");
    std::string out;
    std::stringstream ss(spec);
    std::string tok;
    while (std::getline(ss, tok, '+')) out += (out.empty() ? "" : "+") + map_key_name(tok);
    if (keyboard_key(out)) return Ok("Нажато: " + spec);
    return Fail(is_wayland() ? "Не могу нажимать клавиши в Wayland: установите wtype (или ydotool)." : "Не могу нажимать клавиши: установите xdotool.");
}
inline ActResult ActType(const std::string& text) {
    if (text.empty()) return Fail("Нечего печатать.");
    std::string t = utf8_truncate(text, 1000);
    if (is_wayland() && have_cmd("wtype")) return run_capture({"wtype", "--", t}, 15000).code == 0 ? Ok("Напечатано.") : Fail("wtype не смог напечатать текст.");
    if (is_wayland() && have_cmd("ydotool")) return run_capture({"ydotool", "type", t}, 15000).code == 0 ? Ok("Напечатано.") : Fail("ydotool не смог напечатать текст.");
    if (have_cmd("xdotool")) return run_capture({"xdotool", "type", "--delay", "12", "--", t}, 20000).code == 0 ? Ok("Напечатано.") : Fail("xdotool не смог напечатать текст.");
    return Fail("Не могу печатать: установите xdotool (X11) или wtype (Wayland).");
}

// ---------------------------------------------------------------- команда, удаление, закрытие, питание
inline ActResult ActRun(const Action& a) {
    if (a.args.empty() || trim(a.args[0]).empty()) return Fail("Пустая команда.", true);
    std::string cmd = trim(a.args[0]);
    if (need_confirm() && !confirm_action("Выполнить команду:\n" + utf8_truncate(cmd, 300))) return Fail("Пользователь отклонил команду.", true);
    RunResult r = run_shell(cmd, 30000);
    std::string out = trim(utf8_truncate(r.out, 3000));
    if (r.timeout) return Fail("Команда не уложилась в 30 секунд и остановлена. " + out, true);
    return Ok("Код возврата " + std::to_string(r.code) + (out.empty() ? "." : ". Вывод:\n" + out), true);
}
inline ActResult ActDelete(const Action& a) {
    if (a.args.empty() || trim(a.args[0]).empty()) return Fail("Не указан путь.");
    std::string p = expand_path_arg(a.args[0]);
    std::error_code ec;
    if (!fs::exists(p, ec)) return Fail("Нет такого файла или папки: " + p);
    if (is_protected_path_linux(p)) return Fail("Эту папку удалять нельзя: " + p);
    if (need_confirm() && !confirm_action("Переместить в Корзину:\n" + p)) return Fail("Пользователь отклонил удаление.");
    if (have_cmd("gio") && run_capture({"gio", "trash", "--", p}, 15000).code == 0) return Ok("Перемещено в Корзину: " + p);
    if (have_cmd("trash-put") && run_capture({"trash-put", "--", p}, 15000).code == 0) return Ok("Перемещено в Корзину: " + p);
    return Fail("Не удалось переместить в Корзину (нужен gio из пакета glib/gvfs или trash-cli). Файл не тронут.");
}
inline std::string safe_proc_name(std::string n) {
    n = trim(n);
    if (n.size() > 4 && to_lower_ascii(n.substr(n.size() - 4)) == ".exe") n.resize(n.size() - 4);
    std::string o;
    for (unsigned char c : n) if (isalnum(c) || c == '.' || c == '_' || c == '-' || c == '+') o += (char)c;
    return o.size() > 15 ? o.substr(0, 15) : o;  // имя процесса в ядре ограничено 15 символами
}
inline ActResult ActCloseApp(const Action& a) {
    std::string n = safe_proc_name(a.args.empty() ? "" : a.args[0]);
    if (n.empty()) return Fail("Не указано, какую программу закрыть.");
    static const char* never[] = {"systemd", "init", "dbus-daemon", "gdm", "gdm3", "sddm", "lightdm", "Xorg", "Xwayland", "gnome-shell", "plasmashell", "pipewire", "pulseaudio", "sshd", "login"};
    for (const char* x : never) if (to_lower_ascii(n) == to_lower_ascii(x)) return Fail("Системный процесс закрывать нельзя: " + n);
    if (need_confirm() && !confirm_action("Закрыть программу: " + n)) return Fail("Пользователь отклонил закрытие.");
    RunResult r = run_capture({"pkill", "-u", std::to_string(getuid()), "-x", n}, 5000);
    if (r.code == 0) return Ok("Закрыто: " + n);
    if (r.code == 1) return Fail("Процесс «" + n + "» не найден (имя процесса может отличаться от названия программы).");
    return Fail("Не удалось закрыть: " + n);
}

inline std::atomic<int> g_powerGen{0};
inline ActResult ActPower(const Action& a) {
    std::string m = to_lower_ascii(a.args.empty() ? "" : trim(a.args[0]));
    if (m == "cancel") { ++g_powerGen; return Ok("Выключение отменено.", true); }
    if (m != "shutdown" && m != "restart" && m != "sleep" && m != "logoff") return Fail("Неизвестный режим питания: " + m);
    if (need_confirm() && !confirm_action("Питание компьютера: " + m)) return Fail("Пользователь отклонил действие.");
    if (m == "sleep") return run_capture({"systemctl", "suspend"}, 8000).code == 0 ? Ok("Засыпаю.") : Fail("Не удалось уснуть.");
    if (m == "logoff") return run_capture({"loginctl", "terminate-user", user_name()}, 8000).code == 0 ? Ok("Выход из сеанса.") : Fail("Не удалось выйти из сеанса.");
    int gen = ++g_powerGen;
    bool reboot = (m == "restart");
    std::thread([gen, reboot] {
        for (int i = 0; i < 300 && !g_closing; ++i) { msleep(100); if (g_powerGen != gen) return; }  // 30 секунд на отмену
        if (g_closing || g_powerGen != gen) return;
        if (run_capture({"systemctl", reboot ? "reboot" : "poweroff"}, 15000).code != 0)
            run_capture({"shutdown", reboot ? "-r" : "-h", "now"}, 15000);
    }).detach();
    return Ok(std::string(reboot ? "Перезагрузка" : "Выключение") + " через 30 секунд. Скажите «отмени выключение», чтобы отменить.");
}

// ---------------------------------------------------------------- напоминания и таймеры
inline std::mutex g_remMx;
inline std::vector<std::string> g_remDue;
inline ActResult ActTimer(const Action& a) {
    double min = a.args.empty() ? 0 : std::atof(a.args[0].c_str());
    if (min <= 0 || min > 24 * 60) return Fail("Укажите время от 1 секунды до 24 часов (в минутах).");
    std::string what = a.args.size() > 1 ? trim(a.args[1]) : "Время вышло";
    if (what.empty()) what = "Время вышло";
    double sec = min * 60.0;
    std::thread([sec, what] {
        long long until = now_ms() + (long long)(sec * 1000.0);
        while (now_ms() < until && !g_closing) msleep(250);
        if (g_closing) return;
        std::lock_guard<std::mutex> lk(g_remMx);
        g_remDue.push_back(what);
        g_remFlag = true;
    }).detach();
    return Ok("Таймер поставлен на " + std::to_string((int)std::lround(sec)) + " с: " + what);
}
inline ActResult ActWait(const std::string& ms) {
    int n = std::max(0, std::min(std::atoi(ms.c_str()), 10000));
    for (int i = 0; i < n && !g_closing; i += 50) msleep(50);
    return Ok("Подождал.");
}

// ---------------------------------------------------------------- «включи песню»: проверяем, что звук пошёл
inline bool audio_playing() {
    RunResult r = run_capture({"env", "LC_ALL=C", "pactl", "list", "sink-inputs"}, 2500);
    return r.out.find("Corked: no") != std::string::npos;
}
inline void ensure_playing() {
    auto wait = [](int ms) { for (int t = 0; t < ms; t += 500) { if (audio_playing()) return true; msleep(500); if (g_closing) return false; } return false; };
    if (!have_cmd("pactl")) return;
    if (wait(6000)) return;
    log_line("ensure_playing: звука нет, пробую Play");
    if (have_cmd("playerctl")) run_capture({"playerctl", "play"}, 3000);
    if (wait(2500)) return;
    keyboard_key("k");  // горячая клавиша YouTube «играть/пауза»
    wait(2500);
}

// ---------------------------------------------------------------- диспетчер
inline ActResult RunAction(const Action& a) {
    const std::string& t = a.type;
    const std::string a0 = a.args.empty() ? "" : a.args[0];
    if (t == "mic_off") { g_online = false; return Ok("Микрофон выключен."); }
    if (t == "remember") return ActRemember(a);
    if (t == "forget") return ActForget(a);
    if (t == "web_search" || t == "web") return ActWebSearch(a0);
    if (t == "type") return ActType(a0);
    if (t == "key") return ActKey(a0);
    if (t == "wait") return ActWait(a0);
    if (t == "timer" || t == "remind") return ActTimer(a);
    if (t == "open_app") return ActOpenApp(a0);
    if (t == "open_url") {
        if (!is_http_url(a0)) return Fail("Разрешены только обычные ссылки http/https.");
        return open_target(a0) ? Ok("Открыта ссылка.") : Fail("Не удалось открыть ссылку.");
    }
    if (t == "youtube") return ActYouTube(a0, false);
    if (t == "youtube_play") return ActYouTube(a0, true);
    if (t == "search") {
        if (trim(a0).empty()) return Fail("Пустой поисковый запрос.");
        return open_target("https://www.google.com/search?q=" + url_encode(trim(a0))) ? Ok("Открыт поиск: " + trim(a0)) : Fail("Не удалось открыть поиск.");
    }
    if (t == "open_path") return ActOpenPath(a);
    if (t == "find_file") return ActFindFile(a);
    if (t == "read_file") return ActReadFile(a);
    if (t == "list_dir") return ActListDir(a);
    if (t == "sysinfo") return ActSysInfo();
    if (t == "volume") return ActVolume(a);
    if (t == "media") return ActMedia(a);
    if (t == "lock") return ActLock();
    if (t == "run") return ActRun(a);
    if (t == "delete") return ActDelete(a);
    if (t == "close_app") return ActCloseApp(a);
    if (t == "power") return ActPower(a);
    return Fail("Неизвестное действие: " + t);
}
inline std::string describe_action(const Action& a) {
    std::string s = a.type;
    for (size_t i = 0; i < a.args.size(); ++i) s += (i ? " | " : ": ") + a.args[i];
    return utf8_truncate(s, 200);
}
