#!/usr/bin/env bash
# FLEY AI для Linux - удаление.   ./uninstall.sh [--system] [--prefix DIR] [--purge]
#   --purge  удалить также настройки (включая API-ключ), память и историю диалога
set -euo pipefail

PREFIX="$HOME/.local"; SYSTEM=0; PURGE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --system) SYSTEM=1; PREFIX="/usr/local" ;;
    --prefix) PREFIX="${2:?После --prefix нужен каталог}"; shift ;;
    --purge) PURGE=1 ;;
    -h|--help) sed -n '2,3p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Неизвестный параметр: $1" >&2; exit 1 ;;
  esac
  shift
done

RUN=""
if [ "$SYSTEM" -eq 1 ] && [ "$(id -u)" -ne 0 ]; then RUN="sudo"; fi

pkill -u "$(id -u)" -x fley-ai 2>/dev/null || true   # закрыть, если запущен
$RUN rm -f "$PREFIX/bin/fley-ai" "$PREFIX/share/applications/fley-ai.desktop" "$PREFIX/share/icons/hicolor/scalable/apps/fley-ai.svg"
rm -f "${XDG_CONFIG_HOME:-$HOME/.config}/autostart/fley-ai.desktop"
command -v update-desktop-database >/dev/null 2>&1 && $RUN update-desktop-database "$PREFIX/share/applications" >/dev/null 2>&1 || true
echo "✔ Программа удалена из $PREFIX"

if [ "$PURGE" -eq 1 ]; then
  rm -rf "${XDG_CONFIG_HOME:-$HOME/.config}/fley-ai" "${XDG_DATA_HOME:-$HOME/.local/share}/fley-ai"
  echo "✔ Настройки, память и история удалены"
else
  echo "Настройки и память сохранены (${XDG_CONFIG_HOME:-$HOME/.config}/fley-ai). Полное удаление: ./uninstall.sh --purge"
fi
