#!/usr/bin/env bash
# FLEY AI - установка живого голоса (Piper, работает офлайн). Запуск: ./install_voice.sh
# После установки FLEY AI сам находит голос (~/.local/share/fley-ai/voices), ничего в .env менять не нужно.
set -e
DIR="$HOME/.local/share/fley-ai/voices"
mkdir -p "$DIR"
cd "$DIR"
command -v curl >/dev/null || { echo "Нужен curl: sudo apt install curl"; exit 1; }

case "$(uname -m)" in
  x86_64)  ARCH=x86_64 ;;
  aarch64) ARCH=aarch64 ;;
  armv7l)  ARCH=armv7l ;;
  *) echo "Архитектура $(uname -m) не поддерживается этим скриптом."; exit 1 ;;
esac

if [ ! -x "$DIR/piper/piper" ]; then
  echo "[1/3] Скачиваю Piper..."
  curl -fL --retry 3 -o piper.tar.gz "https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_linux_${ARCH}.tar.gz"
  tar xzf piper.tar.gz && rm -f piper.tar.gz
fi

HF="https://huggingface.co/rhasspy/piper-voices/resolve/main"
if [ ! -s ru.onnx ]; then
  echo "[2/3] Скачиваю русский голос (Denis, мужской)..."
  curl -fL --retry 3 -o ru.onnx      "$HF/ru/ru_RU/denis/medium/ru_RU-denis-medium.onnx"
  curl -fL --retry 3 -o ru.onnx.json "$HF/ru/ru_RU/denis/medium/ru_RU-denis-medium.onnx.json"
fi
if [ ! -s en.onnx ]; then
  echo "[3/3] Скачиваю английский голос (Ryan, мужской)..."
  curl -fL --retry 3 -o en.onnx      "$HF/en/en_US/ryan/high/en_US-ryan-high.onnx" || true
  curl -fL --retry 3 -o en.onnx.json "$HF/en/en_US/ryan/high/en_US-ryan-high.onnx.json" || true
  [ -s en.onnx ] || rm -f en.onnx en.onnx.json
fi

echo "Проверка голоса..."
echo "Здравствуйте, сэр. Голос установлен." | "$DIR/piper/piper" --model "$DIR/ru.onnx" --output_file /tmp/fley_voice_test.wav >/dev/null 2>&1 \
  && echo "Готово. Перезапустите FLEY AI." || echo "Piper не запустился - пришлите вывод: $DIR/piper/piper --help"
