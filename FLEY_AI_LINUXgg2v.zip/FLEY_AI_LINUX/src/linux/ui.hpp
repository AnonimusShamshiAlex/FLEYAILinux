// FLEY AI (Linux) - интерфейс HUD: рисование через Cairo, окно и события через SDL2.
#pragma once
#include <cairo/cairo.h>

#include "ai.hpp"

struct RGBc { int r, g, b; };
struct Rf { float x, y, w, h; };
// палитра JARVIS: яркий кристальный синий, ледяной, белое ядро; янтарь - «думаю», золото - броня Mark
static const RGBc C_CYAN = {30, 200, 255}, C_ICE = {150, 236, 255}, C_AMBER = {255, 176, 48}, C_BLUE = {96, 160, 255}, C_RED = {255, 90, 90},
                  C_OFF = {120, 135, 170}, C_WHITE = {255, 255, 255}, C_DARK = {2, 12, 24}, C_GOLD = {255, 200, 80};
static RGBc Mix(RGBc a, RGBc b, float k) { return {(int)(a.r + (b.r - a.r) * k), (int)(a.g + (b.g - a.g) * k), (int)(a.b + (b.b - a.b) * k)}; }
static const double kPi = 3.14159265358979;

static size_t U8Prev(const std::string& s, size_t pos) {
    if (pos == 0) return 0;
    size_t i = pos - 1;
    while (i > 0 && ((unsigned char)s[i] & 0xC0) == 0x80) --i;
    return i;
}
static size_t U8Len(const std::string& s, size_t i) {
    unsigned char c = (unsigned char)s[i];
    size_t n = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 1;
    return std::min(n, s.size() - i);
}

// ------------------------------------------------------------------ тонкая обёртка над Cairo (похожа на GDI+: перья и кисти)
struct Gfx {
    cairo_t* c;
    void col(RGBc k, int a) { cairo_set_source_rgba(c, k.r / 255.0, k.g / 255.0, k.b / 255.0, std::max(0, std::min(255, a)) / 255.0); }
    void line(float x1, float y1, float x2, float y2, RGBc k, int a, float w, bool round = false) {
        col(k, a);
        cairo_set_line_width(c, w);
        cairo_set_line_cap(c, round ? CAIRO_LINE_CAP_ROUND : CAIRO_LINE_CAP_BUTT);
        cairo_move_to(c, x1, y1);
        cairo_line_to(c, x2, y2);
        cairo_stroke(c);
    }
    void rect(Rf r, RGBc k, int a, float w) {
        col(k, a);
        cairo_set_line_width(c, w);
        cairo_rectangle(c, r.x, r.y, r.w, r.h);
        cairo_stroke(c);
    }
    void frect(Rf r, RGBc k, int a) { col(k, a); cairo_rectangle(c, r.x, r.y, r.w, r.h); cairo_fill(c); }
    void circle(float cx, float cy, float r, RGBc k, int a, float w) {
        col(k, a);
        cairo_set_line_width(c, w);
        cairo_new_path(c);
        cairo_arc(c, cx, cy, std::max(0.1f, r), 0, 2 * kPi);
        cairo_stroke(c);
    }
    void fcircle(float cx, float cy, float r, RGBc k, int a) { col(k, a); cairo_new_path(c); cairo_arc(c, cx, cy, std::max(0.1f, r), 0, 2 * kPi); cairo_fill(c); }
    void ellipse(float cx, float cy, float rx, float ry, RGBc k, int a, float w, bool fill = false) {  // эллипс через масштабирование
        cairo_save(c);
        cairo_translate(c, cx, cy);
        cairo_scale(c, std::max(0.1f, rx), std::max(0.1f, ry));
        cairo_new_path(c);
        cairo_arc(c, 0, 0, 1.0, 0, 2 * kPi);
        cairo_restore(c);
        col(k, a);
        if (fill) cairo_fill(c);
        else { cairo_set_line_width(c, w); cairo_stroke(c); }
    }
    void arcEll(float cx, float cy, float rx, float ry, float startDeg, float sweepDeg, RGBc k, int a, float w) {
        cairo_save(c);
        cairo_translate(c, cx, cy);
        cairo_scale(c, std::max(0.1f, rx), std::max(0.1f, ry));
        cairo_new_path(c);
        cairo_arc(c, 0, 0, 1.0, startDeg * kPi / 180.0, (startDeg + sweepDeg) * kPi / 180.0);
        cairo_restore(c);
        col(k, a);
        cairo_set_line_width(c, w);
        cairo_stroke(c);
    }
    void arc(float cx, float cy, float r, float startDeg, float sweepDeg, RGBc k, int a, float w, bool round = false) {
        col(k, a);
        cairo_set_line_width(c, w);
        cairo_set_line_cap(c, round ? CAIRO_LINE_CAP_ROUND : CAIRO_LINE_CAP_BUTT);
        cairo_new_path(c);
        cairo_arc(c, cx, cy, std::max(0.1f, r), startDeg * kPi / 180.0, (startDeg + sweepDeg) * kPi / 180.0);
        cairo_stroke(c);
        cairo_set_line_cap(c, CAIRO_LINE_CAP_BUTT);
    }
    void font(bool mono, float px, bool bold) {
        cairo_select_font_face(c, mono ? "Monospace" : "Sans", CAIRO_FONT_SLANT_NORMAL, bold ? CAIRO_FONT_WEIGHT_BOLD : CAIRO_FONT_WEIGHT_NORMAL);
        cairo_set_font_size(c, px);
    }
    float width(const std::string& s) {
        cairo_text_extents_t te;
        cairo_text_extents(c, s.c_str(), &te);
        return (float)te.x_advance;
    }
    // одна строка, выравнивание: 0 слева, 1 по центру, 2 справа; обрезается многоточием
    void text(const std::string& s, bool mono, float px, bool bold, RGBc k, int a, Rf r, int align = 0) {
        font(mono, px, bold);
        std::string t = s;
        if (r.w > 0 && width(t) > r.w) {
            while (t.size() > 1 && width(t + "…") > r.w) t.erase(U8Prev(t, t.size()));
            t += "…";
        }
        cairo_font_extents_t fe;
        cairo_font_extents(c, &fe);
        float tw = width(t);
        float tx = align == 0 ? r.x : align == 1 ? r.x + (r.w - tw) / 2 : r.x + r.w - tw;
        col(k, a);
        cairo_move_to(c, tx, r.y + (float)fe.ascent);
        cairo_show_text(c, t.c_str());
    }
    // перенос по словам (шрифт уже выбран); возвращает строки
    std::vector<std::string> wrap(const std::string& text, float maxw) {
        std::vector<std::string> lines;
        size_t p = 0;
        while (p <= text.size()) {
            size_t e = text.find('\n', p);
            std::string para = text.substr(p, e == std::string::npos ? std::string::npos : e - p);
            std::string cur;
            size_t i = 0;
            while (i < para.size()) {
                size_t sp = para.find(' ', i);
                std::string word = para.substr(i, sp == std::string::npos ? std::string::npos : sp - i);
                i = sp == std::string::npos ? para.size() : sp + 1;
                std::string trial = cur.empty() ? word : cur + " " + word;
                if (width(trial) <= maxw || cur.empty()) {
                    cur = trial;
                    while (width(cur) > maxw && cur.size() > 1) {  // слишком длинное слово: режем по символам
                        size_t k = 0, last = 0;
                        while (k < cur.size() && width(cur.substr(0, k + U8Len(cur, k))) <= maxw) { last = k + U8Len(cur, k); k = last; }
                        if (last == 0) last = U8Len(cur, 0);
                        lines.push_back(cur.substr(0, last));
                        cur = cur.substr(last);
                    }
                } else { lines.push_back(cur); cur = word; }
            }
            lines.push_back(cur);
            if (e == std::string::npos) break;
            p = e + 1;
        }
        return lines;
    }
};

// ------------------------------------------------------------------ состояние интерфейса
struct LogEntry { int role; std::string text; };
static std::vector<LogEntry> g_log;
static float g_cpu = 0, g_ram = 0, g_wave[160], g_lv = 0.0f;
static int g_wavePos = 0, g_W = 0, g_H = 0, g_mode = 0, g_hover = 0, g_press = 0, g_tFx = 1, g_focus = 0;
static bool g_setOpen = false, g_keyShow = false, g_tConfirm = false, g_tAuto = false, g_cfShow = false;
static std::string g_ed[4];  // ключ, обращение, слово-активатор, пауза
static std::string g_cfLocal;
static SDL_Window* g_win = nullptr;

enum BtnId { B_NONE = 0, B_ORB, B_CLOSE, B_MIN, B_MODE, B_MIC, B_CLEAR, B_SET, S_SHOW, S_CLR, S_CONFIRM, S_FX, S_AUTO, S_SAVE, S_CANCEL, S_ENV, S_PASTE, S_GET, C_YES, C_NO };
struct BtnDef { int id; Rf r; std::string text; RGBc col; };
static std::vector<BtnDef> g_btns;

struct Lay { float s, W, H, cx, cy, R; Rf left, holo, right, log; bool mini; } L;
struct SetLay { Rf panel, f[4], bShow, bPaste, bGet, bClr, bConfirm, bFx, bAuto, bSave, bCancel, bEnv, cfPanel, bYes, bNo; } SL;

static bool InRc(const Rf& r, int x, int y) { return x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h; }

static void LayoutSettings() {
    float s = L.s;
    float pw = std::min(860.0f * s, L.W - 24.0f), ph = std::min(540.0f * s, L.H - 24.0f);
    float x0 = (L.W - pw) / 2, y0 = (L.H - ph) / 2, pad = 28 * s, inner = pw - 2 * pad, gap = 18 * s;
    float col = (inner - gap) / 2, fh = 38 * s;
    SL.panel = {x0, y0, pw, ph};
    SL.f[0] = {x0 + pad, y0 + 96 * s, inner, fh};
    {
        float g4 = 10 * s, bw = inner - 3 * g4;
        float w1 = bw * 0.21f, w2 = bw * 0.25f, w3 = bw * 0.30f, w4 = bw - w1 - w2 - w3, yy = y0 + 144 * s, hh = 32 * s;
        SL.bShow = {x0 + pad, yy, w1, hh};
        SL.bPaste = {SL.bShow.x + w1 + g4, yy, w2, hh};
        SL.bGet = {SL.bPaste.x + w2 + g4, yy, w3, hh};
        SL.bClr = {SL.bGet.x + w3 + g4, yy, w4, hh};
    }
    SL.f[1] = {x0 + pad, y0 + 218 * s, col, fh};
    SL.f[2] = {x0 + pad + col + gap, y0 + 218 * s, col, fh};
    SL.f[3] = {x0 + pad, y0 + 292 * s, col, fh};
    SL.bConfirm = {x0 + pad + col + gap, y0 + 292 * s, col, fh};
    SL.bFx = {x0 + pad, y0 + 352 * s, col, fh};
    SL.bAuto = {x0 + pad + col + gap, y0 + 352 * s, col, fh};
    float by = y0 + ph - 62 * s;
    SL.bSave = {x0 + pad, by, std::min(210 * s, inner * 0.3f), 42 * s};
    SL.bCancel = {SL.bSave.x + SL.bSave.w + 12 * s, by, std::min(170 * s, inner * 0.25f), 42 * s};
    SL.bEnv = {SL.bCancel.x + SL.bCancel.w + 12 * s, by, x0 + pw - pad - (SL.bCancel.x + SL.bCancel.w + 12 * s), 42 * s};
    float cw = std::min(760 * s, L.W - 24.0f), chh = std::min(320 * s, L.H - 24.0f);
    SL.cfPanel = {(L.W - cw) / 2, (L.H - chh) / 2, cw, chh};
    SL.bYes = {SL.cfPanel.x + 28 * s, SL.cfPanel.y + chh - 72 * s, 220 * s, 46 * s};
    SL.bNo = {SL.bYes.x + SL.bYes.w + 16 * s, SL.bYes.y, 220 * s, 46 * s};
}

static void Relayout() {
    L.W = (float)g_W;
    L.H = (float)g_H;
    L.mini = g_mode == 2;
    if (L.mini) {
        L.s = std::max(0.7f, std::min(1.3f, L.W / 520.0f));
        float s = L.s, m = 18 * s;
        L.R = std::min(L.W * 0.2f, (L.H * 0.44f - 70 * s) / 2.1f);
        L.cx = L.W / 2;
        L.cy = 62 * s + L.R * 1.95f;
        float ly = L.cy + L.R * 2.1f, top = ly + 84 * s, bottom = L.H - m - 36 * s - 10 * s;
        L.log = {m, top, L.W - 2 * m, std::max(10.0f, bottom - top)};
        L.left = L.right = L.holo = {0, 0, 0, 0};
    } else {
        L.s = std::max(0.62f, std::min(2.2f, std::min(L.H / 1080.0f, L.W / 1750.0f)));
        float s = L.s, m = 34 * s, lw = 330 * s, rw = 470 * s;
        float top = 110 * s, colH = L.H - top - 110 * s, statsH = std::min(430 * s, colH);
        L.left = {m, top, lw, statsH};
        float hh = colH - statsH - 12 * s;
        L.holo = hh >= 150 * s ? Rf{m, top + statsH + 12 * s, lw, hh} : Rf{0, 0, 0, 0};
        L.right = {L.W - m - rw, top, rw, colH};
        L.log = L.right;
        L.cx = (L.left.x + L.left.w + L.right.x) / 2.0f;
        L.cy = L.H * 0.45f;
        L.R = std::min(L.H * 0.15f, (L.right.x - L.left.x - L.left.w) / 4.4f);
    }
    LayoutSettings();
}

// ------------------------------------------------------------------ кнопки
static void AddBtn(int id, Rf r, const std::string& t, RGBc c) { g_btns.push_back({id, r, t, c}); }
static void BuildButtons() {
    g_btns.clear();
    float s = L.s;
    bool on = g_online != 0;
    if (g_cfShow) {
        AddBtn(C_YES, SL.bYes, "РАЗРЕШИТЬ", C_AMBER);
        AddBtn(C_NO, SL.bNo, "ОТКАЗАТЬ", C_ICE);
        return;
    }
    if (g_setOpen) {
        AddBtn(S_SHOW, SL.bShow, g_keyShow ? "СКРЫТЬ" : "ПОКАЗАТЬ", C_CYAN);
        AddBtn(S_PASTE, SL.bPaste, "ВСТАВИТЬ КЛЮЧ", C_ICE);
        AddBtn(S_GET, SL.bGet, "СОЗДАТЬ КЛЮЧ (GROQ)", C_GOLD);
        AddBtn(S_CLR, SL.bClr, "ОЧИСТИТЬ", C_CYAN);
        AddBtn(S_CONFIRM, SL.bConfirm, g_tConfirm ? "ПОДТВЕРЖДЕНИЕ ОПАСНОГО: ДА" : "ПОДТВЕРЖДЕНИЕ ОПАСНОГО: НЕТ", g_tConfirm ? C_ICE : C_OFF);
        AddBtn(S_FX, SL.bFx, g_tFx == 1 ? "ГОЛОС: JARVIS" : g_tFx == 2 ? "ГОЛОС: РОБОТ" : "ГОЛОС: ЧИСТЫЙ", g_tFx == 0 ? C_OFF : g_tFx == 1 ? C_ICE : C_AMBER);
        AddBtn(S_AUTO, SL.bAuto, g_tAuto ? "ЗАПУСК С СИСТЕМОЙ: ДА" : "ЗАПУСК С СИСТЕМОЙ: НЕТ", g_tAuto ? C_ICE : C_OFF);
        AddBtn(S_SAVE, SL.bSave, "СОХРАНИТЬ", C_ICE);
        AddBtn(S_CANCEL, SL.bCancel, "ОТМЕНА", C_RED);
        AddBtn(S_ENV, SL.bEnv, "ОТКРЫТЬ .env", C_CYAN);
        return;
    }
    const char* modeName = g_mode == 0 ? "РЕЖИМ: ПОЛНЫЙ ЭКРАН" : g_mode == 1 ? "РЕЖИМ: ОКНО" : "РЕЖИМ: МИНИ";
    if (!L.mini) {
        float m = 34 * s, bw = 60 * s, bh = 36 * s, top = 26 * s, xr = L.W - m;
        if (g_mode == 0) {
            AddBtn(B_CLOSE, {xr - bw, top, bw, bh}, "X", C_RED);
            AddBtn(B_MIN, {xr - 2 * bw - 10 * s, top, bw, bh}, "_", C_CYAN);
            xr -= 2 * bw + 22 * s;
        }
        AddBtn(B_MODE, {xr - 250 * s, top, 250 * s, bh}, modeName, C_CYAN);
        float by = L.H - m - 36 * s, x = m, w = 210 * s, gap = 12 * s;
        AddBtn(B_MIC, {x, by, w, 36 * s}, on ? "МИКРОФОН: ВКЛ" : "МИКРОФОН: ВЫКЛ", on ? C_ICE : C_OFF);
        AddBtn(B_CLEAR, {x + w + gap, by, w, 36 * s}, "ОЧИСТИТЬ ДИАЛОГ", C_CYAN);
        AddBtn(B_SET, {x + 2 * (w + gap), by, w, 36 * s}, "НАСТРОЙКИ", C_AMBER);
    } else {
        float m = 18 * s, by = L.H - m - 36 * s, gap = 8 * s, w = (L.W - 2 * m - 2 * gap) / 3;
        AddBtn(B_MIC, {m, by, w, 36 * s}, on ? "МИКРОФОН: ВКЛ" : "МИКРОФОН: ВЫКЛ", on ? C_ICE : C_OFF);
        AddBtn(B_MODE, {m + w + gap, by, w, 36 * s}, "РЕЖИМ", C_CYAN);
        AddBtn(B_SET, {m + 2 * (w + gap), by, w, 36 * s}, "НАСТРОЙКИ", C_AMBER);
    }
}
static int HitTest(int x, int y) {
    BuildButtons();
    for (size_t i = g_btns.size(); i-- > 0;)
        if (InRc(g_btns[i].r, x, y)) return g_btns[i].id;
    if (!g_setOpen && !g_cfShow) {
        float dx = x - L.cx, dy = y - L.cy, rr = L.R * 1.5f;
        if (dx * dx + dy * dy <= rr * rr) return B_ORB;
    }
    return B_NONE;
}
static std::string TipFor(int id) {
    switch (id) {
        case B_ORB: case B_MIC: return "Нажмите: включить / выключить микрофон (во время ответа - прервать)";
        case B_MODE: return "Сменить режим: полный экран → окно → мини-окно поверх всех (F11)";
        case B_CLEAR: return "Очистить журнал и контекст разговора (память о вас сохранится)";
        case B_SET: return "Настройки: API-ключ, обращение, голос, слово-активатор";
        case B_CLOSE: return "Закрыть FLEY AI";
        case B_MIN: return "Свернуть (микрофон продолжит слушать)";
        case S_SHOW: return "Показать или скрыть API-ключ";
        case S_PASTE: return "Вставить ключ из буфера обмена и сразу сохранить";
        case S_GET: return "Открыть страницу, где бесплатно создаётся ключ: console.groq.com/keys";
        case S_CLR: return "Стереть поле ключа";
        case S_CONFIRM: return "ДА - перед опасными действиями спрашивать; НЕТ - выполнять сразу";
        case S_FX: return "Голос: JARVIS (мягкий) / РОБОТ (металл) / ЧИСТЫЙ (без эффектов)";
        case S_AUTO: return "Запускать FLEY AI при входе в систему";
        case S_SAVE: return "Сохранить в .env и применить";
        case S_CANCEL: return "Закрыть без сохранения";
        case S_ENV: return "Открыть файл .env в текстовом редакторе";
    }
    return "";
}

// ------------------------------------------------------------------ примитивы оформления
static void Brackets(Gfx& g, Rf r, RGBc c, float len, float w, int a) {
    float x1 = r.x, y1 = r.y, x2 = r.x + r.w, y2 = r.y + r.h;
    g.line(x1, y1, x1 + len, y1, c, a, w); g.line(x1, y1, x1, y1 + len, c, a, w);
    g.line(x2, y1, x2 - len, y1, c, a, w); g.line(x2, y1, x2, y1 + len, c, a, w);
    g.line(x1, y2, x1 + len, y2, c, a, w); g.line(x1, y2, x1, y2 + len, c, a, w);
    g.line(x2, y2, x2 - len, y2, c, a, w); g.line(x2, y2, x2, y2 + len, c, a, w);
}
static void Panel(Gfx& g, Rf r, const char* title) {
    float s = L.s;
    g.frect(r, {0, 36, 64}, 80);
    g.rect(r, C_CYAN, 60, 1.0f);
    Brackets(g, r, C_CYAN, 22 * s, 2.0f * s, 235);
    g.text(title, true, 15 * s, true, C_CYAN, 235, {r.x + 14 * s, r.y + 10 * s, r.w - 28 * s, 22 * s});
    g.line(r.x + 14 * s, r.y + 36 * s, r.x + r.w - 14 * s, r.y + 36 * s, C_CYAN, 95, 1.0f);
}
static cairo_surface_t* g_bg = nullptr;
static void BuildBg() {
    if (g_bg) cairo_surface_destroy(g_bg);
    g_bg = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, g_W, g_H);
    cairo_t* c = cairo_create(g_bg);
    Gfx g{c};
    float s = L.s;
    {
        cairo_pattern_t* p = cairo_pattern_create_linear(0, 0, 0, L.H);
        cairo_pattern_add_color_stop_rgb(p, 0, 2 / 255.0, 9 / 255.0, 20 / 255.0);
        cairo_pattern_add_color_stop_rgb(p, 1, 3 / 255.0, 22 / 255.0, 44 / 255.0);
        cairo_set_source(c, p);
        cairo_paint(c);
        cairo_pattern_destroy(p);
    }
    {   // свечение за ядром
        float rad = L.R * 3.8f;
        cairo_pattern_t* p = cairo_pattern_create_radial(L.cx, L.cy, 0, L.cx, L.cy, rad);
        cairo_pattern_add_color_stop_rgba(p, 0, C_CYAN.r / 255.0, C_CYAN.g / 255.0, C_CYAN.b / 255.0, 52 / 255.0);
        cairo_pattern_add_color_stop_rgba(p, 1, C_CYAN.r / 255.0, C_CYAN.g / 255.0, C_CYAN.b / 255.0, 0);
        cairo_set_source(c, p);
        cairo_arc(c, L.cx, L.cy, rad, 0, 2 * kPi);
        cairo_fill(c);
        cairo_pattern_destroy(p);
    }
    float step = 60 * s;
    for (int i = 0; i * step < L.W; ++i) g.line(i * step + 0.5f, 0, i * step + 0.5f, L.H, C_CYAN, i % 5 == 0 ? 24 : 10, 1.0f);
    for (int i = 0; i * step < L.H; ++i) g.line(0, i * step + 0.5f, L.W, i * step + 0.5f, C_CYAN, i % 5 == 0 ? 24 : 10, 1.0f);
    Brackets(g, {10 * s, 10 * s, L.W - 20 * s, L.H - 20 * s}, C_CYAN, L.mini ? 34 * s : 60 * s, 3.0f * s, 210);
    if (L.mini) {
        g.text("F L E Y   A I", false, 26 * s, true, C_CYAN, 255, {20 * s, 14 * s, 300 * s, 34 * s});
        g.text("FLEY INDUSTRIES", true, 12 * s, false, C_ICE, 210, {22 * s, 44 * s, 300 * s, 18 * s});
        cairo_destroy(c);
        return;
    }
    g.text("F L E Y   A I", false, 38 * s, true, C_CYAN, 255, {34 * s, 22 * s, 500 * s, 50 * s});
    g.text("FLEY INDUSTRIES  //  ГОЛОСОВОЙ ИНТЕРФЕЙС  //  v0.9 LINUX", true, 15 * s, false, C_ICE, 210, {36 * s, 68 * s, 760 * s, 22 * s});
    g.line(34 * s, 98 * s, L.W - 34 * s, 98 * s, C_CYAN, 95, 1.0f);
    Panel(g, L.left, "СИСТЕМА");
    if (L.holo.h > 0) Panel(g, L.holo, "ГОЛОГРАММА  //  MARK L");
    Panel(g, L.right, "ЖУРНАЛ СВЯЗИ");
    g.text("F11 - режим окна     ПРОБЕЛ - микрофон", true, 14 * s, false, C_BLUE, 160, {L.W - 34 * s - 460 * s, L.H - 34 * s - 24 * s, 460 * s, 22 * s}, 2);
    cairo_destroy(c);
}

static void Btn(Gfx& g, const BtnDef& b, bool hov, bool down) {
    float s = L.s;
    Rf rc = b.r;
    RGBc c = b.col;
    if (hov)
        for (int i = 3; i >= 1; --i)
            g.rect({rc.x - i * 2.6f * s, rc.y - i * 2.6f * s, rc.w + i * 5.2f * s, rc.h + i * 5.2f * s}, c, 26 * (4 - i), 1.5f);
    g.frect(rc, c, down ? 150 : hov ? 100 : 28);
    g.rect(rc, hov ? Mix(c, C_WHITE, 0.55f) : c, hov ? 255 : 200, hov ? 2.6f : 1.5f);
    if (hov) Brackets(g, rc, C_WHITE, 9 * s, 2.0f, 255);
    g.text(b.text, true, 15 * s, true, hov ? C_WHITE : c, 255, {rc.x + 4 * s, rc.y + (rc.h - 20 * s) / 2 + (down ? 1.0f : 0.0f), rc.w - 8 * s, 22 * s}, 1);
}
static void Bar(Gfx& g, float x, float y, float w, float frac, RGBc c, const std::string& label, const std::string& val) {
    float s = L.s;
    g.text(label, true, 14 * s, false, C_BLUE, 225, {x, y, w, 20 * s});
    g.text(val, true, 14 * s, true, c, 255, {x, y, w, 20 * s}, 2);
    g.rect({x, y + 22 * s, w, 12 * s}, c, 95, 1.0f);
    frac = std::max(0.0f, std::min(1.0f, frac));
    int segs = (int)(w / (8 * s));
    for (int i = 0; i < segs * frac; ++i) g.frect({x + 2 + i * 8 * s, y + 24 * s, 6 * s, 8 * s}, c, 215);
}

// ------------------------------------------------------------------ голограмма костюма (каркас вращается)
struct V3 { float x, y, z; };
struct Seg { V3 a, b; int hot; };  // hot: 0 обычная линия, 1 белая (реактор, глаза), 2 золото (броня шлема)
static std::vector<Seg> g_holo;
static void HSeg(V3 a, V3 b, int hot = 0) { g_holo.push_back({a, b, hot}); }
static void HFrustum(float x0, float y0, float hx0, float hz0, float x1, float y1, float hx1, float hz1, float zc0 = 0, float zc1 = 0, int hot = 0) {
    V3 bt[4] = {{x0 - hx0, y0, zc0 - hz0}, {x0 + hx0, y0, zc0 - hz0}, {x0 + hx0, y0, zc0 + hz0}, {x0 - hx0, y0, zc0 + hz0}};
    V3 tp[4] = {{x1 - hx1, y1, zc1 - hz1}, {x1 + hx1, y1, zc1 - hz1}, {x1 + hx1, y1, zc1 + hz1}, {x1 - hx1, y1, zc1 + hz1}};
    for (int i = 0; i < 4; ++i) { HSeg(bt[i], bt[(i + 1) % 4], hot); HSeg(tp[i], tp[(i + 1) % 4], hot); HSeg(bt[i], tp[i], hot); }
}
static void HRing(float cx, float cy, float cz, float r, int n, bool flat, int hot) {
    for (int i = 0; i < n; ++i) {
        double a0 = i * 6.283185307 / n, a1 = (i + 1) * 6.283185307 / n;
        V3 p0 = flat ? V3{cx + r * (float)std::cos(a0), cy + r * (float)std::sin(a0), cz} : V3{cx + r * (float)std::cos(a0), cy, cz + r * (float)std::sin(a0)};
        V3 p1 = flat ? V3{cx + r * (float)std::cos(a1), cy + r * (float)std::sin(a1), cz} : V3{cx + r * (float)std::cos(a1), cy, cz + r * (float)std::sin(a1)};
        HSeg(p0, p1, hot);
    }
}
static void BuildHolo() {
    g_holo.clear();
    HFrustum(0, 3.55f, 0.58f, 0.62f, 0, 5.15f, 0.46f, 0.52f, 0, 0, 2);
    HFrustum(0, 5.15f, 0.46f, 0.52f, 0, 5.55f, 0.22f, 0.30f, 0, 0, 2);
    HFrustum(0, 3.0f, 0.42f, 0.46f, 0, 3.55f, 0.58f, 0.62f, 0.05f, 0, 2);
    HSeg({-0.46f, 4.60f, 0.60f}, {-0.10f, 4.42f, 0.60f}, 1);
    HSeg({0.46f, 4.60f, 0.60f}, {0.10f, 4.42f, 0.60f}, 1);
    HSeg({-0.22f, 3.85f, 0.64f}, {0.22f, 3.85f, 0.64f}, 2);
    HSeg({-0.46f, 4.95f, 0.54f}, {0.46f, 4.95f, 0.54f}, 2);
    HSeg({-0.58f, 4.0f, 0.62f}, {-0.30f, 3.2f, 0.50f}, 2);
    HSeg({0.58f, 4.0f, 0.62f}, {0.30f, 3.2f, 0.50f}, 2);
    HFrustum(0, 2.65f, 0.26f, 0.26f, 0, 3.0f, 0.28f, 0.28f);
    HFrustum(0, 0.55f, 0.62f, 0.40f, 0, 2.65f, 1.0f, 0.52f);
    HFrustum(0, -0.05f, 0.58f, 0.38f, 0, 0.55f, 0.62f, 0.40f);
    HFrustum(0, -0.55f, 0.68f, 0.42f, 0, -0.05f, 0.58f, 0.38f);
    HSeg({-0.9f, 2.3f, 0.52f}, {-0.25f, 1.95f, 0.56f});
    HSeg({0.9f, 2.3f, 0.52f}, {0.25f, 1.95f, 0.56f});
    HRing(0, 1.7f, 0.55f, 0.38f, 18, true, 1);
    HRing(0, 1.7f, 0.55f, 0.20f, 12, true, 1);
    for (int sd = -1; sd <= 1; sd += 2) {
        float X = (float)sd;
        HFrustum(X * 1.38f, 2.0f, 0.36f, 0.46f, X * 1.38f, 2.8f, 0.40f, 0.50f);
        HFrustum(X * 1.50f, 0.95f, 0.27f, 0.32f, X * 1.40f, 2.0f, 0.34f, 0.40f);
        HFrustum(X * 1.62f, -0.6f, 0.22f, 0.26f, X * 1.50f, 0.95f, 0.28f, 0.33f);
        HRing(X * 1.62f, -0.64f, 0, 0.17f, 10, false, 1);
        HFrustum(X * 0.36f, -2.7f, 0.30f, 0.34f, X * 0.36f, -0.55f, 0.36f, 0.42f);
        HFrustum(X * 0.38f, -4.65f, 0.24f, 0.28f, X * 0.36f, -2.7f, 0.30f, 0.34f);
        HFrustum(X * 0.38f, -5.05f, 0.28f, 0.52f, X * 0.38f, -4.65f, 0.26f, 0.30f, 0.2f, 0);
    }
}
static void DrawHolo(Gfx& g, Rf a, RGBc col, double t, float lv) {
    float s = L.s;
    if (g_holo.empty()) BuildHolo();
    float top = a.y + 46 * s, bottom = a.y + a.h - 26 * s;
    float k = std::min((bottom - top) / 11.2f, a.w / 6.8f);
    float cx = a.x + a.w / 2, cy = (top + bottom) / 2;
    float ang = (float)(t * 0.85);
    float ca = std::cos(ang), sa = std::sin(ang);
    float fl = 0.90f + 0.10f * (float)(std::sin(t * 37.0) * std::sin(t * 3.1));
    float py = cy + 5.35f * k, rx = 2.5f * k, ry = 0.55f * k;
    for (int i = 0; i < 3; ++i) {
        float f = 1.0f - i * 0.28f;
        g.ellipse(cx, py, rx * f, ry * f, col, 130 - i * 35, 1.4f * s);
    }
    g.arcEll(cx, py, rx, ry, (float)(t * 75.0), 38.0f, C_WHITE, 200, 2.4f * s);
    g.arcEll(cx, py, rx, ry, (float)(t * 75.0 + 180.0), 38.0f, C_WHITE, 200, 2.4f * s);
    g.ellipse(cx, py, rx * 0.9f, ry * 0.9f, col, 26, 0, true);
    float scanY = top + (float)std::fmod(t * 0.4, 1.0) * (bottom - top);
    g.line(cx - 2.6f * k, scanY, cx + 2.6f * k, scanY, col, 120, 1.5f * s);
    for (const Seg& sg : g_holo) {
        float ax = sg.a.x * ca + sg.a.z * sa, az = -sg.a.x * sa + sg.a.z * ca;
        float bx = sg.b.x * ca + sg.b.z * sa, bz = -sg.b.x * sa + sg.b.z * ca;
        float pa = 1.0f + az * 0.035f, pb = 1.0f + bz * 0.035f;
        float x1 = cx + ax * k * pa, y1 = cy - (sg.a.y - 0.25f) * k * pa;
        float x2 = cx + bx * k * pb, y2 = cy - (sg.b.y - 0.25f) * k * pb;
        float zm = (az + bz) * 0.5f;
        int alpha = (int)((105 + zm * 55) * fl);
        float my = (y1 + y2) * 0.5f;
        RGBc c = sg.hot == 1 ? Mix(col, C_WHITE, 0.8f) : sg.hot == 2 ? C_GOLD : col;
        float w = (sg.hot ? 1.9f : 1.3f) * s;
        if (std::fabs(my - scanY) < 9 * s) { alpha += 110; c = Mix(c, C_WHITE, 0.5f); }
        if (sg.hot == 1) alpha = (int)(alpha * (1.2f + lv * 0.9f)) + 60;
        if (sg.hot) g.line(x1, y1, x2, y2, c, 40, w * 3.2f);
        g.line(x1, y1, x2, y2, c, alpha, w);
    }
    g.text("FLEY INDUSTRIES  //  ARMOR", true, 12 * s, false, C_ICE, 190, {a.x, a.y + a.h - 22 * s, a.w, 18 * s}, 1);
}

// ------------------------------------------------------------------ ядро-реактор
static void DrawOrb(Gfx& g, RGBc col, int st) {
    float s = L.s, R = L.R, cx = L.cx, cy = L.cy, lv = g_lv;
    double t = Tick() / 1000.0;
    float spin = st == THINKING ? 3.5f : 1.0f;
    for (int i = 0; i < 7; ++i) g.fcircle(cx, cy, R * (0.95f + i * 0.1f) + lv * R * 0.25f, col, 16 - i * 2);
    {   float r = R * 1.95f;
        for (int k = 0; k < 3; ++k) g.arc(cx, cy, r, (float)(t * 25 * spin + k * 120), 78.0f, col, 200, 3.0f * s);
        g.circle(cx, cy, r, col, 40, 1.0f); }
    {   float r = R * 1.72f;
        for (int k = 0; k < 24; ++k) g.arc(cx, cy, r, (float)(-t * 18 + k * 15), 8.0f, col, 130, 1.6f * s); }
    {   float r = R * 1.5f;
        for (int k = 0; k < 90; ++k) {
            double a = (k * 4.0 + t * 6.0) * kPi / 180.0;
            float len = (k % 5 == 0 ? 14.0f : 7.0f) * s;
            g.line(cx + (float)std::cos(a) * r, cy + (float)std::sin(a) * r, cx + (float)std::cos(a) * (r + len), cy + (float)std::sin(a) * (r + len), col, k % 5 == 0 ? 170 : 90, 1.2f * s);
        } }
    {   float r = R * 1.27f;
        g.arc(cx, cy, r, (float)(t * 60 * spin), 110.0f, col, 235, 6.0f * s, true);
        g.arc(cx, cy, r, (float)(t * 60 * spin + 180), 60.0f, col, 140, 4.0f * s, true); }
    {   float r0 = R * 1.04f;  // радиальный эквалайзер
        for (int k = 0; k < 72; ++k) {
            double a = k * 5.0 * kPi / 180.0;
            float amp = lv * (0.45f + 0.55f * (float)std::fabs(std::sin(k * 0.55 + t * 7.0)));
            float len = 3.0f * s + R * 0.5f * amp;
            g.line(cx + (float)std::cos(a) * r0, cy + (float)std::sin(a) * r0, cx + (float)std::cos(a) * (r0 + len), cy + (float)std::sin(a) * (r0 + len), col, 200, 2.6f * s);
        } }
    {   float r = R * 0.95f + lv * R * 0.04f;
        g.fcircle(cx, cy, r, C_DARK, 240);
        g.circle(cx, cy, r, col, 255, 3.0f * s); }
    g.circle(cx, cy, R * 0.8f, col, 110, 1.5f * s);
    {   float r = R * 0.63f;
        for (int k = 0; k < 10; ++k) g.arc(cx, cy, r, (float)(k * 36 + t * 10 * spin), 27.0f, col, 175, R * 0.13f); }
    {   float rt = R * 0.34f;  // треугольник реактора
        float px[3], py[3];
        for (int k = 0; k < 3; ++k) { double a = (-90 + k * 120 + t * 20 * spin) * kPi / 180.0; px[k] = cx + (float)std::cos(a) * rt; py[k] = cy + (float)std::sin(a) * rt; }
        cairo_move_to(g.c, px[0], py[0]); cairo_line_to(g.c, px[1], py[1]); cairo_line_to(g.c, px[2], py[2]); cairo_close_path(g.c);
        g.col(col, 70); cairo_fill_preserve(g.c);
        g.col(col, 240); cairo_set_line_width(g.c, 2.0f * s); cairo_stroke(g.c); }
    {   float r = R * 0.15f * (1.0f + lv * 0.6f);
        for (int i = 3; i >= 1; --i) g.fcircle(cx, cy, r * (1 + i * 0.6f), col, 30);
        g.fcircle(cx, cy, r, C_WHITE, 240); }
    if (g_hover == B_ORB && !g_setOpen && !g_cfShow) {
        float r = R * (2.12f + 0.04f * (float)std::sin(t * 6.0));
        g.circle(cx, cy, r, C_WHITE, 230, 3.0f * s);
        g.circle(cx, cy, r, col, 120, 8.0f * s);
        g.fcircle(cx, cy, r, col, 26);
    }
}

static void DrawLog(Gfx& g, float x, float top, float w, float bottomY) {
    float s = L.s, y = bottomY, px = (L.mini ? 15.0f : 18.0f) * s, lh = px * 1.28f;
    for (int i = (int)g_log.size() - 1; i >= 0; --i) {
        const LogEntry& ln = g_log[(size_t)i];
        RGBc c = ln.role == 0 ? C_WHITE : ln.role == 1 ? C_CYAN : C_AMBER;
        std::string txt = std::string(ln.role == 0 ? "ВЫ > " : ln.role == 1 ? "FLEY > " : "СИСТЕМА > ") + ln.text;
        g.font(false, px, false);
        std::vector<std::string> lines = g.wrap(txt, w);
        y -= (float)lines.size() * lh + 10 * s;
        if (y < top) break;
        for (size_t k = 0; k < lines.size(); ++k) g.text(lines[k], false, px, false, c, 245, {x, y + (float)k * lh, w + 40, lh});
    }
}

static void DrawHud(Gfx& g) {
    float s = L.s;
    double t = Tick() / 1000.0;
    int st = g_state;
    bool on = g_online != 0;
    RGBc col = !on ? C_OFF : st == LISTENING ? C_ICE : st == THINKING ? C_AMBER : st == SPEAKING ? Mix(C_CYAN, C_WHITE, 0.55f) : C_CYAN;

    if (!L.mini) {  // бегущий огонёк на верхней линии и сканирующая линия
        float x = (float)std::fmod(t * 350.0, (double)L.W);
        g.line(x, 98 * s, x + 90 * s, 98 * s, C_CYAN, 255, 2.0f * s);
        float y = (float)std::fmod(t * 140.0, (double)L.H);
        cairo_pattern_t* p = cairo_pattern_create_linear(0, y - 40 * s, 0, y);
        cairo_pattern_add_color_stop_rgba(p, 0, C_CYAN.r / 255.0, C_CYAN.g / 255.0, C_CYAN.b / 255.0, 0);
        cairo_pattern_add_color_stop_rgba(p, 1, C_CYAN.r / 255.0, C_CYAN.g / 255.0, C_CYAN.b / 255.0, 22 / 255.0);
        cairo_set_source(g.c, p);
        cairo_rectangle(g.c, 0, y - 40 * s, L.W, 40 * s);
        cairo_fill(g.c);
        cairo_pattern_destroy(p);
    }
    DrawOrb(g, col, st);

    std::string label = !on ? "МИКРОФОН ВЫКЛ" : st == LISTENING ? "СЛУШАЮ" : st == THINKING ? "ОБРАБОТКА" : st == SPEAKING ? "ОТВЕЧАЮ" : "ОЖИДАНИЕ";
    float ly = L.cy + L.R * 2.1f, lfs = L.mini ? 26.0f : 34.0f;
    g.text(label, false, lfs * s, true, col, 255, {L.cx - 300 * s, ly, 600 * s, 44 * s}, 1);
    std::string status;
    bool err;
    { std::lock_guard<std::mutex> lk(g_mx); status = g_status; err = g_statusErr; }
    std::string tip = g_hover ? TipFor(g_hover) : "";
    bool showTip = !tip.empty();
    {   // строка состояния: переносится на несколько строк (ошибки бывают длинными)
        float px = (L.mini ? 13.0f : 16.0f) * s, w = std::min(L.W - 40 * s, 900 * s), lh = px * 1.3f;
        float y0 = ly + (L.mini ? 34.0f : 44.0f) * s;
        g.font(true, px, false);
        std::vector<std::string> lines = g.wrap(showTip ? tip : status, w);
        for (size_t k = 0; k < lines.size() && k < 3; ++k) {
            std::string ln = lines[k];
            if (k == 2 && lines.size() > 3) ln += "…";
            g.text(ln, true, px, false, showTip ? C_ICE : err ? C_RED : C_BLUE, showTip ? 255 : err ? 255 : 225, {L.cx - w / 2, y0 + (float)k * lh, w, lh}, 1);
        }
    }

    if (!L.mini) {
        {   // осциллограмма внизу
            float w = 560 * s, x0 = L.cx - w / 2, yc = L.H - 62 * s;
            g.col(col, 230);
            cairo_set_line_width(g.c, 2.0f * s);
            for (int i = 0; i < 160; ++i) {
                float v = g_wave[(g_wavePos + i) % 160];
                float px = x0 + w * i / 159.0f, py = yc + (float)std::sin(i * 0.9 + t * 8) * v * 26 * s;
                if (i == 0) cairo_move_to(g.c, px, py); else cairo_line_to(g.c, px, py);
            }
            cairo_stroke(g.c);
            g.line(x0, yc, x0 + w, yc, col, 50, 1.0f);
        }
        // левая панель
        float x = L.left.x + 18 * s, w2 = L.left.w - 36 * s, y = L.left.y + 48 * s;
        time_t tt = time(nullptr);
        struct tm tm;
        localtime_r(&tt, &tm);
        char buf[64];
        snprintf(buf, sizeof buf, "%02d:%02d:%02d", tm.tm_hour, tm.tm_min, tm.tm_sec);
        g.text(buf, true, 46 * s, true, C_CYAN, 255, {x, y, w2, 56 * s});
        snprintf(buf, sizeof buf, "%02d.%02d.%04d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
        g.text(buf, true, 17 * s, false, C_BLUE, 225, {x, y + 52 * s, w2, 24 * s});
        y += 90 * s;
        Bar(g, x, y, w2, g_cpu / 100.0f, g_cpu > 85 ? C_RED : C_CYAN, "ПРОЦЕССОР", std::to_string((int)g_cpu) + "%");
        y += 52 * s;
        Bar(g, x, y, w2, g_ram / 100.0f, g_ram > 85 ? C_RED : C_CYAN, "ПАМЯТЬ ПК", std::to_string((int)g_ram) + "%");
        y += 52 * s;
        Bar(g, x, y, w2, g_lv * 1.4f, col, "МИКРОФОН", on ? std::to_string(g_level1000 / 10) + "%" : std::string("выкл"));
        y += 56 * s;
        g.text("СОЗДАТЕЛЬ", true, 13 * s, false, C_BLUE, 205, {x, y, w2, 18 * s});
        g.text("FLEY INDUSTRIES", true, 15 * s, true, C_ICE, 255, {x, y + 17 * s, w2, 22 * s});
        y += 44 * s;
        g.text("ПАМЯТЬ FLEY", true, 13 * s, false, C_BLUE, 205, {x, y, w2, 18 * s});
        g.text(std::to_string((int)g_factCount) + " фактов о вас", true, 15 * s, true, C_ICE, 255, {x, y + 17 * s, w2, 22 * s});
        y += 44 * s;
        g.text("УПРАВЛЕНИЕ ПК", true, 13 * s, false, C_BLUE, 205, {x, y, w2, 18 * s});
        g.text(g_set.pc ? "АКТИВНО" : "ВЫКЛЮЧЕНО", true, 15 * s, true, g_set.pc ? C_ICE : C_RED, 255, {x, y + 17 * s, w2, 22 * s});

        if (L.holo.h > 0) DrawHolo(g, L.holo, col, t, g_lv);
        DrawLog(g, L.right.x + 16 * s, L.right.y + 46 * s, L.right.w - 32 * s, L.right.y + L.right.h - 14 * s);
    } else {
        DrawLog(g, L.log.x, L.log.y, L.log.w, L.log.y + L.log.h);
    }
}

// ------------------------------------------------------------------ настройки (окно внутри интерфейса, свои поля ввода)
static std::string KeyKind(const std::string& kk) {
    return kk.compare(0, 4, "gsk_") == 0 ? "тип ключа: Groq" : kk.compare(0, 6, "sk-or-") == 0 ? "тип ключа: OpenRouter" : kk.compare(0, 3, "sk-") == 0 ? "тип ключа: OpenAI" : "тип ключа: не распознан";
}
static void DrawSettings(Gfx& g) {
    float s = L.s;
    g.frect({0, 0, L.W, L.H}, C_DARK, 228);
    Rf p = SL.panel;
    g.frect(p, {3, 24, 42}, 255);
    g.rect(p, C_CYAN, 150, 1.5f);
    Brackets(g, p, C_CYAN, 28 * s, 3.0f * s, 255);
    g.text("НАСТРОЙКИ  //  FLEY INDUSTRIES", false, 26 * s, true, C_CYAN, 255, {p.x + 28 * s, p.y + 20 * s, p.w - 56 * s, 36 * s});
    g.line(p.x + 28 * s, p.y + 62 * s, p.x + p.w - 28 * s, p.y + 62 * s, C_CYAN, 95, 1.0f);
    const char* labs[4] = {"API-КЛЮЧ  (Groq / OpenRouter / OpenAI)", "КАК К ВАМ ОБРАЩАТЬСЯ (например: сэр)", "СЛОВО-АКТИВАТОР (пусто = слушать всё)", "КОНЕЦ ФРАЗЫ, СЕК (0.4 - 5)"};
    long long tk = Tick();
    for (int i = 0; i < 4; ++i) {
        Rf r = SL.f[i];
        g.text(labs[i], true, 13 * s, false, C_BLUE, 235, {r.x, r.y - 22 * s, r.w, 18 * s});
        bool foc = g_focus == i;
        g.frect(r, {4, 30, 50}, 255);
        g.rect(r, C_CYAN, foc ? 255 : 110, foc ? 2.2f : 1.2f);
        std::string shown = (i == 0 && !g_keyShow) ? std::string(g_ed[0].size(), '*') : g_ed[i];
        if (foc && (tk / 500) % 2 == 0) shown += "|";
        g.font(true, 17 * s, false);
        while (shown.size() > 1 && g.width(shown) > r.w - 20 * s) shown.erase(0, U8Len(shown, 0));  // длинный ключ: видна его правая часть
        g.text(shown, true, 17 * s, false, C_WHITE, 255, {r.x + 10 * s, r.y + 9 * s, r.w - 14 * s, 24 * s});
    }
    g.text(KeyKind(g_ed[0]), true, 13 * s, true, C_ICE, 230, {SL.f[0].x, SL.f[0].y - 22 * s, SL.f[0].w, 18 * s}, 2);
    g.text("Нет ключа? Бесплатно: console.groq.com/keys (подойдёт и ключ OpenAI / OpenRouter). Скопируйте его и нажмите ВСТАВИТЬ КЛЮЧ.", true, 12 * s, false, C_GOLD, 225,
           {SL.f[0].x, SL.bShow.y + 36 * s, SL.f[0].w, 16 * s});
    g.text("Tab - следующее поле    Ctrl+V - вставить    Enter - сохранить    Esc - отмена", true, 12 * s, false, C_BLUE, 170, {p.x + 28 * s, p.y + p.h - 100 * s, p.w - 56 * s, 18 * s});
}

static void DrawConfirm(Gfx& g) {
    float s = L.s;
    g.frect({0, 0, L.W, L.H}, C_DARK, 215);
    Rf p = SL.cfPanel;
    g.frect(p, {24, 16, 6}, 255);
    g.rect(p, C_AMBER, 200, 2.0f);
    Brackets(g, p, C_AMBER, 28 * s, 3.0f * s, 255);
    g.text("ПОДТВЕРЖДЕНИЕ ДЕЙСТВИЯ", false, 24 * s, true, C_AMBER, 255, {p.x + 28 * s, p.y + 20 * s, p.w - 56 * s, 34 * s});
    g.line(p.x + 28 * s, p.y + 62 * s, p.x + p.w - 28 * s, p.y + 62 * s, C_AMBER, 120, 1.0f);
    g.font(true, 15 * s, false);
    std::vector<std::string> lines = g.wrap(g_cfLocal, p.w - 56 * s);
    for (size_t k = 0; k < lines.size() && k < 8; ++k) g.text(lines[k], true, 15 * s, false, C_WHITE, 255, {p.x + 28 * s, p.y + 78 * s + (float)k * 22 * s, p.w - 56 * s, 22 * s});
    g.text("Y - разрешить      N или Esc - отказать (через 60 с отказ автоматически)", true, 12 * s, false, C_BLUE, 190, {p.x + 28 * s, SL.bYes.y - 26 * s, p.w - 56 * s, 18 * s});
}

// ------------------------------------------------------------------ анимация и статистика
static void Animate() {
    int st = g_state;
    double t = Tick() / 1000.0, target;
    if (!g_online) target = 0.02;
    else if (st == LISTENING) target = g_level1000 / 1000.0 * 1.6;
    else if (st == SPEAKING) target = 0.35 + 0.25 * std::sin(t * 9) + 0.15 * std::sin(t * 5.3);
    else if (st == THINKING) target = 0.12;
    else target = 0.06 + 0.04 * std::sin(t * 2);
    g_lv = (float)std::min(0.9, g_lv * 0.7 + std::max(0.0, target) * 0.3);
    g_wave[g_wavePos] = g_lv;
    g_wavePos = (g_wavePos + 1) % 160;
}
static void UpdateStats() {
    static double pi = 0, pt = 0;
    double i, t;
    if (CpuTimes(i, t) && t > pt) { g_cpu = (float)(100.0 * (1.0 - (i - pi) / (t - pt))); pi = i; pt = t; }
    double tk, ak;
    if (MemInfo(tk, ak)) g_ram = (float)(100.0 * (tk - ak) / tk);
}

// ------------------------------------------------------------------ окно: режимы, настройки, действия
static void MkdirP(const std::string& path) {
    for (size_t i = 1; i <= path.size(); ++i)
        if (i == path.size() || path[i] == '/') mkdir(path.substr(0, i).c_str(), 0755);
}
static void ApplyAutostart(bool on) {
    std::string dir = HomeDir() + "/.config/autostart", f = dir + "/fley-ai.desktop";
    if (!on) { unlink(f.c_str()); return; }
    MkdirP(dir);
    std::string exeDir = g_exePath.substr(0, g_exePath.find_last_of('/'));
    WriteFileText(f, "[Desktop Entry]\nType=Application\nName=FLEY AI\nComment=Голосовой ИИ-помощник\nExec=\"" + g_exePath + "\"\nPath=" + exeDir +
                         "\nIcon=" + exeDir + "/fai.png\nTerminal=false\nX-GNOME-Autostart-enabled=true\n");
}
static void PersistMode(int m) {
    std::string env = ReadFile(g_envPath);
    if (env.empty()) env = kEnvTemplate;
    WriteFileText(g_envPath, set_env_value(env, "FLEY_WINDOW_MODE", m == 0 ? "full" : m == 1 ? "window" : "mini"));
    chmod(g_envPath.c_str(), 0600);
}
static void ApplyMode(int m, bool persist = true) {
    g_mode = m;
#if SDL_VERSION_ATLEAST(2, 0, 16)
    SDL_SetWindowAlwaysOnTop(g_win, m == 2 ? SDL_TRUE : SDL_FALSE);
#endif
    if (m == 0) {
        SDL_SetWindowFullscreen(g_win, SDL_WINDOW_FULLSCREEN_DESKTOP);
    } else {
        SDL_SetWindowFullscreen(g_win, 0);
        SDL_SetWindowResizable(g_win, SDL_TRUE);
        if (m == 1) { SDL_SetWindowSize(g_win, 1280, 760); SDL_SetWindowPosition(g_win, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED); }
        else { SDL_SetWindowSize(g_win, 520, 760); SDL_SetWindowPosition(g_win, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED); }
    }
    if (persist) PersistMode(m);
}
static void OpenSettings() {
    g_ed[0] = g_set.key;
    g_ed[1] = g_set.call_me;
    g_ed[2] = g_set.wake;
    char b[32];
    snprintf(b, sizeof b, "%.1f", g_set.silence);
    g_ed[3] = b;
    g_tConfirm = g_set.confirm;
    g_tFx = g_set.fx_mode;
    g_tAuto = g_set.autostart;
    g_keyShow = false;
    g_focus = 0;
    g_setOpen = true;
    SDL_StartTextInput();
}
static void CloseSettings() {
    g_setOpen = false;
    g_wantSet = 0;
    SDL_StopTextInput();
}
static void SaveSettingsUi() {
    std::string env = ReadFile(g_envPath);
    if (env.empty()) env = kEnvTemplate;
    std::string key;
    for (char c : trim(g_ed[0])) if (!isspace((unsigned char)c) && c != '"' && c != '\'') key += c;  // ключ без пробелов и кавычек
    double sil = atof(g_ed[3].c_str());
    if (sil < 0.4 || sil > 5.0) sil = 1.2;
    char sb[32];
    snprintf(sb, sizeof sb, "%.1f", sil);
    env = set_env_value(env, "GROQ_API_KEY", key);
    env = set_env_value(env, "OPENAI_API_KEY", "", false);  // чтобы старые ключи не перебивали новый
    env = set_env_value(env, "OPENROUTER_API_KEY", "", false);
    env = set_env_value(env, "FLEY_CALL_ME", trim(g_ed[1]));
    env = set_env_value(env, "FLEY_WAKE", trim(g_ed[2]));
    env = set_env_value(env, "FLEY_SILENCE_SECONDS", sb);
    env = set_env_value(env, "FLEY_CONFIRM", g_tConfirm ? "1" : "0");
    env = set_env_value(env, "FLEY_VOICE_FX", std::to_string(g_tFx));
    env = set_env_value(env, "FLEY_AUTOSTART", g_tAuto ? "1" : "0");
    if (!WriteFileText(g_envPath, env)) {
        SetStatus("Не удалось сохранить настройки: нет доступа к файлу " + g_envPath, true);
        return;
    }
    chmod(g_envPath.c_str(), 0600);  // в файле секретный ключ: доступ только владельцу
    ApplyAutostart(g_tAuto);
    g_keyErr = 0;
    g_reloadReq = 1;
    CloseSettings();
    bool known = key.compare(0, 4, "gsk_") == 0 || key.compare(0, 3, "sk-") == 0;
    SetStatus(key.empty() ? "Ключ пустой: введите API-ключ в настройках." : known ? "Настройки сохранены и применены." : "Сохранено, но ключ выглядит необычно (ожидается gsk_…, sk-or-… или sk-…).", key.empty() || !known);
}
static void AnswerConfirm(bool yes) {
    {
        std::lock_guard<std::mutex> lk(g_cfMx);
        g_cfAns = yes ? 1 : 0;
    }
    g_cfCv.notify_all();
    g_cfShow = false;
    SetStatus(yes ? "Разрешено." : "Отказано.");
}
static void Activate(int id) {
    switch (id) {
        case B_ORB: case B_MIC: OnOrbClick(); break;
        case B_CLOSE: g_closing = 1; break;
        case B_MIN: SDL_MinimizeWindow(g_win); break;
        case B_MODE: ApplyMode((g_mode + 1) % 3); break;
        case B_CLEAR: g_log.clear(); g_clearReq = 1; break;
        case B_SET: OpenSettings(); break;
        case S_SHOW: g_keyShow = !g_keyShow; break;
        case S_CLR: g_ed[0].clear(); g_focus = 0; break;
        case S_CONFIRM: g_tConfirm = !g_tConfirm; break;
        case S_FX: g_tFx = (g_tFx + 1) % 3; break;
        case S_AUTO: g_tAuto = !g_tAuto; break;
        case S_SAVE: SaveSettingsUi(); break;
        case S_CANCEL: CloseSettings(); break;
        case S_ENV: EnsureEnvFile(); if (!ShellOpen(g_envPath)) SetStatus("Не удалось открыть .env: " + g_envPath, true); break;
        case S_GET: ShellOpen("https://console.groq.com/keys"); break;
        case S_PASTE: {
            char* cb = SDL_GetClipboardText();
            std::string k = cb ? cb : "";
            if (cb) SDL_free(cb);
            std::string clean;  // ключ без пробелов и переносов
            for (char c : k) if (!isspace((unsigned char)c) && c != '"' && c != '\'') clean += c;
            if (clean.size() < 10) { SetStatus("В буфере обмена нет ключа. Скопируйте ключ (Ctrl+C) на странице console.groq.com/keys.", true); break; }
            g_ed[0] = clean;
            SaveSettingsUi();  // вставили - сразу сохранили и применили
            break;
        }
        case C_YES: AnswerConfirm(true); break;
        case C_NO: AnswerConfirm(false); break;
    }
}
