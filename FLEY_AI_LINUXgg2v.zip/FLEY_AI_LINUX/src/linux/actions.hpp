// FLEY AI (Linux) - управление компьютером голосом: действия [[ACTION: ...]], память, история, таймеры.
#pragma once
#include "platform.hpp"

struct ActResult {
    bool ok = true;
    bool feedback = false;  // результат нужно вернуть модели
    std::string msg;
};
static ActResult Ok(const std::string& m, bool fb = false) { ActResult r; r.ok = true; r.msg = m; r.feedback = fb; return r; }
static ActResult Fail(const std::string& m, bool fb = false) { ActResult r; r.ok = false; r.msg = m; r.feedback = fb; return r; }

// ------------------------------------------------------------------ подтверждение (окно рисует интерфейс)
static std::mutex g_cfMx;
static std::condition_variable g_cfCv;
static std::string g_cfText;
static std::atomic<int> g_cfReq{0}, g_cfAns{-1};  // ans: -1 ждём, 0 нет, 1 да

static bool Confirm(const std::string& what) {
    SetStatus("Жду вашего подтверждения в окне…");
    {
        std::lock_guard<std::mutex> lk(g_cfMx);
        g_cfText = what;
        g_cfAns = -1;
        g_cfReq = 1;
    }
    std::unique_lock<std::mutex> lk(g_cfMx);
    g_cfCv.wait_for(lk, std::chrono::seconds(60), [] { return g_cfAns != -1 || g_closing; });
    bool yes = g_cfAns == 1;
    g_cfReq = 0;
    return yes;
}
static bool NeedConfirm() { return g_set.confirm || g_taint; }

// ------------------------------------------------------------------ пути
static std::string XdgDir(const std::string& name, const std::string& fallback) {
    std::string home = HomeDir(), d = ReadFile(home + "/.config/user-dirs.dirs");
    std::string key = "XDG_" + name + "_DIR=";
    size_t p = 0;
    while (p < d.size()) {
        size_t e = d.find('\n', p);
        std::string line = trim(d.substr(p, e == std::string::npos ? std::string::npos : e - p));
        if (line.compare(0, key.size(), key) == 0) {
            std::string v = line.substr(key.size());
            if (v.size() >= 2 && v.front() == '"') v = v.substr(1, v.size() - 2);
            size_t h = v.find("$HOME");
            if (h != std::string::npos) v.replace(h, 5, home);
            if (!v.empty()) return v;
        }
        if (e == std::string::npos) break;
        p = e + 1;
    }
    return home + "/" + fallback;
}
static std::string UserDirByAlias(const std::string& a) {
    if (a == "desktop" || a == "рабочий стол") return XdgDir("DESKTOP", "Desktop");
    if (a == "documents" || a == "документы" || a == "мои документы") return XdgDir("DOCUMENTS", "Documents");
    if (a == "pictures" || a == "картинки" || a == "изображения" || a == "фото") return XdgDir("PICTURES", "Pictures");
    if (a == "music" || a == "музыка") return XdgDir("MUSIC", "Music");
    if (a == "videos" || a == "видео") return XdgDir("VIDEOS", "Videos");
    if (a == "downloads" || a == "загрузки") return XdgDir("DOWNLOAD", "Downloads");
    if (a == "home" || a == "профиль" || a == "домой") return HomeDir();
    return "";
}
static std::string ExpandPathArg(const std::string& arg) {
    std::string w = trim(arg);
    while (!w.empty() && (w.front() == '"' || w.front() == '\'')) w.erase(w.begin());
    while (!w.empty() && (w.back() == '"' || w.back() == '\'')) w.pop_back();
    for (char& c : w) if (c == '\\') c = '/';
    size_t sep = w.find('/');
    std::string first = lower_utf8(sep == std::string::npos ? w : w.substr(0, sep));
    std::string base = UserDirByAlias(first);
    if (!base.empty()) return base + (sep == std::string::npos ? "" : w.substr(sep));
    if (!w.empty() && w[0] == '~') return HomeDir() + w.substr(1);
    if (w.compare(0, 5, "$HOME") == 0) return HomeDir() + w.substr(5);
    if (w.compare(0, 7, "${HOME}") == 0) return HomeDir() + w.substr(7);
    if (!w.empty() && w[0] != '/') return HomeDir() + "/" + w;
    return w;
}
// Пути, которые нельзя удалять: системные каталоги, корень, домашняя папка и её стандартные папки целиком
static bool IsProtectedPath(const std::string& in) {
    char rp[4096];
    std::string p = realpath(in.c_str(), rp) ? std::string(rp) : in;
    while (p.size() > 1 && p.back() == '/') p.pop_back();
    if (p.empty() || p == "/") return true;
    static const char* sys[] = {"/bin", "/boot", "/dev", "/etc", "/lib", "/lib32", "/lib64", "/libx32", "/proc", "/root", "/run",
                                "/sbin", "/sys", "/usr", "/var", "/snap", "/opt", "/srv", "/lost+found"};
    for (const char* s : sys) {
        std::string x = s;
        if (p == x || p.compare(0, x.size() + 1, x + "/") == 0) return true;
    }
    static const char* tops[] = {"/home", "/mnt", "/media", "/tmp"};
    for (const char* s : tops) if (p == s) return true;
    std::string home = HomeDir();
    if (p == home) return true;
    static const char* dirs[] = {"DESKTOP", "DOCUMENTS", "DOWNLOAD", "PICTURES", "MUSIC", "VIDEOS"};
    static const char* fb[] = {"Desktop", "Documents", "Downloads", "Pictures", "Music", "Videos"};
    for (int i = 0; i < 6; ++i) if (p == XdgDir(dirs[i], fb[i])) return true;
    for (const char* hidden : {"/.ssh", "/.gnupg", "/.config", "/.local", "/.var"})
        if (p == home + hidden) return true;
    if (p.compare(0, 6, "/home/") == 0 && p.find('/', 6) == std::string::npos) return true;  // чужой домашний каталог целиком
    return false;
}

// ------------------------------------------------------------------ запуск программ
static std::vector<std::string> SplitBar(const std::string& s) {
    std::vector<std::string> o;
    size_t st = 0;
    while (st <= s.size()) {
        size_t e = s.find('|', st);
        o.push_back(s.substr(st, e == std::string::npos ? std::string::npos : e - st));
        if (e == std::string::npos) break;
        st = e + 1;
    }
    return o;
}
// разбор строки Exec= из .desktop: кавычки учитываются, коды %f %u и т.п. выбрасываются
static std::vector<std::string> ParseExec(const std::string& ex) {
    std::vector<std::string> out;
    std::string cur;
    bool q = false, has = false;
    for (size_t i = 0; i < ex.size(); ++i) {
        char c = ex[i];
        if (q) {
            if (c == '"') q = false;
            else if (c == '\\' && i + 1 < ex.size()) cur += ex[++i];
            else cur += c;
        } else if (c == '"') { q = true; has = true; }
        else if (isspace((unsigned char)c)) { if (has || !cur.empty()) out.push_back(cur); cur.clear(); has = false; }
        else cur += c;
    }
    if (has || !cur.empty()) out.push_back(cur);
    std::vector<std::string> res;
    for (auto& t : out) {
        if (t.size() == 2 && t[0] == '%') continue;
        if (t == "@@" || t == "@@u") continue;
        res.push_back(t);
    }
    return res;
}
static std::string DesktopField(const std::string& file, const char* key) {
    std::string k = std::string(key) + "=";
    size_t p = 0;
    bool inEntry = false;
    while (p < file.size()) {
        size_t e = file.find('\n', p);
        std::string line = trim(file.substr(p, e == std::string::npos ? std::string::npos : e - p));
        if (!line.empty() && line[0] == '[') inEntry = line == "[Desktop Entry]";
        else if (inEntry && line.compare(0, k.size(), k) == 0) return line.substr(k.size());
        if (e == std::string::npos) break;
        p = e + 1;
    }
    return "";
}
// Ищет установленное приложение по части названия в файлах .desktop (в т.ч. flatpak и snap)
static bool FindDesktopApp(const std::string& needle, std::vector<std::string>& argv) {
    std::vector<std::string> dirs = {"/usr/share/applications", "/usr/local/share/applications", HomeDir() + "/.local/share/applications",
                                     "/var/lib/flatpak/exports/share/applications", HomeDir() + "/.local/share/flatpak/exports/share/applications",
                                     "/var/lib/snapd/desktop/applications"};
    int bestScore = 0;
    std::vector<std::string> best;
    for (auto& d : dirs) {
        DIR* dp = opendir(d.c_str());
        if (!dp) continue;
        while (dirent* en = readdir(dp)) {
            std::string fn = en->d_name;
            if (fn.size() < 9 || fn.compare(fn.size() - 8, 8, ".desktop") != 0) continue;
            std::string txt = ReadFile(d + "/" + fn);
            if (txt.empty() || DesktopField(txt, "NoDisplay") == "true" || DesktopField(txt, "Hidden") == "true") continue;
            if (DesktopField(txt, "Terminal") == "true") continue;
            std::string nm = lower_utf8(DesktopField(txt, "Name")), stem = lower_utf8(fn.substr(0, fn.size() - 8));
            std::string ru = lower_utf8(DesktopField(txt, "Name[ru]"));
            int score = 0;
            if (nm == needle || ru == needle || stem == needle) score = 100;
            else if (nm.compare(0, needle.size(), needle) == 0 || ru.compare(0, needle.size(), needle) == 0) score = 60;
            else if (nm.find(needle) != std::string::npos || ru.find(needle) != std::string::npos || stem.find(needle) != std::string::npos) score = 30;
            if (score > bestScore) {
                std::vector<std::string> av = ParseExec(DesktopField(txt, "Exec"));
                if (!av.empty()) { bestScore = score; best = av; }
            }
        }
        closedir(dp);
    }
    if (bestScore == 0) return false;
    argv = best;
    return true;
}

static ActResult ActOpenApp(const std::string& arg) {
    std::string name = lower_utf8(trim(arg));
    if (name.empty()) return Fail("Не указано, какую программу открыть.");
    struct App { const char* keys; std::vector<std::string> cmds; };
    static const std::vector<App> kApps = {
        {"chrome|google chrome|хром|гугл хром", {"google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "brave-browser"}},
        {"edge|эдж|microsoft edge", {"microsoft-edge", "microsoft-edge-stable"}},
        {"firefox|фаерфокс|файрфокс", {"firefox", "firefox-esr"}},
        {"браузер|browser", {"https://www.google.com"}},
        {"notepad|блокнот|текстовый редактор|editor", {"gnome-text-editor", "gedit", "kate", "kwrite", "mousepad", "xed", "pluma", "leafpad"}},
        {"calc|calculator|калькулятор", {"gnome-calculator", "kcalc", "galculator", "mate-calc", "xfce4-calculator", "qalculate-gtk"}},
        {"paint|пейнт|рисовалка", {"kolourpaint", "pinta", "gimp", "krita", "drawing"}},
        {"explorer|проводник|файлы|файловый менеджер|files", {"nautilus", "dolphin", "thunar", "nemo", "pcmanfm", "caja", "pcmanfm-qt"}},
        {"cmd|командная строка|powershell|терминал|terminal|консоль", {"gnome-terminal", "kgx", "konsole", "xfce4-terminal", "alacritty", "kitty", "tilix", "mate-terminal", "x-terminal-emulator", "xterm"}},
        {"taskmgr|task manager|диспетчер задач|системный монитор", {"gnome-system-monitor", "plasma-systemmonitor", "ksysguard", "xfce4-taskmanager", "mate-system-monitor", "lxtask"}},
        {"settings|параметры|настройки системы|панель управления|control panel", {"gnome-control-center", "systemsettings", "systemsettings5", "xfce4-settings-manager", "cinnamon-settings", "mate-control-center"}},
        {"code|vscode|vs code|visual studio code", {"code", "codium", "code-oss", "vscodium"}},
        {"word|ворд|writer", {"libreoffice --writer", "lowriter", "onlyoffice-desktopeditors"}},
        {"excel|эксель|calc office", {"libreoffice --calc", "localc", "onlyoffice-desktopeditors"}},
        {"powerpoint|презентации|impress", {"libreoffice --impress", "loimpress", "onlyoffice-desktopeditors"}},
        {"outlook|почта|mail", {"thunderbird", "evolution", "geary", "kmail"}},
        {"camera|камера", {"cheese", "kamoso", "guvcview"}},
        {"ножницы|snipping tool|скриншот|screenshot", {"gnome-screenshot", "spectacle", "flameshot", "xfce4-screenshooter"}},
        {"youtube|ютуб", {"https://www.youtube.com"}},
        {"google|гугл", {"https://www.google.com"}},
        {"gmail", {"https://mail.google.com"}},
        {"whatsapp|ватсап", {"https://web.whatsapp.com"}},
        {"telegram|телеграм", {"telegram-desktop", "Telegram", "flatpak run org.telegram.desktop"}},
        {"spotify|спотифай", {"spotify", "flatpak run com.spotify.Client"}},
        {"discord|дискорд", {"discord", "Discord", "flatpak run com.discordapp.Discord"}},
    };
    for (auto& a : kApps) {
        bool hit = false;
        for (auto& k : SplitBar(a.keys)) if (name == k) hit = true;
        if (!hit) continue;
        for (auto& c : a.cmds) {
            if (c.compare(0, 4, "http") == 0) { if (ShellOpen(c)) return Ok("Запущено: " + trim(arg)); continue; }
            if (Spawn(split_words(c))) return Ok("Запущено: " + trim(arg));
        }
        break;  // известная программа, но не установлена: пробуем поиск по .desktop ниже
    }
    std::vector<std::string> av;
    if (FindDesktopApp(name, av) && Spawn(av)) return Ok("Запущено: " + trim(arg));
    bool safe = true;
    for (unsigned char c : name) if (!(isalnum(c) || c == '.' || c == '_' || c == '-')) safe = false;
    if (safe && Spawn({name})) return Ok("Запущено: " + trim(arg));
    return Fail("Не нашёл программу «" + trim(arg) + "» на этом компьютере.");
}

// ------------------------------------------------------------------ YouTube
static bool ValidVideoId(const std::string& id) {
    if (id.size() != 11) return false;
    for (unsigned char c : id) if (!(isalnum(c) || c == '-' || c == '_')) return false;
    return true;
}
static std::string FirstVideoId(const std::string& page) {
    static const char* marks[] = {"\"videoRenderer\":{\"videoId\":\"", "\"videoId\":\"", "/watch?v="};
    for (const char* m : marks) {
        size_t from = 0, ml = strlen(m);
        for (int tries = 0; tries < 8; ++tries) {
            size_t p = page.find(m, from);
            if (p == std::string::npos) break;
            std::string id = page.substr(p + ml, 11);
            if (ValidVideoId(id)) return id;
            from = p + ml;
        }
    }
    return "";
}
static ActResult ActYouTube(const std::string& query, bool play) {
    if (trim(query).empty()) return ShellOpen("https://www.youtube.com") ? Ok("Открыт YouTube.") : Fail("Не удалось открыть YouTube (нет xdg-open).");
    std::string q = url_encode(trim(query));
    if (play) {
        std::string id = FirstVideoId(HttpGetPage("www.youtube.com", "/results?search_query=" + q + "&sp=EgIQAQ%3D%3D&hl=ru"));
        if (id.empty()) id = FirstVideoId(HttpGetPage("www.youtube.com", "/results?search_query=" + q));
        if (id.empty()) {  // запасной путь: поисковик
            std::string page = HttpGetPage("html.duckduckgo.com", "/html/?q=site%3Ayoutube.com%2Fwatch+" + q);
            size_t p = page.find("youtube.com%2Fwatch%3Fv%3D");
            if (p != std::string::npos && ValidVideoId(page.substr(p + 26, 11))) id = page.substr(p + 26, 11);
        }
        if (!id.empty() && ShellOpen("https://www.youtube.com/watch?v=" + id + "&autoplay=1")) {
            g_ensurePlay = 1;  // после ответа проверим, что звук пошёл
            return Ok("Включено видео по запросу: " + trim(query));
        }
    }
    if (ShellOpen("https://www.youtube.com/results?search_query=" + q))
        return Ok(play ? "Автоматически выбрать видео не удалось, открыт список результатов: " + trim(query) : "Открыт поиск YouTube: " + trim(query), play);
    return Fail("Не удалось открыть YouTube.");
}

// ------------------------------------------------------------------ файлы
static void SearchFiles(const std::string& dir, const std::string& needle, int depth, long long deadline, std::vector<std::string>& out, size_t maxOut) {
    if (out.size() >= maxOut || Tick() > deadline) return;
    DIR* d = opendir(dir.c_str());
    if (!d) return;
    std::vector<std::string> subs;
    while (dirent* en = readdir(d)) {
        std::string n = en->d_name;
        if (n == "." || n == "..") continue;
        std::string full = dir + "/" + n;
        struct stat st;
        if (lstat(full.c_str(), &st) != 0) continue;
        bool isDir = S_ISDIR(st.st_mode);
        if (lower_utf8(n).find(needle) != std::string::npos && out.size() < maxOut) out.push_back(full + (isDir ? "/" : ""));
        if (isDir && !S_ISLNK(st.st_mode) && n != "node_modules" && n != ".git" && n[0] != '.' && n != "snap") subs.push_back(full);
    }
    closedir(d);
    if (depth > 0) for (auto& s : subs) SearchFiles(s, needle, depth - 1, deadline, out, maxOut);
}
static ActResult ActFindFile(const Action& a) {
    if (a.args.empty() || trim(a.args[0]).empty()) return Fail("Не указано, что искать.", true);
    std::string needle = lower_utf8(trim(a.args[0]));
    std::vector<std::string> roots;
    if (a.args.size() > 1 && !trim(a.args[1]).empty()) roots.push_back(ExpandPathArg(a.args[1]));
    else
        for (const char* al : {"desktop", "documents", "downloads", "pictures", "music", "videos"}) {
            std::string d = UserDirByAlias(al);
            if (!d.empty() && std::find(roots.begin(), roots.end(), d) == roots.end()) roots.push_back(d);
        }
    std::vector<std::string> found;
    long long deadline = Tick() + 7000;
    for (auto& r : roots) SearchFiles(r, needle, 6, deadline, found, 15);
    if (found.empty()) return Ok("Ничего не найдено по запросу «" + trim(a.args[0]) + "» (искал в личных папках).", true);
    std::string m = "Найдено:\n";
    for (auto& f : found) m += f + "\n";
    return Ok(m, true);
}
static ActResult ActReadFile(const Action& a) {
    if (a.args.empty()) return Fail("Не указан файл.", true);
    std::string p = ExpandPathArg(a.args[0]);
    struct stat st;
    if (stat(p.c_str(), &st) != 0 || S_ISDIR(st.st_mode)) return Fail("Файл не найден: " + p, true);
    size_t dot = p.find_last_of('.'), sl = p.find_last_of('/');
    std::string ext = (dot != std::string::npos && (sl == std::string::npos || dot > sl)) ? to_lower_ascii(p.substr(dot)) : "";
    static const char* ok[] = {".txt", ".md", ".log", ".csv", ".json", ".xml", ".ini", ".cfg", ".conf", ".yaml", ".yml", ".cpp", ".h", ".hpp", ".c",
                               ".py", ".js", ".ts", ".html", ".css", ".sh", ".cs", ".java", ".rs", ".go", ".env", ".toml", ".tex", ".desktop"};
    bool allowed = false;
    for (auto e : ok) if (ext == e) allowed = true;
    if (!allowed) return Fail("Читать можно только текстовые файлы (txt, md, json, код и т.п.), а это: " + (ext.empty() ? std::string("без расширения") : ext), true);
    FILE* f = fopen(p.c_str(), "rb");
    if (!f) return Fail("Не удалось открыть файл.", true);
    std::string buf(8000, '\0');
    size_t n = fread(&buf[0], 1, buf.size(), f);
    fclose(f);
    buf.resize(n);
    if (n >= 3 && (unsigned char)buf[0] == 0xEF && (unsigned char)buf[1] == 0xBB && (unsigned char)buf[2] == 0xBF) buf = buf.substr(3);
    return Ok("Начало файла " + p + ":\n" + utf8_truncate(buf, 6000), true);
}
static ActResult ActListDir(const Action& a) {
    std::string p = ExpandPathArg(a.args.empty() ? "desktop" : a.args[0]);
    DIR* d = opendir(p.c_str());
    if (!d) return Fail("Папка не найдена: " + p, true);
    std::vector<std::string> names;
    while (dirent* en = readdir(d)) {
        std::string n = en->d_name;
        if (n == "." || n == "..") continue;
        names.push_back((IsDir(p + "/" + n) ? "[папка] " : "") + n);
    }
    closedir(d);
    std::sort(names.begin(), names.end());
    std::string m = "Содержимое " + p + ":\n";
    int cnt = 0;
    for (auto& n : names) {
        if (++cnt > 60) { m += "...и ещё файлы\n"; break; }
        m += n + "\n";
    }
    return Ok(m, true);
}
static ActResult ActOpenPath(const Action& a) {
    if (a.args.empty()) return Fail("Не указан путь.");
    std::string p = ExpandPathArg(a.args[0]);
    if (!PathExists(p)) return Fail("Путь не найден: " + p);
    return ShellOpen(p) ? Ok("Открыто: " + p) : Fail("Не удалось открыть: " + p);
}

// ------------------------------------------------------------------ железо и система
static bool CpuTimes(double& idle, double& total) {
    std::string s = ReadFile("/proc/stat");
    unsigned long long v[8] = {};
    if (sscanf(s.c_str(), "cpu %llu %llu %llu %llu %llu %llu %llu %llu", &v[0], &v[1], &v[2], &v[3], &v[4], &v[5], &v[6], &v[7]) < 4) return false;
    idle = (double)(v[3] + v[4]);
    total = 0;
    for (int i = 0; i < 8; ++i) total += (double)v[i];
    return true;
}
static bool MemInfo(double& totalKb, double& availKb) {
    std::string s = ReadFile("/proc/meminfo");
    totalKb = availKb = 0;
    size_t p = s.find("MemTotal:"), q = s.find("MemAvailable:");
    if (p == std::string::npos || q == std::string::npos) return false;
    totalKb = atof(s.c_str() + p + 9);
    availKb = atof(s.c_str() + q + 13);
    return totalKb > 0;
}
static ActResult ActSysInfo() {
    char b[256];
    std::string m;
    std::string cpuinfo = ReadFile("/proc/cpuinfo");
    size_t p = cpuinfo.find("model name");
    if (p != std::string::npos) {
        size_t c = cpuinfo.find(':', p), e = cpuinfo.find('\n', p);
        if (c != std::string::npos && e != std::string::npos) m += "Процессор: " + trim(cpuinfo.substr(c + 1, e - c - 1)) + "\n";
    }
    double i1, t1, i2, t2;
    if (CpuTimes(i1, t1)) {
        Sleep(400);
        if (CpuTimes(i2, t2) && t2 > t1) {
            snprintf(b, sizeof b, "Загрузка процессора: %.0f%%\n", 100.0 * (1.0 - (i2 - i1) / (t2 - t1)));
            m += b;
        }
    }
    double tk, ak;
    if (MemInfo(tk, ak)) {
        snprintf(b, sizeof b, "Оперативная память: занято %.1f из %.1f ГБ (%.0f%%)\n", (tk - ak) / 1048576.0, tk / 1048576.0, 100.0 * (tk - ak) / tk);
        m += b;
    }
    if (HasCmd("lspci")) {
        ProcRes r = RunProc({"lspci"}, "", 3000, false, false);
        size_t pos = 0;
        while (pos < r.out.size()) {
            size_t e = r.out.find('\n', pos);
            std::string line = r.out.substr(pos, e == std::string::npos ? std::string::npos : e - pos);
            if (line.find("VGA") != std::string::npos || line.find("3D controller") != std::string::npos) {
                size_t c = line.find(": ");
                m += "Видеокарта: " + (c != std::string::npos ? line.substr(c + 2) : line) + "\n";
                break;
            }
            if (e == std::string::npos) break;
            pos = e + 1;
        }
    }
    {   // диски: настоящие файловые системы из /proc/mounts
        std::string mounts = ReadFile("/proc/mounts");
        std::set<std::string> seenDev;
        size_t pos = 0;
        static const std::set<std::string> fsOk = {"ext4", "ext3", "ext2", "btrfs", "xfs", "f2fs", "ntfs", "ntfs3", "fuseblk", "vfat", "exfat", "zfs"};
        while (pos < mounts.size()) {
            size_t e = mounts.find('\n', pos);
            std::vector<std::string> f = split_words(mounts.substr(pos, e == std::string::npos ? std::string::npos : e - pos));
            if (f.size() >= 3 && fsOk.count(f[2]) && seenDev.insert(f[0]).second && f[1].compare(0, 5, "/boot") != 0 && f[1].compare(0, 5, "/snap") != 0) {
                struct statvfs sv;
                std::string mp = f[1];
                for (size_t k; (k = mp.find("\\040")) != std::string::npos;) mp.replace(k, 4, " ");
                if (statvfs(mp.c_str(), &sv) == 0 && sv.f_blocks > 0) {
                    snprintf(b, sizeof b, "Диск %s: свободно %.0f из %.0f ГБ\n", mp.c_str(), (double)sv.f_bavail * sv.f_frsize / 1073741824.0,
                             (double)sv.f_blocks * sv.f_frsize / 1073741824.0);
                    m += b;
                }
            }
            if (e == std::string::npos) break;
            pos = e + 1;
        }
    }
    {   // батарея
        DIR* d = opendir("/sys/class/power_supply");
        while (d) {
            dirent* en = readdir(d);
            if (!en) break;
            std::string n = en->d_name;
            if (n.compare(0, 3, "BAT") != 0) continue;
            std::string cap = trim(ReadFile("/sys/class/power_supply/" + n + "/capacity")), stt = trim(ReadFile("/sys/class/power_supply/" + n + "/status"));
            if (!cap.empty()) m += "Батарея: " + cap + "%, " + (stt == "Charging" || stt == "Full" ? "от сети" : "от батареи") + "\n";
            break;
        }
        if (d) closedir(d);
    }
    double up = atof(ReadFile("/proc/uptime").c_str());
    snprintf(b, sizeof b, "Работает без перезагрузки: %d ч %d мин\n", (int)(up / 3600), (int)std::fmod(up / 60, 60.0));
    m += b;
    return Ok(m, true);
}

// ------------------------------------------------------------------ громкость, медиа, клавиатура
static bool Run0(const std::vector<std::string>& a, int timeoutMs = 5000) {
    if (a.empty() || !HasCmd(a[0])) return false;
    ProcRes r = RunProc(a, "", timeoutMs, false, false);
    return r.code == 0;
}
static bool IsWayland() {
    const char* t = getenv("XDG_SESSION_TYPE");
    return t && std::string(t) == "wayland";
}
// Нажатие сочетания клавиш: xdotool (X11) или wtype (Wayland). Имена клавиш - как в xdotool/xkb.
static bool SendKeys(const std::vector<std::string>& mods, const std::string& key) {
    bool wl = IsWayland();
    if (wl && HasCmd("wtype")) {
        std::vector<std::string> a = {"wtype"};
        for (auto& m : mods) { a.push_back("-M"); a.push_back(m == "super" ? "logo" : m); }
        if (!key.empty()) { a.push_back("-k"); a.push_back(key); }
        for (size_t i = mods.size(); i-- > 0;) { a.push_back("-m"); a.push_back(mods[i] == "super" ? "logo" : mods[i]); }
        return Run0(a);
    }
    if (HasCmd("xdotool")) {
        std::string combo;
        for (auto& m : mods) combo += m + "+";
        combo += key;
        if (key.empty() && !combo.empty()) combo.pop_back();
        return Run0({"xdotool", "key", "--clearmodifiers", combo});
    }
    if (wl && HasCmd("ydotool")) return false;  // ydotool требует кодов клавиш: не поддерживаем
    return false;
}
static ActResult NoInputTool() {
    return Fail(IsWayland() ? "Для ввода с клавиатуры в Wayland нужен wtype: sudo apt install wtype" : "Для ввода с клавиатуры нужен xdotool: sudo apt install xdotool");
}
static ActResult ActVolume(const Action& a) {
    std::string mode = a.args.empty() ? "" : to_lower_ascii(a.args[0]);
    int n = a.args.size() > 1 ? atoi(a.args[1].c_str()) : 5;
    bool pa = HasCmd("pactl");
    // sign: '+' прибавить, '-' убавить, '=' установить; pct - проценты
    auto setVol = [&](char sign, int pct) -> bool {
        std::string pv = (sign == '=' ? "" : std::string(1, sign)) + std::to_string(pct) + "%";
        if (pa && Run0({"pactl", "set-sink-volume", "@DEFAULT_SINK@", pv})) return true;
        std::string tail = sign == '=' ? "" : std::string(1, sign);
        if (HasCmd("wpctl") && Run0({"wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", std::to_string(pct) + "%" + tail})) return true;
        return Run0({"amixer", "-q", "sset", "Master", std::to_string(pct) + "%" + tail});
    };
    if (mode == "mute" || mode == "unmute") {
        if ((pa && Run0({"pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"})) || Run0({"wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"}) ||
            Run0({"amixer", "-q", "sset", "Master", "toggle"}))
            return Ok("Звук включён/выключен.");
        return Fail("Не удалось изменить звук (нужен pactl, wpctl или amixer).");
    }
    if (mode == "up") return setVol('+', std::max(1, std::min(n, 50)) * 2) ? Ok("Громкость увеличена.") : Fail("Не удалось изменить громкость (нужен pactl, wpctl или amixer).");
    if (mode == "down") return setVol('-', std::max(1, std::min(n, 50)) * 2) ? Ok("Громкость уменьшена.") : Fail("Не удалось изменить громкость (нужен pactl, wpctl или amixer).");
    if (mode == "set") {
        int pct = std::max(0, std::min(a.args.size() > 1 ? atoi(a.args[1].c_str()) : 50, 100));
        return setVol('=', pct) ? Ok("Громкость " + std::to_string(pct) + "%.") : Fail("Не удалось изменить громкость.");
    }
    return Fail("Неизвестная команда громкости.");
}
static ActResult ActMedia(const Action& a) {
    std::string m = a.args.empty() ? "" : to_lower_ascii(a.args[0]);
    const char *pc = nullptr, *xk = nullptr, *ok = nullptr;
    if (m == "play_pause" || m == "play" || m == "pause") { pc = "play-pause"; xk = "XF86AudioPlay"; ok = "Пауза/воспроизведение."; }
    else if (m == "next") { pc = "next"; xk = "XF86AudioNext"; ok = "Следующий трек."; }
    else if (m == "prev" || m == "previous") { pc = "previous"; xk = "XF86AudioPrev"; ok = "Предыдущий трек."; }
    else if (m == "stop") { pc = "stop"; xk = "XF86AudioStop"; ok = "Остановлено."; }
    else return Fail("Неизвестная медиа-команда.");
    if (Run0({"playerctl", pc})) return Ok(ok);
    if (SendKeys({}, xk)) return Ok(ok);
    return Fail("Для управления медиа нужен playerctl: sudo apt install playerctl");
}
static ActResult ActType(const std::string& text) {
    if (text.empty()) return Fail("Нечего печатать.");
    if (IsWayland() && HasCmd("wtype")) return Run0({"wtype", "--", text}, 30000) ? Ok("Напечатано.") : Fail("wtype не сработал.");
    if (HasCmd("xdotool")) return Run0({"xdotool", "type", "--clearmodifiers", "--delay", "6", "--", text}, 60000) ? Ok("Напечатано.") : Fail("xdotool не сработал.");
    return NoInputTool();
}
static ActResult ActKey(const std::string& spec) {
    std::vector<std::string> mods;
    std::string key;
    size_t st = 0;
    std::string s = to_lower_ascii(trim(spec));
    static const std::map<std::string, std::string> names = {
        {"enter", "Return"}, {"return", "Return"}, {"tab", "Tab"}, {"esc", "Escape"}, {"escape", "Escape"}, {"space", "space"},
        {"backspace", "BackSpace"}, {"delete", "Delete"}, {"del", "Delete"}, {"up", "Up"}, {"down", "Down"}, {"left", "Left"},
        {"right", "Right"}, {"home", "Home"}, {"end", "End"}, {"pageup", "Prior"}, {"pagedown", "Next"}};
    while (st <= s.size()) {
        size_t plus = s.find('+', st);
        std::string tk = trim(s.substr(st, plus == std::string::npos ? std::string::npos : plus - st));
        if (tk == "ctrl" || tk == "control") mods.push_back("ctrl");
        else if (tk == "alt") mods.push_back("alt");
        else if (tk == "shift") mods.push_back("shift");
        else if (tk == "win" || tk == "windows" || tk == "cmd" || tk == "super") mods.push_back("super");
        else if (names.count(tk)) key = names.at(tk);
        else if (tk.size() >= 2 && tk[0] == 'f' && atoi(tk.c_str() + 1) >= 1 && atoi(tk.c_str() + 1) <= 12) key = "F" + std::to_string(atoi(tk.c_str() + 1));
        else if (tk.size() == 1 && isalnum((unsigned char)tk[0])) key = tk;
        if (plus == std::string::npos) break;
        st = plus + 1;
    }
    if (key.empty() && mods.empty()) return Fail("Не понял сочетание клавиш: " + spec);
    if (!HasCmd("xdotool") && !(IsWayland() && HasCmd("wtype"))) return NoInputTool();
    return SendKeys(mods, key) ? Ok("Нажато: " + spec) : Fail("Не удалось нажать: " + spec);
}

// ------------------------------------------------------------------ опасные действия (с подтверждением, если оно включено или был недоверенный ввод)
static ActResult ActLock() {
    if (Run0({"loginctl", "lock-session"}) || Run0({"xdg-screensaver", "lock"}) || Run0({"gnome-screensaver-command", "-l"}) || Run0({"dm-tool", "lock"}) ||
        Run0({"qdbus", "org.freedesktop.ScreenSaver", "/ScreenSaver", "Lock"}))
        return Ok("Компьютер заблокирован.");
    return Fail("Не удалось заблокировать экран (нужен loginctl или xdg-screensaver).");
}
static ActResult ActRun(const Action& a) {
    if (a.args.empty() || trim(a.args[0]).empty()) return Fail("Не указана команда.", true);
    std::string cmd = a.args[0];
    for (size_t i = 1; i < a.args.size(); ++i) cmd += " | " + a.args[i];  // pipe внутри команды
    if (NeedConfirm() && !Confirm("FLEY AI хочет выполнить команду на вашем компьютере:\n\n" + cmd)) return Fail("Пользователь отказал в подтверждении.", true);
    ProcRes r = RunProc({"/bin/sh", "-c", cmd}, "", 20000);
    if (r.timedOut) return Fail("Команда не завершилась за 20 секунд и была остановлена.\n" + utf8_truncate(r.out, 2500), true);
    return Ok("Код завершения " + std::to_string(r.code) + ". Вывод:\n" + utf8_truncate(trim(r.out), 3000), true);
}
static ActResult ActDelete(const Action& a) {
    if (a.args.empty()) return Fail("Не указан путь.");
    std::string p = ExpandPathArg(a.args[0]);
    if (!PathExists(p)) return Fail("Путь не найден: " + p);
    if (IsProtectedPath(p)) return Fail("Этот путь защищён, удалять его нельзя.");
    if (NeedConfirm() && !Confirm("FLEY AI хочет переместить в Корзину:\n\n" + p)) return Fail("Пользователь отказал в подтверждении.");
    // только в Корзину: безвозвратного удаления (rm) программа не делает
    if (Run0({"gio", "trash", "--", p}, 20000) || Run0({"trash-put", "--", p}, 20000) || Run0({"kioclient5", "move", p, "trash:/"}, 20000))
        return Ok("Перемещено в Корзину: " + p);
    return Fail("Не удалось переместить в Корзину (нужен gio или trash-cli): " + p);
}
static std::string SafeProcName(const std::string& in) {
    std::string o;
    for (unsigned char c : trim(in)) if (isalnum(c) || c == '.' || c == '_' || c == '-' || c == '+') o += (char)c;
    if (o.size() > 4 && to_lower_ascii(o).compare(o.size() - 4, 4, ".exe") == 0) o.resize(o.size() - 4);
    if (o.size() > 15) o.resize(15);  // имя процесса в ядре обрезается до 15 символов
    return o;
}
static ActResult ActCloseApp(const Action& a) {
    std::string name = a.args.empty() ? "" : SafeProcName(a.args[0]);
    if (name.empty() || name[0] == '-') return Fail("Не указано имя программы.");
    if (NeedConfirm() && !Confirm("FLEY AI хочет закрыть программу:\n\n" + name)) return Fail("Пользователь отказал в подтверждении.");
    if (Run0({"pkill", "-x", name}) || Run0({"pkill", "-i", "-x", name})) return Ok("Программа закрыта: " + name);
    return Fail("Не удалось закрыть (возможно, она не запущена): " + name);
}
static std::atomic<int> g_powerGen{0};
static ActResult ActPower(const Action& a) {
    std::string m = a.args.empty() ? "" : to_lower_ascii(a.args[0]);
    if (m == "cancel") { g_powerGen++; return Ok("Выключение или перезагрузка отменены."); }
    std::vector<std::string> cmd;
    std::string what, done;
    bool delayed = false;
    if (m == "shutdown") { cmd = {"systemctl", "poweroff"}; what = "ВЫКЛЮЧИТЬ компьютер (через 30 секунд)"; done = "Компьютер выключится через 30 секунд. Можно отменить командой «отмени выключение»."; delayed = true; }
    else if (m == "restart") { cmd = {"systemctl", "reboot"}; what = "ПЕРЕЗАГРУЗИТЬ компьютер (через 30 секунд)"; done = "Перезагрузка через 30 секунд. Можно отменить командой «отмени выключение»."; delayed = true; }
    else if (m == "logoff") { struct passwd* pw = getpwuid(getuid()); cmd = {"loginctl", "terminate-user", pw && pw->pw_name ? pw->pw_name : std::to_string((long)getuid())}; what = "ВЫЙТИ из учётной записи"; done = "Выход из системы."; }
    else if (m == "sleep") { cmd = {"systemctl", "suspend"}; what = "перевести компьютер в СОН"; done = "Перевожу в сон."; }
    else if (m == "hibernate") { cmd = {"systemctl", "hibernate"}; what = "перевести компьютер в ГИБЕРНАЦИЮ"; done = "Гибернация."; }
    else return Fail("Неизвестная команда питания.");
    if (NeedConfirm() && !Confirm("FLEY AI хочет " + what + ".")) return Fail("Пользователь отказал в подтверждении.");
    if (delayed) {
        int gen = ++g_powerGen;
        std::thread([cmd, gen] {
            for (int i = 0; i < 300 && !g_closing; ++i) { Sleep(100); if (g_powerGen != gen) return; }
            if (g_powerGen == gen && !g_closing) Run0(cmd, 15000);
        }).detach();
        return Ok(done);
    }
    return Run0(cmd, 15000) ? Ok(done) : Fail("Не удалось выполнить команду питания.");
}

// ------------------------------------------------------------------ память (долговременная) и история диалога
static std::vector<std::string> g_facts;
static std::string MemPath() { return g_dir + "/fley_memory.txt"; }
static void LoadMemory() {
    g_facts.clear();
    std::string d = ReadFile(MemPath());
    size_t p = 0;
    while (p < d.size()) {
        size_t e = d.find('\n', p);
        std::string line = trim(d.substr(p, e == std::string::npos ? std::string::npos : e - p));
        if (!line.empty()) g_facts.push_back(line);
        if (e == std::string::npos) break;
        p = e + 1;
    }
    g_factCount = (int)g_facts.size();
}
static void SaveMemory() {
    std::string o;
    for (auto& f : g_facts) o += f + "\n";
    WriteFileText(MemPath(), o);
    g_factCount = (int)g_facts.size();
}
static std::string MemoryBlock() {
    if (g_facts.empty()) return "";
    std::vector<std::string> pick;
    size_t total = 0;
    for (size_t i = g_facts.size(); i-- > 0;) {
        if (total + g_facts[i].size() > 2500) break;
        total += g_facts[i].size() + 3;
        pick.push_back(g_facts[i]);
    }
    std::string m = "\nДОЛГОВРЕМЕННАЯ ПАМЯТЬ (факты о пользователе, которые ты помнишь):\n";
    for (size_t i = pick.size(); i-- > 0;) m += "- " + pick[i] + "\n";
    return m;
}
static ActResult ActRemember(const Action& a) {
    std::string f = a.args.empty() ? "" : trim(a.args[0]);
    for (char& c : f) if (c == '\n' || c == '\r') c = ' ';
    f = utf8_truncate(f, 300);
    if (f.empty()) return Fail("Пустой факт.");
    for (auto& x : g_facts) if (x == f) return Ok("Уже помню.");
    g_facts.push_back(f);
    if (g_facts.size() > 300) g_facts.erase(g_facts.begin());
    SaveMemory();
    return Ok("Запомнил: " + f);
}
static ActResult ActForget(const Action& a) {
    std::string needle = lower_utf8(a.args.empty() ? "" : trim(a.args[0]));
    if (needle.empty()) return Fail("Не указано, что забыть.");
    size_t before = g_facts.size();
    std::vector<std::string> keep;
    for (auto& x : g_facts) if (lower_utf8(x).find(needle) == std::string::npos) keep.push_back(x);
    g_facts.swap(keep);
    SaveMemory();
    return Ok("Забыто записей: " + std::to_string(before - g_facts.size()));
}
static std::string EscLine(const std::string& s) {
    std::string o;
    for (char c : s) { if (c == '\\') o += "\\\\"; else if (c == '\n') o += "\\n"; else if (c != '\r') o += c; }
    return o;
}
static std::string UnescLine(const std::string& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '\\' && i + 1 < s.size()) { ++i; o += s[i] == 'n' ? '\n' : s[i]; }
        else o += s[i];
    }
    return o;
}
static void SaveHistory() {
    std::string o;
    size_t from = g_hist.size() > 40 ? g_hist.size() - 40 : 0;
    for (size_t i = from; i < g_hist.size(); ++i)
        o += std::string(g_hist[i].first == "user" ? "U\t" : "A\t") + EscLine(utf8_truncate(g_hist[i].second, 1500)) + "\n";
    WriteFileText(g_dir + "/fley_history.txt", o);
}
static void LoadHistory() {
    g_hist.clear();
    std::string d = ReadFile(g_dir + "/fley_history.txt");
    size_t p = 0;
    while (p < d.size()) {
        size_t e = d.find('\n', p);
        std::string line = d.substr(p, e == std::string::npos ? std::string::npos : e - p);
        if (line.size() >= 2 && line[1] == '\t') g_hist.push_back({line[0] == 'U' ? "user" : "assistant", UnescLine(line.substr(2))});
        if (e == std::string::npos) break;
        p = e + 1;
    }
    while (!g_hist.empty() && g_hist.front().first != "user") g_hist.erase(g_hist.begin());
}

// ------------------------------------------------------------------ интернет-поиск
static std::string StripTags(const std::string& s) {
    std::string o;
    bool tag = false;
    for (char c : s) { if (c == '<') tag = true; else if (c == '>') tag = false; else if (!tag) o += c; }
    static const char* ent[][2] = {{"&amp;", "&"}, {"&quot;", "\""}, {"&#x27;", "'"}, {"&#39;", "'"}, {"&lt;", "<"}, {"&gt;", ">"}, {"&nbsp;", " "}};
    for (auto& e : ent) {
        size_t p;
        while ((p = o.find(e[0])) != std::string::npos) o.replace(p, strlen(e[0]), e[1]);
    }
    return trim(o);
}
static ActResult ActWebSearch(const std::string& q) {
    if (trim(q).empty()) return Fail("Пустой запрос.", true);
    std::string page = HttpGetPage("html.duckduckgo.com", "/html/?q=" + url_encode(trim(q)));
    std::string m;
    size_t pos = 0;
    int n = 0;
    while (n < 6) {
        size_t a = page.find("class=\"result__a\"", pos);
        if (a == std::string::npos) break;
        size_t ta = page.find('>', a), te = page.find("</a>", ta == std::string::npos ? a : ta);
        if (ta == std::string::npos || te == std::string::npos) break;
        std::string title = StripTags(page.substr(ta + 1, te - ta - 1));
        std::string snip;
        size_t sa = page.find("class=\"result__snippet\"", te);
        size_t nextRes = page.find("class=\"result__a\"", te);
        if (sa != std::string::npos && (nextRes == std::string::npos || sa < nextRes)) {
            size_t sb = page.find('>', sa), se = page.find("</a>", sb == std::string::npos ? sa : sb);
            if (sb != std::string::npos && se != std::string::npos) snip = StripTags(page.substr(sb + 1, se - sb - 1));
            pos = se == std::string::npos ? te : se;
        } else pos = te;
        ++n;
        m += std::to_string(n) + ". " + title + (snip.empty() ? "" : " - " + snip) + "\n";
    }
    if (m.empty()) return Fail("Поиск в интернете ничего не вернул (возможно, сайт недоступен). Предложи открыть поиск в браузере.", true);
    return Ok("Результаты поиска по «" + trim(q) + "»:\n" + utf8_truncate(m, 3500), true);
}

// ------------------------------------------------------------------ проверка, что видео заиграло
static std::string ActiveWindowTitle() {
    if (IsWayland() || !HasCmd("xdotool")) return "";
    ProcRes r = RunProc({"xdotool", "getactivewindow", "getwindowname"}, "", 2000, false, false);
    return r.code == 0 ? trim(r.out) : "";
}
static bool AudioPlaying(int ms) {
    if (!HasCmd("pactl")) return true;  // проверить нечем: считаем, что играет
    long long end = Tick() + ms;
    do {
        ProcRes r = RunProc({"pactl", "list", "sink-inputs"}, "", 2000, false, false);
        if (r.out.find("Corked: no") != std::string::npos) return true;
        Sleep(150);
    } while (Tick() < end && !g_closing);
    return false;
}
static void EnsurePlaying() {
    if (IsWayland() || !HasCmd("xdotool")) return;  // без xdotool окно браузера не определить
    auto isYt = [] { return ActiveWindowTitle().find("YouTube") != std::string::npos; };
    long long t0 = Tick();
    while (!isYt() && Tick() - t0 < 9000 && !g_closing) Sleep(300);
    if (!isYt() || g_closing) return;
    Sleep(1200);
    if (AudioPlaying(1500)) return;
    SetStatus("Запускаю воспроизведение…");
    for (int i = 0; i < 2 && !g_closing; ++i) {  // клавиша K в YouTube = пуск/пауза
        if (!isYt()) return;
        ActKey("k");
        Sleep(700);
        if (AudioPlaying(1600)) return;
    }
}
static ActResult ActWait(const std::string& ms) {
    int n = std::max(0, std::min(atoi(ms.c_str()), 10000));
    for (int i = 0; i < n && !g_closing; i += 50) Sleep(50);
    return Ok("Подождал.");
}

// ------------------------------------------------------------------ напоминания и таймеры: "timer | минуты | текст"
static std::mutex g_remMx;
static std::vector<std::string> g_remDue;
static ActResult ActTimer(const Action& a) {
    double min = a.args.empty() ? 0 : atof(a.args[0].c_str());
    if (min <= 0 || min > 24 * 60) return Fail("Укажите время от 1 секунды до 24 часов (в минутах).");
    std::string what = a.args.size() > 1 ? trim(a.args[1]) : "Время вышло";
    if (what.empty()) what = "Время вышло";
    double sec = min * 60.0;
    std::thread([sec, what] {
        long long until = Tick() + (long long)(sec * 1000.0);
        while (Tick() < until && !g_closing) Sleep(250);
        if (!g_closing) {
            std::lock_guard<std::mutex> lk(g_remMx);
            g_remDue.push_back(what);
            g_remFlag = 1;
        }
    }).detach();
    return Ok("Таймер поставлен на " + std::to_string((int)std::lround(sec)) + " с: " + what);
}

static ActResult RunAction(const Action& a) {
    const std::string& t = a.type;
    const std::string a0 = a.args.empty() ? "" : a.args[0];
    if (t == "mic_off") { g_online = 0; return Ok("Микрофон выключен."); }
    if (t == "remember") return ActRemember(a);
    if (t == "forget") return ActForget(a);
    if (t == "web_search" || t == "web") return ActWebSearch(a0);
    if (t == "type") return ActType(a0);
    if (t == "key") return ActKey(a0);
    if (t == "wait") return ActWait(a0);
    if (t == "timer" || t == "remind") return ActTimer(a);
    if (t == "open_app") return ActOpenApp(a0);
    if (t == "open_url") {
        if (!is_http_url(a0)) return Fail("Разрешены только обычные ссылки http/https.");
        return ShellOpen(a0) ? Ok("Открыта ссылка.") : Fail("Не удалось открыть ссылку.");
    }
    if (t == "youtube") return ActYouTube(a0, false);
    if (t == "youtube_play") return ActYouTube(a0, true);
    if (t == "search") {
        if (trim(a0).empty()) return Fail("Пустой поисковый запрос.");
        return ShellOpen("https://www.google.com/search?q=" + url_encode(trim(a0))) ? Ok("Открыт поиск: " + trim(a0)) : Fail("Не удалось открыть поиск.");
    }
    if (t == "open_path") return ActOpenPath(a);
    if (t == "find_file") return ActFindFile(a);
    if (t == "read_file") return ActReadFile(a);
    if (t == "list_dir") return ActListDir(a);
    if (t == "sysinfo") return ActSysInfo();
    if (t == "volume") return ActVolume(a);
    if (t == "media") return ActMedia(a);
    if (t == "lock") return ActLock();
    if (t == "run") return ActRun(a);
    if (t == "delete") return ActDelete(a);
    if (t == "close_app") return ActCloseApp(a);
    if (t == "power") return ActPower(a);
    return Fail("Неизвестное действие: " + t);
}
static std::string DescribeAction(const Action& a) {
    std::string s = a.type;
    for (size_t i = 0; i < a.args.size(); ++i) s += (i ? " | " : ": ") + a.args[i];
    return utf8_truncate(s, 200);
}
