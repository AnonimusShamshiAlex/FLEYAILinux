// FLEY AI (Linux) - платформенный слой: состояние, файлы, HTTP (libcurl), процессы, звук (SDL2).
// Подключается из main_linux.cpp. Переносимое ядро - ../core.hpp (то же, что в Windows-версии).
#pragma once

#include <SDL2/SDL.h>
#include <curl/curl.h>

#include <dirent.h>
#include <fcntl.h>
#include <poll.h>
#include <pwd.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <map>
#include <mutex>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#include "../core.hpp"

using namespace fley;

// ------------------------------------------------------------------ состояние
enum State { IDLE = 0, LISTENING, THINKING, SPEAKING };
static std::atomic<int> g_state{IDLE}, g_keyErr{0}, g_remFlag{0}, g_online{1}, g_stopSpeak{0}, g_closing{0}, g_clearReq{0},
    g_taint{0}, g_ensurePlay{0}, g_reloadReq{0}, g_wantSet{0}, g_level1000{0}, g_factCount{0};

static std::mutex g_mx;  // защищает g_status и очередь журнала
static std::string g_status = "Запуск…";
static bool g_statusErr = false;
static Settings g_set;
static std::map<std::string, std::string> g_env;
static std::vector<std::pair<std::string, std::string>> g_hist;
static std::string g_dir, g_envPath, g_exePath;

// Ключ по умолчанию НЕ зашит в программу: его вводят в окне НАСТРОЙКИ или пишут в .env.
static const char* kDefaultKey = "";

struct LogMsg { int role; std::string text; };
static std::vector<LogMsg> g_pendingLog;

static long long Tick() {
    using namespace std::chrono;
    return (long long)duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}
static void Sleep(int ms) { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }

// ------------------------------------------------------------------ файлы и журнал
static std::string ReadFile(const std::string& path) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return "";
    std::string out;
    char buf[65536];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) out.append(buf, n);
    fclose(f);
    return out;
}
static bool WriteFileText(const std::string& path, const std::string& data, const char* mode = "wb") {
    FILE* f = fopen(path.c_str(), mode);
    if (!f) return false;
    bool ok = fwrite(data.data(), 1, data.size(), f) == data.size();
    fclose(f);
    return ok;
}
static bool PathExists(const std::string& p) {
    struct stat st;
    return stat(p.c_str(), &st) == 0;
}
static bool IsDir(const std::string& p) {
    struct stat st;
    return stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}
static std::string HomeDir() {
    const char* h = getenv("HOME");
    if (h && *h) return h;
    struct passwd* pw = getpwuid(getuid());
    return pw && pw->pw_dir ? pw->pw_dir : "/tmp";
}
static void LogLine(const std::string& msg) {
    char ts[32];
    time_t t = time(nullptr);
    struct tm tmv;
    localtime_r(&t, &tmv);
    strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S ", &tmv);
    WriteFileText(g_dir + "/fley.log", std::string(ts) + msg + "\n", "ab");
}
static void SetStatus(const std::string& t, bool err = false) {
    std::lock_guard<std::mutex> lk(g_mx);
    g_status = t;
    g_statusErr = err;
}
static void PostLog(int role, const std::string& text) {
    std::lock_guard<std::mutex> lk(g_mx);
    g_pendingLog.push_back({role, text});
}

// ------------------------------------------------------------------ настройки (.env)
static const char* kEnvTemplate =
    "# FLEY AI - настройки. Не отправляйте этот файл другим людям: тут ваш ключ!\n"
    "# Подходит ключ Groq (gsk_...), OpenRouter (sk-or-...) или OpenAI (sk-...).\n"
    "# Бесплатный ключ Groq: https://console.groq.com/keys  (или кнопка в окне НАСТРОЙКИ)\n"
    "GROQ_API_KEY=\n"
    "# FLEY_PC_CONTROL=1\n"
    "# FLEY_CONFIRM=0\n"
    "# FLEY_SILENCE_SECONDS=1.2\n"
    "# FLEY_REASONING=low\n"
    "# FLEY_VOICE_PITCH=0.96\n"
    "# FLEY_VOICE_RATE=1.0\n"
    "# FLEY_VOICE_FX=1\n"
    "# FLEY_WINDOW_MODE=full\n"
    "# FLEY_CALL_ME=\n"
    "# Озвучка на Linux: espeak-ng (по умолчанию) или Piper (лучше качество):\n"
    "# FLEY_PIPER_MODEL=/путь/к/ru_RU-denis-medium.onnx\n";

static void EnsureEnvFile() {
    if (!PathExists(g_envPath)) {
        WriteFileText(g_envPath, kEnvTemplate);
        chmod(g_envPath.c_str(), 0600);
    }
}
static std::string EnvGet(const char* k) {
    auto it = g_env.find(k);
    return it == g_env.end() ? "" : trim(it->second);
}
static void LoadSettings() {
    g_env = parse_env(ReadFile(g_envPath));
    g_set = make_settings(g_env, kDefaultKey);
}
static bool NeedKey() {
    if (!g_set.key.empty()) return false;
    g_wantSet = 1;  // окно настроек откроет интерфейс
    SetStatus("Нужен API-ключ: создайте бесплатный на console.groq.com/keys и вставьте в настройках.", true);
    return true;
}

// ------------------------------------------------------------------ HTTP (libcurl)
struct HttpRes {
    int status = 0;
    std::string body, ctype, errstr;
    int err = 0;    // код curl
    int retry = 0;  // заголовок Retry-After, сек
};
static size_t CurlWrite(char* p, size_t s, size_t n, void* u) {
    std::string* b = (std::string*)u;
    if (b->size() > 40u * 1024 * 1024) return 0;
    b->append(p, s * n);
    return s * n;
}
static size_t CurlHeader(char* p, size_t s, size_t n, void* u) {
    std::string h(p, s * n);
    if (to_lower_ascii(h).compare(0, 12, "retry-after:") == 0) *(int*)u = std::atoi(h.c_str() + 12);
    return s * n;
}
static HttpRes HttpDo(const std::string& url, const char* post, const std::string& body, const std::vector<std::string>& headers,
                      long connectS, long totalS, const char* ua) {
    HttpRes r;
    CURL* c = curl_easy_init();
    if (!c) { r.err = -1; r.errstr = "curl init"; return r; }
    std::string out;
    int retry = 0;
    char errbuf[CURL_ERROR_SIZE] = {};
    struct curl_slist* hl = nullptr;
    for (auto& h : headers) hl = curl_slist_append(hl, h.c_str());
    curl_easy_setopt(c, CURLOPT_URL, url.c_str());
    curl_easy_setopt(c, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(c, CURLOPT_CONNECTTIMEOUT, connectS);
    curl_easy_setopt(c, CURLOPT_TIMEOUT, totalS);
    curl_easy_setopt(c, CURLOPT_USERAGENT, ua);
    curl_easy_setopt(c, CURLOPT_ACCEPT_ENCODING, "");
    curl_easy_setopt(c, CURLOPT_ERRORBUFFER, errbuf);
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, CurlWrite);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, &out);
    curl_easy_setopt(c, CURLOPT_HEADERFUNCTION, CurlHeader);
    curl_easy_setopt(c, CURLOPT_HEADERDATA, &retry);
    if (hl) curl_easy_setopt(c, CURLOPT_HTTPHEADER, hl);
    if (post) {
        curl_easy_setopt(c, CURLOPT_POST, 1L);
        curl_easy_setopt(c, CURLOPT_POSTFIELDS, body.data());
        curl_easy_setopt(c, CURLOPT_POSTFIELDSIZE_LARGE, (curl_off_t)body.size());
    }
    CURLcode rc = curl_easy_perform(c);
    r.body.swap(out);
    r.retry = retry;
    if (rc == CURLE_OK || (rc == CURLE_WRITE_ERROR && !r.body.empty())) {
        long code = 0;
        curl_easy_getinfo(c, CURLINFO_RESPONSE_CODE, &code);
        r.status = (int)code;
        char* ct = nullptr;
        curl_easy_getinfo(c, CURLINFO_CONTENT_TYPE, &ct);
        if (ct) r.ctype = ct;
    } else {
        r.err = (int)rc;
        r.errstr = errbuf[0] ? errbuf : curl_easy_strerror(rc);
    }
    if (hl) curl_slist_free_all(hl);
    curl_easy_cleanup(c);
    return r;
}
static HttpRes HttpPost(const std::string& path, const std::string& ctype, const std::string& body, bool tts = false) {
    const std::string& host = tts ? g_set.tts_host : g_set.host;
    const std::string& base = tts ? g_set.tts_path : g_set.base_path;
    const std::string& key = tts ? g_set.tts_key : g_set.key;
    std::vector<std::string> hd = {"Authorization: Bearer " + key, "Content-Type: " + ctype, "X-Title: FLEY AI"};
    return HttpDo("https://" + host + base + path, "POST", body, hd, 15, 120, "FLEY-AI/0.9-linux");
}
static std::string HttpGetPage(const std::string& host, const std::string& path) {
    std::vector<std::string> hd = {"Accept-Language: ru,en;q=0.8", "Cookie: CONSENT=YES+1; SOCS=CAI"};
    HttpRes r = HttpDo("https://" + host + path, nullptr, "", hd, 8, 15,
                       "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36");
    if (r.body.size() > 1500000) r.body.resize(1500000);
    return r.body;
}

struct KeyError : std::runtime_error {
    explicit KeyError(const std::string& m) : std::runtime_error(m) {}
};
struct RateLimit : std::runtime_error {
    int wait;
    RateLimit(const std::string& m, int w) : std::runtime_error(m), wait(w) {}
};
static void CheckHttp(const HttpRes& r) {
    if (r.status == 429) {
        int w = r.retry > 0 ? r.retry : parse_retry_seconds(r.body);
        throw RateLimit(explain_error(429, r.body), w > 0 ? w : 20);
    }
    if (r.status == 401) throw KeyError(explain_error(401, r.body));
    if (r.status == 0)
        throw std::runtime_error("Нет связи с сервером (" + r.errstr + "). Проверьте интернет или VPN.");
    if (r.status < 200 || r.status >= 300) throw std::runtime_error(explain_error(r.status, r.body));
}

// ------------------------------------------------------------------ процессы
struct ProcRes {
    int code = -1;
    std::string out;
    bool timedOut = false, notFound = false;
};
static bool HasCmd(const std::string& name) {
    if (name.empty()) return false;
    if (name.find('/') != std::string::npos) return access(name.c_str(), X_OK) == 0;
    const char* p = getenv("PATH");
    std::string path = p ? p : "/usr/local/bin:/usr/bin:/bin";
    size_t st = 0;
    while (st <= path.size()) {
        size_t e = path.find(':', st);
        std::string dir = path.substr(st, e == std::string::npos ? std::string::npos : e - st);
        if (!dir.empty() && access((dir + "/" + name).c_str(), X_OK) == 0) return true;
        if (e == std::string::npos) break;
        st = e + 1;
    }
    return false;
}
static std::vector<char*> ArgvOf(const std::vector<std::string>& a) {
    std::vector<char*> v;
    for (auto& s : a) v.push_back(const_cast<char*>(s.c_str()));
    v.push_back(nullptr);
    return v;
}
// Запуск программы БЕЗ оболочки (аргументы не интерпретируются), с перехватом вывода и таймаутом.
static ProcRes RunProc(const std::vector<std::string>& args, const std::string& input = "", int timeoutMs = 20000,
                       bool abortOnStop = false, bool keepStderr = true) {
    ProcRes pr;
    if (args.empty()) return pr;
    std::vector<char*> av = ArgvOf(args);
    int inP[2], outP[2];
    if (pipe(inP) != 0) return pr;
    if (pipe(outP) != 0) { close(inP[0]); close(inP[1]); return pr; }
    pid_t pid = fork();
    if (pid < 0) { close(inP[0]); close(inP[1]); close(outP[0]); close(outP[1]); return pr; }
    if (pid == 0) {
        setpgid(0, 0);
        dup2(inP[0], 0);
        dup2(outP[1], 1);
        if (keepStderr) dup2(outP[1], 2);
        else { int dn = open("/dev/null", O_WRONLY); if (dn >= 0) dup2(dn, 2); }
        close(inP[0]); close(inP[1]); close(outP[0]); close(outP[1]);
        execvp(av[0], av.data());
        _exit(127);
    }
    setpgid(pid, pid);
    close(inP[0]);
    close(outP[1]);
    size_t off = 0;
    while (off < input.size()) {
        ssize_t n = write(inP[1], input.data() + off, input.size() - off);
        if (n <= 0) break;
        off += (size_t)n;
    }
    close(inP[1]);
    long long t0 = Tick();
    char buf[4096];
    for (;;) {
        pollfd p = {outP[0], POLLIN, 0};
        int r = poll(&p, 1, 100);
        if (r > 0) {
            ssize_t n = read(outP[0], buf, sizeof buf);
            if (n > 0) { if (pr.out.size() < 8u * 1024 * 1024) pr.out.append(buf, (size_t)n); }
            else break;
        }
        if (Tick() - t0 > timeoutMs || (abortOnStop && (g_stopSpeak || g_closing))) {
            kill(-pid, SIGKILL);
            pr.timedOut = true;
            break;
        }
    }
    close(outP[0]);
    int st = 0;
    waitpid(pid, &st, 0);
    pr.code = pr.timedOut ? -2 : WIFEXITED(st) ? WEXITSTATUS(st) : -1;
    pr.notFound = pr.code == 127;
    return pr;
}
// Запуск «и забыл» (программа живёт сама по себе, не зависит от FLEY AI).
static bool Spawn(const std::vector<std::string>& args) {
    if (args.empty() || !HasCmd(args[0])) return false;
    std::vector<char*> av = ArgvOf(args);
    pid_t p = fork();
    if (p < 0) return false;
    if (p == 0) {
        setsid();
        if (fork() != 0) _exit(0);
        int dn = open("/dev/null", O_RDWR);
        if (dn >= 0) { dup2(dn, 0); dup2(dn, 1); dup2(dn, 2); }
        execvp(av[0], av.data());
        _exit(127);
    }
    int st = 0;
    waitpid(p, &st, 0);
    return true;
}
static bool ShellOpen(const std::string& target) {
    for (const char* c : {"xdg-open", "gio", "gnome-open", "kde-open5", "kde-open"}) {
        if (!HasCmd(c)) continue;
        if (std::string(c) == "gio") return Spawn({"gio", "open", target});
        return Spawn({c, target});
    }
    return false;
}

// ------------------------------------------------------------------ звук (SDL2): запись и воспроизведение
struct WavInfo { int rate = 0, ch = 0; std::string pcm; };
static bool ParseWav(const std::string& w, WavInfo& out) {
    if (w.size() < 44 || w.compare(0, 4, "RIFF") != 0 || w.compare(8, 4, "WAVE") != 0) return false;
    size_t p = 12;
    int fmt = 0, bits = 0;
    while (p + 8 <= w.size()) {
        std::string id = w.substr(p, 4);
        size_t len = rd_le(w, p + 4, 4);
        if (id == "fmt " && p + 8 + 16 <= w.size()) {
            fmt = (int)rd_le(w, p + 8, 2);
            out.ch = (int)rd_le(w, p + 10, 2);
            out.rate = (int)rd_le(w, p + 12, 4);
            bits = (int)rd_le(w, p + 22, 2);
        } else if (id == "data") {
            size_t off = p + 8, n = std::min(len, w.size() - off);
            out.pcm = w.substr(off, n);
            break;
        }
        p += 8 + len + (len & 1);
    }
    return fmt == 1 && bits == 16 && out.ch >= 1 && out.ch <= 2 && out.rate >= 8000 && !out.pcm.empty();
}

static SDL_AudioDeviceID g_play = 0;
static void StopPlayback() {
    if (g_play) {
        SDL_ClearQueuedAudio(g_play);
        SDL_CloseAudioDevice(g_play);
        g_play = 0;
    }
}
// Начинает воспроизведение и сразу возвращается; возвращает длительность в секундах.
static double StartPcm(const std::string& pcm, int rate, int ch = 1) {
    StopPlayback();
    SDL_AudioSpec want, have;
    SDL_zero(want);
    SDL_zero(have);
    want.freq = rate;
    want.format = AUDIO_S16SYS;
    want.channels = (Uint8)ch;
    want.samples = 2048;
    want.callback = nullptr;
    g_play = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);
    if (!g_play) throw std::runtime_error(std::string("Не удалось открыть динамики: ") + SDL_GetError());
    SDL_QueueAudio(g_play, pcm.data(), (Uint32)pcm.size());
    SDL_PauseAudioDevice(g_play, 0);
    return (double)pcm.size() / (rate * 2.0 * ch);
}
static double StartWav(const std::string& wav) {
    WavInfo wi;
    if (!ParseWav(wav, wi)) throw std::runtime_error("Синтезатор речи вернул непонятный звук.");
    return StartPcm(wi.pcm, wi.rate, wi.ch);
}
static void WaitPlayback() {
    if (!g_play) return;
    while (SDL_GetQueuedAudioSize(g_play) > 0 && !g_stopSpeak && !g_closing) Sleep(25);
    if (!g_stopSpeak && !g_closing) Sleep(300);  // дать доиграть хвост буфера
    StopPlayback();
}
static void PlayPcm(const std::string& pcm, int rate) {
    g_stopSpeak = 0;
    StartPcm(pcm, rate, 1);
    WaitPlayback();
}
