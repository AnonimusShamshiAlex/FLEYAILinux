// FLEY AI 0.9 (FLEY Industries) - версия для Linux.
// Окно: SDL2 + Cairo. Сеть: libcurl. Звук: SDL2. Озвучка: espeak-ng / Piper. Ядро (JSON, .env, VAD, команды) - core.hpp.
//
// Сборка: см. build.sh (g++ -std=c++17 -O2 src/main_linux.cpp $(pkg-config --cflags --libs sdl2 cairo libcurl) -lpthread)
#include "linux/ui.hpp"

static std::atomic<int> g_workerDone{0};

static std::string ExeDir() { return g_exePath.substr(0, g_exePath.find_last_of('/')); }

static void SetWindowIconFromPng(const std::string& path) {
    cairo_surface_t* img = cairo_image_surface_create_from_png(path.c_str());
    if (cairo_surface_status(img) != CAIRO_STATUS_SUCCESS) { cairo_surface_destroy(img); return; }
    cairo_surface_flush(img);
    SDL_Surface* sf = SDL_CreateRGBSurfaceFrom(cairo_image_surface_get_data(img), cairo_image_surface_get_width(img), cairo_image_surface_get_height(img), 32,
                                               cairo_image_surface_get_stride(img), 0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
    if (sf) { SDL_SetWindowIcon(g_win, sf); SDL_FreeSurface(sf); }
    cairo_surface_destroy(img);
}

int main(int, char**) {
    signal(SIGPIPE, SIG_IGN);
    char exe[4096] = {};
    ssize_t n = readlink("/proc/self/exe", exe, sizeof exe - 1);
    g_exePath = n > 0 ? std::string(exe, (size_t)n) : "./fley-ai";

    // папка данных: FLEY_HOME, либо папка программы (если там есть .env и можно писать), либо ~/.config/fley-ai
    const char* fh = getenv("FLEY_HOME");
    if (fh && *fh) { g_dir = fh; MkdirP(g_dir); }
    else if (PathExists(ExeDir() + "/.env") && access(ExeDir().c_str(), W_OK) == 0) g_dir = ExeDir();
    else {
        const char* xc = getenv("XDG_CONFIG_HOME");
        g_dir = (xc && *xc ? std::string(xc) : HomeDir() + "/.config") + "/fley-ai";
        MkdirP(g_dir);
    }
    g_envPath = g_dir + "/.env";
    EnsureEnvFile();
    LoadSettings();
    if (g_set.autostart) ApplyAutostart(true);
    LoadMemory();
    LoadHistory();

    curl_global_init(CURL_GLOBAL_DEFAULT);
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_EVENTS) != 0) {
        fprintf(stderr, "FLEY AI: не удалось запустить SDL: %s\n", SDL_GetError());
        return 1;
    }
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");
    int startMode = g_set.window_mode == "window" ? 1 : g_set.window_mode == "mini" ? 2 : 0;
    Uint32 flags = SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN;
    int w0 = startMode == 2 ? 520 : 1280, h0 = startMode == 2 ? 760 : 760;
    g_win = SDL_CreateWindow("FLEY AI", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, w0, h0, flags);
    if (!g_win) {
        fprintf(stderr, "FLEY AI: не удалось создать окно: %s\n", SDL_GetError());
        return 1;
    }
    SetWindowIconFromPng(ExeDir() + "/fai.png");
    SDL_Renderer* ren = SDL_CreateRenderer(g_win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!ren) ren = SDL_CreateRenderer(g_win, -1, SDL_RENDERER_SOFTWARE);
    if (!ren) {
        fprintf(stderr, "FLEY AI: не удалось создать отрисовщик: %s\n", SDL_GetError());
        return 1;
    }
    ApplyMode(startMode, false);

    std::thread([] { SessionThread(); g_workerDone = 1; }).detach();

    SDL_Texture* tex = nullptr;
    cairo_surface_t* surf = nullptr;
    int texW = 0, texH = 0;
    long long lastStats = 0;
    bool confirmSeen = false;

    while (!g_closing) {
        // ---- события
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            switch (e.type) {
                case SDL_QUIT: g_closing = 1; break;
                case SDL_MOUSEMOTION: g_hover = HitTest(e.motion.x, e.motion.y); break;
                case SDL_MOUSEBUTTONDOWN:
                    if (e.button.button != SDL_BUTTON_LEFT) break;
                    g_hover = HitTest(e.button.x, e.button.y);
                    g_press = g_hover;
                    if (g_setOpen && !g_cfShow)
                        for (int i = 0; i < 4; ++i)
                            if (InRc(SL.f[i], e.button.x, e.button.y)) g_focus = i;
                    break;
                case SDL_MOUSEBUTTONUP:
                    if (e.button.button != SDL_BUTTON_LEFT) break;
                    {
                        int id = HitTest(e.button.x, e.button.y);
                        if (id != B_NONE && id == g_press) Activate(id);
                        g_press = 0;
                        g_hover = HitTest(e.button.x, e.button.y);
                    }
                    break;
                case SDL_TEXTINPUT:
                    if (g_setOpen && !g_cfShow && g_ed[g_focus].size() < 300) g_ed[g_focus] += e.text.text;
                    break;
                case SDL_KEYDOWN: {
                    SDL_Keycode k = e.key.keysym.sym;
                    bool ctrl = (e.key.keysym.mod & KMOD_CTRL) != 0;
                    if (g_cfShow) {
                        if (k == SDLK_y) AnswerConfirm(true);
                        else if (k == SDLK_n || k == SDLK_ESCAPE) AnswerConfirm(false);
                        break;
                    }
                    if (g_setOpen) {
                        if (k == SDLK_ESCAPE) CloseSettings();
                        else if (k == SDLK_RETURN || k == SDLK_KP_ENTER) SaveSettingsUi();
                        else if (k == SDLK_TAB) g_focus = (g_focus + ((e.key.keysym.mod & KMOD_SHIFT) ? 3 : 1)) % 4;
                        else if (k == SDLK_BACKSPACE) { std::string& s = g_ed[g_focus]; if (!s.empty()) s.erase(U8Prev(s, s.size())); }
                        else if (ctrl && k == SDLK_v) {
                            char* cb = SDL_GetClipboardText();
                            if (cb) {
                                std::string add;
                                for (char* p = cb; *p; ++p) if (*p != '\n' && *p != '\r') add += *p;
                                if (g_focus == 0) { std::string c2; for (char c : add) if (!isspace((unsigned char)c) && c != '"' && c != '\'') c2 += c; add = c2; }
                                g_ed[g_focus] += add;
                                SDL_free(cb);
                            }
                        } else if (ctrl && k == SDLK_a) g_ed[g_focus].clear();
                        break;
                    }
                    if (k == SDLK_ESCAPE) { if (g_mode == 0) ApplyMode(1); }
                    else if (k == SDLK_F11) ApplyMode((g_mode + 1) % 3);
                    else if (k == SDLK_SPACE && !e.key.repeat) OnOrbClick();
                    break;
                }
                case SDL_WINDOWEVENT:
                    if (e.window.event == SDL_WINDOWEVENT_LEAVE) g_hover = 0;
                    break;
            }
        }

        // ---- запросы из рабочего потока
        if (g_wantSet && !g_setOpen) { OpenSettings(); g_wantSet = 0; }
        if (g_cfReq && !confirmSeen) {
            { std::lock_guard<std::mutex> lk(g_cfMx); g_cfLocal = g_cfText; }
            g_cfShow = true;
            confirmSeen = true;
            SDL_RaiseWindow(g_win);
        }
        if (!g_cfReq) confirmSeen = false;
        if (g_cfShow && g_cfAns != -1) g_cfShow = false;  // ответ пришёл иначе (таймаут)
        {
            std::lock_guard<std::mutex> lk(g_mx);
            for (auto& m : g_pendingLog) g_log.push_back({m.role, m.text});
            g_pendingLog.clear();
        }
        if (g_log.size() > 200) g_log.erase(g_log.begin(), g_log.begin() + (long)(g_log.size() - 200));

        // ---- размер окна / пересборка фона
        int ww = 0, wh = 0;
        SDL_GetWindowSize(g_win, &ww, &wh);
        if (ww < 200 || wh < 200) { SDL_Delay(50); continue; }  // свёрнуто
        if (ww != g_W || wh != g_H || !surf || L.mini != (g_mode == 2)) {
            g_W = ww;
            g_H = wh;
            Relayout();
            BuildBg();
            if (surf) cairo_surface_destroy(surf);
            surf = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, g_W, g_H);
            if (tex) SDL_DestroyTexture(tex);
            tex = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, g_W, g_H);
            texW = g_W;
            texH = g_H;
        }
        (void)texW; (void)texH;

        // ---- кадр
        Animate();
        if (Tick() - lastStats > 1000) { UpdateStats(); lastStats = Tick(); }
        cairo_t* c = cairo_create(surf);
        cairo_set_operator(c, CAIRO_OPERATOR_SOURCE);
        cairo_set_source_surface(c, g_bg, 0, 0);
        cairo_paint(c);
        cairo_set_operator(c, CAIRO_OPERATOR_OVER);
        cairo_set_antialias(c, CAIRO_ANTIALIAS_GOOD);
        Gfx g{c};
        DrawHud(g);
        if (g_setOpen) DrawSettings(g);
        if (g_cfShow) DrawConfirm(g);
        BuildButtons();
        for (const BtnDef& b : g_btns) Btn(g, b, g_hover == b.id, g_press == b.id && g_hover == b.id);
        if (g_setOpen && g_hover) {
            std::string tp = TipFor(g_hover);
            g.text(tp, true, 13 * L.s, false, C_ICE, 255, {SL.panel.x + 28 * L.s, SL.panel.y + SL.panel.h - 118 * L.s, SL.panel.w - 56 * L.s, 20 * L.s});
        }
        cairo_destroy(c);
        cairo_surface_flush(surf);
        SDL_UpdateTexture(tex, nullptr, cairo_image_surface_get_data(surf), cairo_image_surface_get_stride(surf));
        SDL_RenderClear(ren);
        SDL_RenderCopy(ren, tex, nullptr, nullptr);
        SDL_RenderPresent(ren);
        SDL_Delay(16);
    }

    // ---- выход: останавливаем звук и даём рабочему потоку секунду-две на завершение
    g_stopSpeak = 1;
    g_cfCv.notify_all();
    long long t0 = Tick();
    while (!g_workerDone && Tick() - t0 < 2000) Sleep(50);
    StopPlayback();
    if (tex) SDL_DestroyTexture(tex);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(g_win);
    fflush(nullptr);
    _exit(0);  // рабочий поток может ждать ответа сервера: не блокируем выход
}
