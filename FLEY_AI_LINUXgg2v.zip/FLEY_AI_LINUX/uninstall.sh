#!/usr/bin/env bash
# Удаляет программу и ярлыки. Папку с настройками и памятью спросит отдельно.
set -u
DEST="$HOME/.local/share/fley-ai"
rm -f "$HOME/.local/bin/fley-ai" "$HOME/.local/share/applications/fley-ai.desktop" "$HOME/.config/autostart/fley-ai.desktop"
rm -f "$DEST/fley-ai" "$DEST/fai.png"
read -r -p "Удалить также настройки (.env), память и историю в $DEST ? [y/N] " a
[ "${a:-N}" = y ] && rm -rf "$DEST"
echo "Готово."
