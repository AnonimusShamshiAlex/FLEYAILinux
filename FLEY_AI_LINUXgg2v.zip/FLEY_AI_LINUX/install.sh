#!/usr/bin/env bash
# Устанавливает FLEY AI для текущего пользователя: ~/.local/share/fley-ai + ярлык в меню приложений.
set -euo pipefail
cd "$(dirname "$0")"
[ -x dist/fley-ai ] || ./build.sh
DEST="$HOME/.local/share/fley-ai"
mkdir -p "$DEST" "$HOME/.local/share/applications" "$HOME/.local/bin"
cp -f dist/fley-ai dist/fai.png "$DEST/"
[ -f "$DEST/.env" ] || { cp -f dist/.env "$DEST/.env"; chmod 600 "$DEST/.env"; }
ln -sf "$DEST/fley-ai" "$HOME/.local/bin/fley-ai"
cat > "$HOME/.local/share/applications/fley-ai.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=FLEY AI
Comment=Голосовой ИИ-помощник
Exec=$DEST/fley-ai
Path=$DEST
Icon=$DEST/fai.png
Terminal=false
Categories=Utility;
DESK
echo "Установлено в $DEST. Запуск: из меню приложений или командой fley-ai"
